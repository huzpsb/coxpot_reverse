﻿using System;

// Token: 0x020000BC RID: 188
internal class <Module>{8F015F08-D6B8-4F20-837E-FD8585B23A29}
{
}
