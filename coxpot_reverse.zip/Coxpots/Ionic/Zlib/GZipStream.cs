﻿using System;
using System.IO;
using System.Text;

namespace Ionic.Zlib
{
	// Token: 0x02000071 RID: 113
	public class GZipStream : Stream
	{
		// Token: 0x1700003C RID: 60
		// (get) Token: 0x060001D8 RID: 472 RVA: 0x0000E80C File Offset: 0x0000CA0C
		// (set) Token: 0x060001D9 RID: 473 RVA: 0x0000549A File Offset: 0x0000369A
		public string Comment
		{
			get
			{
				return this.string_1;
			}
			set
			{
				if (this.bool_0)
				{
					throw new ObjectDisposedException("GZipStream");
				}
				this.string_1 = value;
			}
		}

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x060001DA RID: 474 RVA: 0x0000E824 File Offset: 0x0000CA24
		// (set) Token: 0x060001DB RID: 475 RVA: 0x0000E83C File Offset: 0x0000CA3C
		public string FileName
		{
			get
			{
				return this.string_0;
			}
			set
			{
				if (this.bool_0)
				{
					throw new ObjectDisposedException("GZipStream");
				}
				this.string_0 = value;
				if (this.string_0 != null)
				{
					if (this.string_0.IndexOf("/") != -1)
					{
						this.string_0 = this.string_0.Replace("/", "\\");
					}
					if (this.string_0.EndsWith("\\"))
					{
						throw new Exception("Illegal filename");
					}
					if (this.string_0.IndexOf("\\") != -1)
					{
						this.string_0 = Path.GetFileName(this.string_0);
					}
				}
			}
		}

		// Token: 0x1700003E RID: 62
		// (get) Token: 0x060001DC RID: 476 RVA: 0x0000E8E8 File Offset: 0x0000CAE8
		public int Crc32
		{
			get
			{
				return this.int_1;
			}
		}

		// Token: 0x060001DD RID: 477 RVA: 0x000054B6 File Offset: 0x000036B6
		public GZipStream(Stream stream, CompressionMode mode)
		{
			Class35.NkAVmDjz8ZWXG();
			this..ctor(stream, mode, CompressionLevel.Default, false);
		}

		// Token: 0x060001DE RID: 478 RVA: 0x000054C7 File Offset: 0x000036C7
		public GZipStream(Stream stream, CompressionMode mode, CompressionLevel level)
		{
			Class35.NkAVmDjz8ZWXG();
			this..ctor(stream, mode, level, false);
		}

		// Token: 0x060001DF RID: 479 RVA: 0x000054D8 File Offset: 0x000036D8
		public GZipStream(Stream stream, CompressionMode mode, bool leaveOpen)
		{
			Class35.NkAVmDjz8ZWXG();
			this..ctor(stream, mode, CompressionLevel.Default, leaveOpen);
		}

		// Token: 0x060001E0 RID: 480 RVA: 0x000054E9 File Offset: 0x000036E9
		public GZipStream(Stream stream, CompressionMode mode, CompressionLevel level, bool leaveOpen)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.stream0_0 = new Stream0(stream, mode, level, (Enum7)1952, leaveOpen);
		}

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x060001E1 RID: 481 RVA: 0x0000E900 File Offset: 0x0000CB00
		// (set) Token: 0x060001E2 RID: 482 RVA: 0x0000550B File Offset: 0x0000370B
		public virtual FlushType FlushMode
		{
			get
			{
				return this.stream0_0.flushType_0;
			}
			set
			{
				if (this.bool_0)
				{
					throw new ObjectDisposedException("GZipStream");
				}
				this.stream0_0.flushType_0 = value;
			}
		}

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x060001E3 RID: 483 RVA: 0x0000E91C File Offset: 0x0000CB1C
		// (set) Token: 0x060001E4 RID: 484 RVA: 0x0000E938 File Offset: 0x0000CB38
		public int BufferSize
		{
			get
			{
				return this.stream0_0.int_0;
			}
			set
			{
				if (this.bool_0)
				{
					throw new ObjectDisposedException("GZipStream");
				}
				if (this.stream0_0.byte_0 != null)
				{
					throw new ZlibException("The working buffer is already set.");
				}
				if (value < 1024)
				{
					throw new ZlibException(string.Format("Don't be silly. {0} bytes?? Use a bigger buffer, at least {1}.", value, 1024));
				}
				this.stream0_0.int_0 = value;
			}
		}

		// Token: 0x17000041 RID: 65
		// (get) Token: 0x060001E5 RID: 485 RVA: 0x0000E9AC File Offset: 0x0000CBAC
		public virtual long TotalIn
		{
			get
			{
				return this.stream0_0.zlibCodec_0.TotalBytesIn;
			}
		}

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x060001E6 RID: 486 RVA: 0x0000E9CC File Offset: 0x0000CBCC
		public virtual long TotalOut
		{
			get
			{
				return this.stream0_0.zlibCodec_0.TotalBytesOut;
			}
		}

		// Token: 0x060001E7 RID: 487 RVA: 0x0000E9EC File Offset: 0x0000CBEC
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (!this.bool_0)
				{
					if (disposing && this.stream0_0 != null)
					{
						this.stream0_0.Close();
						this.int_1 = this.stream0_0.method_0();
					}
					this.bool_0 = true;
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x060001E8 RID: 488 RVA: 0x0000552C File Offset: 0x0000372C
		public override bool CanRead
		{
			get
			{
				if (this.bool_0)
				{
					throw new ObjectDisposedException("GZipStream");
				}
				return this.stream0_0.stream_0.CanRead;
			}
		}

		// Token: 0x17000044 RID: 68
		// (get) Token: 0x060001E9 RID: 489 RVA: 0x00005551 File Offset: 0x00003751
		public override bool CanSeek
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x060001EA RID: 490 RVA: 0x00005554 File Offset: 0x00003754
		public override bool CanWrite
		{
			get
			{
				if (this.bool_0)
				{
					throw new ObjectDisposedException("GZipStream");
				}
				return this.stream0_0.stream_0.CanWrite;
			}
		}

		// Token: 0x060001EB RID: 491 RVA: 0x00005579 File Offset: 0x00003779
		public override void Flush()
		{
			if (this.bool_0)
			{
				throw new ObjectDisposedException("GZipStream");
			}
			this.stream0_0.Flush();
		}

		// Token: 0x17000046 RID: 70
		// (get) Token: 0x060001EC RID: 492 RVA: 0x00005599 File Offset: 0x00003799
		public override long Length
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		// Token: 0x17000047 RID: 71
		// (get) Token: 0x060001ED RID: 493 RVA: 0x0000EA54 File Offset: 0x0000CC54
		// (set) Token: 0x060001EE RID: 494 RVA: 0x00005599 File Offset: 0x00003799
		public override long Position
		{
			get
			{
				long result;
				if (this.stream0_0.enum8_0 == (Stream0.Enum8)0)
				{
					result = this.stream0_0.zlibCodec_0.TotalBytesOut + (long)this.int_0;
				}
				else if (this.stream0_0.enum8_0 == (Stream0.Enum8)1)
				{
					result = this.stream0_0.zlibCodec_0.TotalBytesIn + (long)this.stream0_0.int_1;
				}
				else
				{
					result = 0L;
				}
				return result;
			}
			set
			{
				throw new NotImplementedException();
			}
		}

		// Token: 0x060001EF RID: 495 RVA: 0x0000EAC8 File Offset: 0x0000CCC8
		public override int Read(byte[] buffer, int offset, int count)
		{
			if (this.bool_0)
			{
				throw new ObjectDisposedException("GZipStream");
			}
			int result = this.stream0_0.Read(buffer, offset, count);
			if (!this.bool_1)
			{
				this.bool_1 = true;
				this.FileName = this.stream0_0.string_0;
				this.Comment = this.stream0_0.string_1;
			}
			return result;
		}

		// Token: 0x060001F0 RID: 496 RVA: 0x00005599 File Offset: 0x00003799
		public override long Seek(long offset, SeekOrigin origin)
		{
			throw new NotImplementedException();
		}

		// Token: 0x060001F1 RID: 497 RVA: 0x00005599 File Offset: 0x00003799
		public override void SetLength(long value)
		{
			throw new NotImplementedException();
		}

		// Token: 0x060001F2 RID: 498 RVA: 0x0000EB30 File Offset: 0x0000CD30
		public override void Write(byte[] buffer, int offset, int count)
		{
			if (this.bool_0)
			{
				throw new ObjectDisposedException("GZipStream");
			}
			if (this.stream0_0.enum8_0 == (Stream0.Enum8)2)
			{
				if (!this.stream0_0.method_1())
				{
					throw new InvalidOperationException();
				}
				this.int_0 = this.method_0();
			}
			this.stream0_0.Write(buffer, offset, count);
		}

		// Token: 0x060001F3 RID: 499 RVA: 0x0000EB90 File Offset: 0x0000CD90
		private int method_0()
		{
			byte[] array = (this.Comment == null) ? null : GZipStream.xnfuafYhhW.GetBytes(this.Comment);
			byte[] array2 = (this.FileName == null) ? null : GZipStream.xnfuafYhhW.GetBytes(this.FileName);
			int num = (this.Comment == null) ? 0 : (array.Length + 1);
			int num2 = (this.FileName == null) ? 0 : (array2.Length + 1);
			int num3 = 10 + num + num2;
			byte[] array3 = new byte[num3];
			array3[0] = 31;
			array3[1] = 139;
			byte[] array4 = array3;
			int num4 = 2;
			int num5 = 3;
			array4[num4] = 8;
			byte b = 0;
			if (this.Comment != null)
			{
				b ^= 16;
			}
			if (this.FileName != null)
			{
				b ^= 8;
			}
			array3[num5++] = b;
			if (this.LastModified == null)
			{
				this.LastModified = new DateTime?(DateTime.Now);
			}
			int value = (int)(this.LastModified.Value - GZipStream.dateTime_0).TotalSeconds;
			Array.Copy(BitConverter.GetBytes(value), 0, array3, num5, 4);
			num5 += 4;
			array3[num5++] = 0;
			array3[num5++] = byte.MaxValue;
			if (num2 != 0)
			{
				Array.Copy(array2, 0, array3, num5, num2 - 1);
				num5 += num2 - 1;
				array3[num5++] = 0;
			}
			if (num != 0)
			{
				Array.Copy(array, 0, array3, num5, num - 1);
				num5 += num - 1;
				array3[num5++] = 0;
			}
			this.stream0_0.stream_0.Write(array3, 0, array3.Length);
			return array3.Length;
		}

		// Token: 0x060001F4 RID: 500 RVA: 0x0000ED34 File Offset: 0x0000CF34
		public static byte[] CompressString(string s)
		{
			byte[] result;
			using (MemoryStream memoryStream = new MemoryStream())
			{
				Stream stream_ = new GZipStream(memoryStream, CompressionMode.Compress, CompressionLevel.BestCompression);
				Stream0.smethod_0(s, stream_);
				result = memoryStream.ToArray();
			}
			return result;
		}

		// Token: 0x060001F5 RID: 501 RVA: 0x0000ED7C File Offset: 0x0000CF7C
		public static byte[] CompressBuffer(byte[] b)
		{
			byte[] result;
			using (MemoryStream memoryStream = new MemoryStream())
			{
				Stream stream_ = new GZipStream(memoryStream, CompressionMode.Compress, CompressionLevel.BestCompression);
				Stream0.smethod_1(b, stream_);
				result = memoryStream.ToArray();
			}
			return result;
		}

		// Token: 0x060001F6 RID: 502 RVA: 0x0000EDC4 File Offset: 0x0000CFC4
		public static string UncompressString(byte[] compressed)
		{
			string result;
			using (MemoryStream memoryStream = new MemoryStream(compressed))
			{
				Stream stream_ = new GZipStream(memoryStream, CompressionMode.Decompress);
				result = Stream0.smethod_2(compressed, stream_);
			}
			return result;
		}

		// Token: 0x060001F7 RID: 503 RVA: 0x0000EE08 File Offset: 0x0000D008
		public static byte[] UncompressBuffer(byte[] compressed)
		{
			byte[] result;
			using (MemoryStream memoryStream = new MemoryStream(compressed))
			{
				Stream stream_ = new GZipStream(memoryStream, CompressionMode.Decompress);
				result = Stream0.smethod_3(compressed, stream_);
			}
			return result;
		}

		// Token: 0x060001F8 RID: 504 RVA: 0x000055A0 File Offset: 0x000037A0
		static GZipStream()
		{
			Class35.NkAVmDjz8ZWXG();
			GZipStream.dateTime_0 = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
			GZipStream.xnfuafYhhW = Encoding.GetEncoding("iso-8859-1");
		}

		// Token: 0x040001E2 RID: 482
		public DateTime? LastModified;

		// Token: 0x040001E3 RID: 483
		private int int_0;

		// Token: 0x040001E4 RID: 484
		internal Stream0 stream0_0;

		// Token: 0x040001E5 RID: 485
		private bool bool_0;

		// Token: 0x040001E6 RID: 486
		private bool bool_1;

		// Token: 0x040001E7 RID: 487
		private string string_0;

		// Token: 0x040001E8 RID: 488
		private string string_1;

		// Token: 0x040001E9 RID: 489
		private int int_1;

		// Token: 0x040001EA RID: 490
		internal static readonly DateTime dateTime_0;

		// Token: 0x040001EB RID: 491
		internal static readonly Encoding xnfuafYhhW;
	}
}
