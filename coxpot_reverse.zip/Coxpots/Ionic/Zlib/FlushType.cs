﻿using System;

namespace Ionic.Zlib
{
	// Token: 0x0200007A RID: 122
	public enum FlushType
	{
		// Token: 0x04000235 RID: 565
		None,
		// Token: 0x04000236 RID: 566
		Partial,
		// Token: 0x04000237 RID: 567
		Sync,
		// Token: 0x04000238 RID: 568
		Full,
		// Token: 0x04000239 RID: 569
		Finish
	}
}
