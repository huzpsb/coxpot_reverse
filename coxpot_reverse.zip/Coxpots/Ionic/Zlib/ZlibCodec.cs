﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zlib
{
	// Token: 0x02000086 RID: 134
	[Guid("ebc25cf6-9120-4283-b972-0e5520d0000D")]
	[ComVisible(true)]
	[ClassInterface(ClassInterfaceType.AutoDispatch)]
	public sealed class ZlibCodec
	{
		// Token: 0x1700004D RID: 77
		// (get) Token: 0x06000246 RID: 582 RVA: 0x00013C7C File Offset: 0x00011E7C
		public int Adler32
		{
			get
			{
				return (int)this.uint_0;
			}
		}

		// Token: 0x06000247 RID: 583 RVA: 0x00005816 File Offset: 0x00003A16
		public ZlibCodec()
		{
			Class35.NkAVmDjz8ZWXG();
			this.CompressLevel = CompressionLevel.Default;
			this.WindowBits = 15;
			this.Strategy = CompressionStrategy.Default;
			base..ctor();
		}

		// Token: 0x06000248 RID: 584 RVA: 0x00013C94 File Offset: 0x00011E94
		public ZlibCodec(CompressionMode mode)
		{
			Class35.NkAVmDjz8ZWXG();
			this.CompressLevel = CompressionLevel.Default;
			this.WindowBits = 15;
			this.Strategy = CompressionStrategy.Default;
			base..ctor();
			if (mode == CompressionMode.Compress)
			{
				int num = this.InitializeDeflate();
				if (num != 0)
				{
					throw new ZlibException("Cannot initialize for deflate.");
				}
			}
			else
			{
				if (mode != CompressionMode.Decompress)
				{
					throw new ZlibException("Invalid ZlibStreamFlavor.");
				}
				int num2 = this.InitializeInflate();
				if (num2 != 0)
				{
					throw new ZlibException("Cannot initialize for inflate.");
				}
			}
		}

		// Token: 0x06000249 RID: 585 RVA: 0x00013D0C File Offset: 0x00011F0C
		public int InitializeInflate()
		{
			return this.InitializeInflate(this.WindowBits);
		}

		// Token: 0x0600024A RID: 586 RVA: 0x00013D28 File Offset: 0x00011F28
		public int InitializeInflate(bool expectRfc1950Header)
		{
			return this.InitializeInflate(this.WindowBits, expectRfc1950Header);
		}

		// Token: 0x0600024B RID: 587 RVA: 0x00013D44 File Offset: 0x00011F44
		public int InitializeInflate(int windowBits)
		{
			this.WindowBits = windowBits;
			return this.InitializeInflate(windowBits, true);
		}

		// Token: 0x0600024C RID: 588 RVA: 0x00013D64 File Offset: 0x00011F64
		public int InitializeInflate(int windowBits, bool expectRfc1950Header)
		{
			this.WindowBits = windowBits;
			if (this.class2_0 != null)
			{
				throw new ZlibException("You may not call InitializeInflate() after calling InitializeDeflate().");
			}
			this.class7_0 = new Class7(expectRfc1950Header);
			return this.class7_0.method_4(this, windowBits);
		}

		// Token: 0x0600024D RID: 589 RVA: 0x00013DAC File Offset: 0x00011FAC
		public int Inflate(FlushType flush)
		{
			if (this.class7_0 == null)
			{
				throw new ZlibException("No Inflate State!");
			}
			return this.class7_0.method_5(flush);
		}

		// Token: 0x0600024E RID: 590 RVA: 0x00013DE0 File Offset: 0x00011FE0
		public int EndInflate()
		{
			if (this.class7_0 == null)
			{
				throw new ZlibException("No Inflate State!");
			}
			int result = this.class7_0.method_3();
			this.class7_0 = null;
			return result;
		}

		// Token: 0x0600024F RID: 591 RVA: 0x00013E1C File Offset: 0x0001201C
		public int SyncInflate()
		{
			if (this.class7_0 == null)
			{
				throw new ZlibException("No Inflate State!");
			}
			return this.class7_0.method_7();
		}

		// Token: 0x06000250 RID: 592 RVA: 0x00013E4C File Offset: 0x0001204C
		public int InitializeDeflate()
		{
			return this.ooaXmHrUuk(true);
		}

		// Token: 0x06000251 RID: 593 RVA: 0x00013E64 File Offset: 0x00012064
		public int InitializeDeflate(CompressionLevel level)
		{
			this.CompressLevel = level;
			return this.ooaXmHrUuk(true);
		}

		// Token: 0x06000252 RID: 594 RVA: 0x00013E84 File Offset: 0x00012084
		public int InitializeDeflate(CompressionLevel level, bool wantRfc1950Header)
		{
			this.CompressLevel = level;
			return this.ooaXmHrUuk(wantRfc1950Header);
		}

		// Token: 0x06000253 RID: 595 RVA: 0x00013EA4 File Offset: 0x000120A4
		public int InitializeDeflate(CompressionLevel level, int bits)
		{
			this.CompressLevel = level;
			this.WindowBits = bits;
			return this.ooaXmHrUuk(true);
		}

		// Token: 0x06000254 RID: 596 RVA: 0x00013EC8 File Offset: 0x000120C8
		public int InitializeDeflate(CompressionLevel level, int bits, bool wantRfc1950Header)
		{
			this.CompressLevel = level;
			this.WindowBits = bits;
			return this.ooaXmHrUuk(wantRfc1950Header);
		}

		// Token: 0x06000255 RID: 597 RVA: 0x00013EEC File Offset: 0x000120EC
		private int ooaXmHrUuk(bool bool_0)
		{
			if (this.class7_0 != null)
			{
				throw new ZlibException("You may not call InitializeDeflate() after calling InitializeInflate().");
			}
			this.class2_0 = new Class2();
			this.class2_0.method_27(bool_0);
			return this.class2_0.method_30(this, this.CompressLevel, this.WindowBits, this.Strategy);
		}

		// Token: 0x06000256 RID: 598 RVA: 0x00013F48 File Offset: 0x00012148
		public int Deflate(FlushType flush)
		{
			if (this.class2_0 == null)
			{
				throw new ZlibException("No Deflate State!");
			}
			return this.class2_0.method_37(flush);
		}

		// Token: 0x06000257 RID: 599 RVA: 0x00005839 File Offset: 0x00003A39
		public int EndDeflate()
		{
			if (this.class2_0 == null)
			{
				throw new ZlibException("No Deflate State!");
			}
			this.class2_0 = null;
			return 0;
		}

		// Token: 0x06000258 RID: 600 RVA: 0x00005859 File Offset: 0x00003A59
		public void ResetDeflate()
		{
			if (this.class2_0 == null)
			{
				throw new ZlibException("No Deflate State!");
			}
			this.class2_0.method_32();
		}

		// Token: 0x06000259 RID: 601 RVA: 0x00013F7C File Offset: 0x0001217C
		public int SetDeflateParams(CompressionLevel level, CompressionStrategy strategy)
		{
			if (this.class2_0 == null)
			{
				throw new ZlibException("No Deflate State!");
			}
			return this.class2_0.method_35(level, strategy);
		}

		// Token: 0x0600025A RID: 602 RVA: 0x00013FB0 File Offset: 0x000121B0
		public int SetDictionary(byte[] dictionary)
		{
			int result;
			if (this.class7_0 != null)
			{
				result = this.class7_0.method_6(dictionary);
			}
			else
			{
				if (this.class2_0 == null)
				{
					throw new ZlibException("No Inflate or Deflate state!");
				}
				result = this.class2_0.method_36(dictionary);
			}
			return result;
		}

		// Token: 0x0600025B RID: 603 RVA: 0x00014000 File Offset: 0x00012200
		internal void method_0()
		{
			int num = this.class2_0.int_20;
			if (num > this.AvailableBytesOut)
			{
				num = this.AvailableBytesOut;
			}
			if (num != 0)
			{
				if (this.class2_0.byte_0.Length <= this.class2_0.int_19 || this.OutputBuffer.Length <= this.NextOut || this.class2_0.byte_0.Length < this.class2_0.int_19 + num || this.OutputBuffer.Length < this.NextOut + num)
				{
					throw new ZlibException(string.Format("Invalid State. (pending.Length={0}, pendingCount={1})", this.class2_0.byte_0.Length, this.class2_0.int_20));
				}
				Array.Copy(this.class2_0.byte_0, this.class2_0.int_19, this.OutputBuffer, this.NextOut, num);
				this.NextOut += num;
				this.class2_0.int_19 += num;
				this.TotalBytesOut += (long)num;
				this.AvailableBytesOut -= num;
				this.class2_0.int_20 -= num;
				if (this.class2_0.int_20 == 0)
				{
					this.class2_0.int_19 = 0;
				}
			}
		}

		// Token: 0x0600025C RID: 604 RVA: 0x00014158 File Offset: 0x00012358
		internal int method_1(byte[] byte_0, int int_0, int int_1)
		{
			int num = this.AvailableBytesIn;
			if (num > int_1)
			{
				num = int_1;
			}
			int result;
			if (num == 0)
			{
				result = 0;
			}
			else
			{
				this.AvailableBytesIn -= num;
				if (this.class2_0.method_26())
				{
					this.uint_0 = Adler.Adler32(this.uint_0, this.InputBuffer, this.NextIn, num);
				}
				Array.Copy(this.InputBuffer, this.NextIn, byte_0, int_0, num);
				this.NextIn += num;
				this.TotalBytesIn += (long)num;
				result = num;
			}
			return result;
		}

		// Token: 0x0400027A RID: 634
		public byte[] InputBuffer;

		// Token: 0x0400027B RID: 635
		public int NextIn;

		// Token: 0x0400027C RID: 636
		public int AvailableBytesIn;

		// Token: 0x0400027D RID: 637
		public long TotalBytesIn;

		// Token: 0x0400027E RID: 638
		public byte[] OutputBuffer;

		// Token: 0x0400027F RID: 639
		public int NextOut;

		// Token: 0x04000280 RID: 640
		public int AvailableBytesOut;

		// Token: 0x04000281 RID: 641
		public long TotalBytesOut;

		// Token: 0x04000282 RID: 642
		public string Message;

		// Token: 0x04000283 RID: 643
		internal Class2 class2_0;

		// Token: 0x04000284 RID: 644
		internal Class7 class7_0;

		// Token: 0x04000285 RID: 645
		internal uint uint_0;

		// Token: 0x04000286 RID: 646
		public CompressionLevel CompressLevel;

		// Token: 0x04000287 RID: 647
		public int WindowBits;

		// Token: 0x04000288 RID: 648
		public CompressionStrategy Strategy;
	}
}
