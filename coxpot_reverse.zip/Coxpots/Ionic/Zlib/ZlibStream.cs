﻿using System;
using System.IO;

namespace Ionic.Zlib
{
	// Token: 0x02000088 RID: 136
	public class ZlibStream : Stream
	{
		// Token: 0x0600025D RID: 605 RVA: 0x0000587C File Offset: 0x00003A7C
		public ZlibStream(Stream stream, CompressionMode mode)
		{
			Class35.NkAVmDjz8ZWXG();
			this..ctor(stream, mode, CompressionLevel.Default, false);
		}

		// Token: 0x0600025E RID: 606 RVA: 0x0000588D File Offset: 0x00003A8D
		public ZlibStream(Stream stream, CompressionMode mode, CompressionLevel level)
		{
			Class35.NkAVmDjz8ZWXG();
			this..ctor(stream, mode, level, false);
		}

		// Token: 0x0600025F RID: 607 RVA: 0x0000589E File Offset: 0x00003A9E
		public ZlibStream(Stream stream, CompressionMode mode, bool leaveOpen)
		{
			Class35.NkAVmDjz8ZWXG();
			this..ctor(stream, mode, CompressionLevel.Default, leaveOpen);
		}

		// Token: 0x06000260 RID: 608 RVA: 0x000058AF File Offset: 0x00003AAF
		public ZlibStream(Stream stream, CompressionMode mode, CompressionLevel level, bool leaveOpen)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.stream0_0 = new Stream0(stream, mode, level, (Enum7)1950, leaveOpen);
		}

		// Token: 0x1700004E RID: 78
		// (get) Token: 0x06000261 RID: 609 RVA: 0x000141EC File Offset: 0x000123EC
		// (set) Token: 0x06000262 RID: 610 RVA: 0x000058D1 File Offset: 0x00003AD1
		public virtual FlushType FlushMode
		{
			get
			{
				return this.stream0_0.flushType_0;
			}
			set
			{
				if (this.bool_0)
				{
					throw new ObjectDisposedException("ZlibStream");
				}
				this.stream0_0.flushType_0 = value;
			}
		}

		// Token: 0x1700004F RID: 79
		// (get) Token: 0x06000263 RID: 611 RVA: 0x00014208 File Offset: 0x00012408
		// (set) Token: 0x06000264 RID: 612 RVA: 0x00014224 File Offset: 0x00012424
		public int BufferSize
		{
			get
			{
				return this.stream0_0.int_0;
			}
			set
			{
				if (this.bool_0)
				{
					throw new ObjectDisposedException("ZlibStream");
				}
				if (this.stream0_0.byte_0 != null)
				{
					throw new ZlibException("The working buffer is already set.");
				}
				if (value < 1024)
				{
					throw new ZlibException(string.Format("Don't be silly. {0} bytes?? Use a bigger buffer, at least {1}.", value, 1024));
				}
				this.stream0_0.int_0 = value;
			}
		}

		// Token: 0x17000050 RID: 80
		// (get) Token: 0x06000265 RID: 613 RVA: 0x00014298 File Offset: 0x00012498
		public virtual long TotalIn
		{
			get
			{
				return this.stream0_0.zlibCodec_0.TotalBytesIn;
			}
		}

		// Token: 0x17000051 RID: 81
		// (get) Token: 0x06000266 RID: 614 RVA: 0x000142B8 File Offset: 0x000124B8
		public virtual long TotalOut
		{
			get
			{
				return this.stream0_0.zlibCodec_0.TotalBytesOut;
			}
		}

		// Token: 0x06000267 RID: 615 RVA: 0x000142D8 File Offset: 0x000124D8
		protected override void Dispose(bool disposing)
		{
			try
			{
				if (!this.bool_0)
				{
					if (disposing && this.stream0_0 != null)
					{
						this.stream0_0.Close();
					}
					this.bool_0 = true;
				}
			}
			finally
			{
				base.Dispose(disposing);
			}
		}

		// Token: 0x17000052 RID: 82
		// (get) Token: 0x06000268 RID: 616 RVA: 0x000058F2 File Offset: 0x00003AF2
		public override bool CanRead
		{
			get
			{
				if (this.bool_0)
				{
					throw new ObjectDisposedException("ZlibStream");
				}
				return this.stream0_0.stream_0.CanRead;
			}
		}

		// Token: 0x17000053 RID: 83
		// (get) Token: 0x06000269 RID: 617 RVA: 0x00005551 File Offset: 0x00003751
		public override bool CanSeek
		{
			get
			{
				return false;
			}
		}

		// Token: 0x17000054 RID: 84
		// (get) Token: 0x0600026A RID: 618 RVA: 0x00005917 File Offset: 0x00003B17
		public override bool CanWrite
		{
			get
			{
				if (this.bool_0)
				{
					throw new ObjectDisposedException("ZlibStream");
				}
				return this.stream0_0.stream_0.CanWrite;
			}
		}

		// Token: 0x0600026B RID: 619 RVA: 0x0000593C File Offset: 0x00003B3C
		public override void Flush()
		{
			if (this.bool_0)
			{
				throw new ObjectDisposedException("ZlibStream");
			}
			this.stream0_0.Flush();
		}

		// Token: 0x17000055 RID: 85
		// (get) Token: 0x0600026C RID: 620 RVA: 0x0000595C File Offset: 0x00003B5C
		public override long Length
		{
			get
			{
				throw new NotSupportedException();
			}
		}

		// Token: 0x17000056 RID: 86
		// (get) Token: 0x0600026D RID: 621 RVA: 0x00014330 File Offset: 0x00012530
		// (set) Token: 0x0600026E RID: 622 RVA: 0x0000595C File Offset: 0x00003B5C
		public override long Position
		{
			get
			{
				long result;
				if (this.stream0_0.enum8_0 == (Stream0.Enum8)0)
				{
					result = this.stream0_0.zlibCodec_0.TotalBytesOut;
				}
				else if (this.stream0_0.enum8_0 == (Stream0.Enum8)1)
				{
					result = this.stream0_0.zlibCodec_0.TotalBytesIn;
				}
				else
				{
					result = 0L;
				}
				return result;
			}
			set
			{
				throw new NotSupportedException();
			}
		}

		// Token: 0x0600026F RID: 623 RVA: 0x00014390 File Offset: 0x00012590
		public override int Read(byte[] buffer, int offset, int count)
		{
			if (this.bool_0)
			{
				throw new ObjectDisposedException("ZlibStream");
			}
			return this.stream0_0.Read(buffer, offset, count);
		}

		// Token: 0x06000270 RID: 624 RVA: 0x0000595C File Offset: 0x00003B5C
		public override long Seek(long offset, SeekOrigin origin)
		{
			throw new NotSupportedException();
		}

		// Token: 0x06000271 RID: 625 RVA: 0x0000595C File Offset: 0x00003B5C
		public override void SetLength(long value)
		{
			throw new NotSupportedException();
		}

		// Token: 0x06000272 RID: 626 RVA: 0x00005963 File Offset: 0x00003B63
		public override void Write(byte[] buffer, int offset, int count)
		{
			if (this.bool_0)
			{
				throw new ObjectDisposedException("ZlibStream");
			}
			this.stream0_0.Write(buffer, offset, count);
		}

		// Token: 0x06000273 RID: 627 RVA: 0x000143C0 File Offset: 0x000125C0
		public static byte[] CompressString(string s)
		{
			byte[] result;
			using (MemoryStream memoryStream = new MemoryStream())
			{
				Stream stream_ = new ZlibStream(memoryStream, CompressionMode.Compress, CompressionLevel.BestCompression);
				Stream0.smethod_0(s, stream_);
				result = memoryStream.ToArray();
			}
			return result;
		}

		// Token: 0x06000274 RID: 628 RVA: 0x00014408 File Offset: 0x00012608
		public static byte[] CompressBuffer(byte[] b)
		{
			byte[] result;
			using (MemoryStream memoryStream = new MemoryStream())
			{
				Stream stream_ = new ZlibStream(memoryStream, CompressionMode.Compress, CompressionLevel.BestCompression);
				Stream0.smethod_1(b, stream_);
				result = memoryStream.ToArray();
			}
			return result;
		}

		// Token: 0x06000275 RID: 629 RVA: 0x00014450 File Offset: 0x00012650
		public static string UncompressString(byte[] compressed)
		{
			string result;
			using (MemoryStream memoryStream = new MemoryStream(compressed))
			{
				Stream stream_ = new ZlibStream(memoryStream, CompressionMode.Decompress);
				result = Stream0.smethod_2(compressed, stream_);
			}
			return result;
		}

		// Token: 0x06000276 RID: 630 RVA: 0x00014494 File Offset: 0x00012694
		public static byte[] UncompressBuffer(byte[] compressed)
		{
			byte[] result;
			using (MemoryStream memoryStream = new MemoryStream(compressed))
			{
				Stream stream_ = new ZlibStream(memoryStream, CompressionMode.Decompress);
				result = Stream0.smethod_3(compressed, stream_);
			}
			return result;
		}

		// Token: 0x04000293 RID: 659
		internal Stream0 stream0_0;

		// Token: 0x04000294 RID: 660
		private bool bool_0;
	}
}
