﻿using System;

namespace Ionic.Zlib
{
	// Token: 0x0200007B RID: 123
	public enum CompressionLevel
	{
		// Token: 0x0400023B RID: 571
		None,
		// Token: 0x0400023C RID: 572
		Level0 = 0,
		// Token: 0x0400023D RID: 573
		BestSpeed,
		// Token: 0x0400023E RID: 574
		Level1 = 1,
		// Token: 0x0400023F RID: 575
		Level2,
		// Token: 0x04000240 RID: 576
		Level3,
		// Token: 0x04000241 RID: 577
		Level4,
		// Token: 0x04000242 RID: 578
		Level5,
		// Token: 0x04000243 RID: 579
		Default,
		// Token: 0x04000244 RID: 580
		Level6 = 6,
		// Token: 0x04000245 RID: 581
		Level7,
		// Token: 0x04000246 RID: 582
		Level8,
		// Token: 0x04000247 RID: 583
		BestCompression,
		// Token: 0x04000248 RID: 584
		Level9 = 9
	}
}
