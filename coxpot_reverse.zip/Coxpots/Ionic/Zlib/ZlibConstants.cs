﻿using System;

namespace Ionic.Zlib
{
	// Token: 0x02000087 RID: 135
	public static class ZlibConstants
	{
		// Token: 0x04000289 RID: 649
		public const int WindowBitsMax = 15;

		// Token: 0x0400028A RID: 650
		public const int WindowBitsDefault = 15;

		// Token: 0x0400028B RID: 651
		public const int Z_OK = 0;

		// Token: 0x0400028C RID: 652
		public const int Z_STREAM_END = 1;

		// Token: 0x0400028D RID: 653
		public const int Z_NEED_DICT = 2;

		// Token: 0x0400028E RID: 654
		public const int Z_STREAM_ERROR = -2;

		// Token: 0x0400028F RID: 655
		public const int Z_DATA_ERROR = -3;

		// Token: 0x04000290 RID: 656
		public const int Z_BUF_ERROR = -5;

		// Token: 0x04000291 RID: 657
		public const int WorkingBufferSizeDefault = 16384;

		// Token: 0x04000292 RID: 658
		public const int WorkingBufferSizeMin = 1024;
	}
}
