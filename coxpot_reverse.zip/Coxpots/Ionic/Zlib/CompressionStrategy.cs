﻿using System;

namespace Ionic.Zlib
{
	// Token: 0x0200007C RID: 124
	public enum CompressionStrategy
	{
		// Token: 0x0400024A RID: 586
		Default,
		// Token: 0x0400024B RID: 587
		Filtered,
		// Token: 0x0400024C RID: 588
		HuffmanOnly
	}
}
