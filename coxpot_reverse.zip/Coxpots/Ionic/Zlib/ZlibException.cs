﻿using System;
using System.Runtime.InteropServices;

namespace Ionic.Zlib
{
	// Token: 0x0200007E RID: 126
	[Guid("ebc25cf6-9120-4283-b972-0e5520d0000E")]
	public class ZlibException : Exception
	{
		// Token: 0x06000220 RID: 544 RVA: 0x00004848 File Offset: 0x00002A48
		public ZlibException()
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
		}

		// Token: 0x06000221 RID: 545 RVA: 0x00004855 File Offset: 0x00002A55
		public ZlibException(string s)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor(s);
		}
	}
}
