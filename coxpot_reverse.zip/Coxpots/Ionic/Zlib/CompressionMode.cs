﻿using System;

namespace Ionic.Zlib
{
	// Token: 0x0200007D RID: 125
	public enum CompressionMode
	{
		// Token: 0x0400024E RID: 590
		Compress,
		// Token: 0x0400024F RID: 591
		Decompress
	}
}
