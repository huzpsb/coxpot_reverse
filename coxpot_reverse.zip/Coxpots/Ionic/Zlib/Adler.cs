﻿using System;

namespace Ionic.Zlib
{
	// Token: 0x02000082 RID: 130
	public sealed class Adler
	{
		// Token: 0x0600022A RID: 554 RVA: 0x00012D2C File Offset: 0x00010F2C
		public static uint Adler32(uint adler, byte[] buf, int index, int len)
		{
			uint result;
			if (buf == null)
			{
				result = 1u;
			}
			else
			{
				uint num = adler & 65535u;
				uint num2 = adler >> 16 & 65535u;
				while (len > 0)
				{
					int i = (len < Adler.int_0) ? len : Adler.int_0;
					len -= i;
					while (i >= 16)
					{
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						num += (uint)buf[index++];
						num2 += num;
						i -= 16;
					}
					if (i != 0)
					{
						do
						{
							num += (uint)buf[index++];
							num2 += num;
						}
						while (--i != 0);
					}
					num %= Adler.uint_0;
					num2 %= Adler.uint_0;
				}
				result = (num2 << 16 | num);
			}
			return result;
		}

		// Token: 0x0600022B RID: 555 RVA: 0x0000480C File Offset: 0x00002A0C
		public Adler()
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
		}

		// Token: 0x0600022C RID: 556 RVA: 0x00005778 File Offset: 0x00003978
		static Adler()
		{
			Class35.NkAVmDjz8ZWXG();
			Adler.uint_0 = 65521u;
			Adler.int_0 = 5552;
		}

		// Token: 0x04000264 RID: 612
		private static readonly uint uint_0;

		// Token: 0x04000265 RID: 613
		private static readonly int int_0;
	}
}
