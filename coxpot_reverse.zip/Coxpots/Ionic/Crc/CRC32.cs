﻿using System;
using System.IO;
using System.Runtime.InteropServices;

namespace Ionic.Crc
{
	// Token: 0x02000089 RID: 137
	[ClassInterface(ClassInterfaceType.AutoDispatch)]
	[ComVisible(true)]
	[Guid("ebc25cf6-9120-4283-b972-0e5520d0000C")]
	public class CRC32
	{
		// Token: 0x17000057 RID: 87
		// (get) Token: 0x06000277 RID: 631 RVA: 0x000144D8 File Offset: 0x000126D8
		public long TotalBytesRead
		{
			get
			{
				return this.long_0;
			}
		}

		// Token: 0x17000058 RID: 88
		// (get) Token: 0x06000278 RID: 632 RVA: 0x000144F0 File Offset: 0x000126F0
		public int Int32_0
		{
			get
			{
				return (int)(~(int)this.uint_2);
			}
		}

		// Token: 0x06000279 RID: 633 RVA: 0x00014508 File Offset: 0x00012708
		public int GetCrc32(Stream input)
		{
			return this.GetCrc32AndCopy(input, null);
		}

		// Token: 0x0600027A RID: 634 RVA: 0x00014520 File Offset: 0x00012720
		public int GetCrc32AndCopy(Stream input, Stream output)
		{
			if (input == null)
			{
				throw new Exception("The input stream must not be null.");
			}
			byte[] array = new byte[8192];
			int count = 8192;
			this.long_0 = 0L;
			int i = input.Read(array, 0, 8192);
			if (output != null)
			{
				output.Write(array, 0, i);
			}
			this.long_0 += (long)i;
			while (i > 0)
			{
				this.SlurpBlock(array, 0, i);
				i = input.Read(array, 0, count);
				if (output != null)
				{
					output.Write(array, 0, i);
				}
				this.long_0 += (long)i;
			}
			return (int)(~(int)this.uint_2);
		}

		// Token: 0x0600027B RID: 635 RVA: 0x000145CC File Offset: 0x000127CC
		public int ComputeCrc32(int W, byte B)
		{
			return this.method_0((uint)W, B);
		}

		// Token: 0x0600027C RID: 636 RVA: 0x000145E4 File Offset: 0x000127E4
		internal int method_0(uint uint_3, byte byte_0)
		{
			return (int)(this.uint_1[(int)((uint_3 ^ (uint)byte_0) & 255u)] ^ uint_3 >> 8);
		}

		// Token: 0x0600027D RID: 637 RVA: 0x00014608 File Offset: 0x00012808
		public void SlurpBlock(byte[] block, int offset, int count)
		{
			if (block == null)
			{
				throw new Exception("The data buffer must not be null.");
			}
			for (int i = 0; i < count; i++)
			{
				int num = offset + i;
				byte b = block[num];
				if (this.bool_0)
				{
					uint num2 = this.uint_2 >> 24 ^ (uint)b;
					this.uint_2 = (this.uint_2 << 8 ^ this.uint_1[(int)num2]);
				}
				else
				{
					uint num3 = (this.uint_2 & 255u) ^ (uint)b;
					this.uint_2 = (this.uint_2 >> 8 ^ this.uint_1[(int)num3]);
				}
			}
			this.long_0 += (long)count;
		}

		// Token: 0x0600027E RID: 638 RVA: 0x000146A0 File Offset: 0x000128A0
		public void method_1(byte b)
		{
			if (this.bool_0)
			{
				uint num = this.uint_2 >> 24 ^ (uint)b;
				this.uint_2 = (this.uint_2 << 8 ^ this.uint_1[(int)num]);
			}
			else
			{
				uint num2 = (this.uint_2 & 255u) ^ (uint)b;
				this.uint_2 = (this.uint_2 >> 8 ^ this.uint_1[(int)num2]);
			}
		}

		// Token: 0x0600027F RID: 639 RVA: 0x00014700 File Offset: 0x00012900
		public void method_2(byte b, int n)
		{
			while (n-- > 0)
			{
				if (this.bool_0)
				{
					uint num = this.uint_2 >> 24 ^ (uint)b;
					this.uint_2 = (this.uint_2 << 8 ^ this.uint_1[(int)num]);
				}
				else
				{
					uint num2 = (this.uint_2 & 255u) ^ (uint)b;
					this.uint_2 = (this.uint_2 >> 8 ^ this.uint_1[(int)num2]);
				}
			}
		}

		// Token: 0x06000280 RID: 640 RVA: 0x00014770 File Offset: 0x00012970
		private static uint smethod_0(uint uint_3)
		{
			uint num = (uint_3 & 1431655765u) << 1 | (uint_3 >> 1 & 1431655765u);
			num = ((num & 858993459u) << 2 | (num >> 2 & 858993459u));
			num = ((num & 252645135u) << 4 | (num >> 4 & 252645135u));
			return num << 24 | (num & 65280u) << 8 | (num >> 8 & 65280u) | num >> 24;
		}

		// Token: 0x06000281 RID: 641 RVA: 0x000147DC File Offset: 0x000129DC
		private static byte smethod_1(byte byte_0)
		{
			uint num = (uint)byte_0 * 131586u;
			uint num2 = num & 17055760u;
			uint num3 = num << 2 & 34111520u;
			return (byte)(16781313u * (num2 + num3) >> 24);
		}

		// Token: 0x06000282 RID: 642 RVA: 0x00014814 File Offset: 0x00012A14
		private void method_3()
		{
			this.uint_1 = new uint[256];
			byte b = 0;
			do
			{
				uint num = (uint)b;
				for (byte b2 = 8; b2 > 0; b2 -= 1)
				{
					if ((num & 1u) == 1u)
					{
						num = (num >> 1 ^ this.uint_0);
					}
					else
					{
						num >>= 1;
					}
				}
				if (this.bool_0)
				{
					this.uint_1[(int)CRC32.smethod_1(b)] = CRC32.smethod_0(num);
				}
				else
				{
					this.uint_1[(int)b] = num;
				}
				b += 1;
			}
			while (b > 0);
		}

		// Token: 0x06000283 RID: 643 RVA: 0x00014890 File Offset: 0x00012A90
		private uint method_4(uint[] uint_3, uint uint_4)
		{
			uint num = 0u;
			int num2 = 0;
			while (uint_4 > 0u)
			{
				if ((uint_4 & 1u) == 1u)
				{
					num ^= uint_3[num2];
				}
				uint_4 >>= 1;
				num2++;
			}
			return num;
		}

		// Token: 0x06000284 RID: 644 RVA: 0x000148C4 File Offset: 0x00012AC4
		private void method_5(uint[] uint_3, uint[] uint_4)
		{
			for (int i = 0; i < 32; i++)
			{
				uint_3[i] = this.method_4(uint_4, uint_4[i]);
			}
		}

		// Token: 0x06000285 RID: 645 RVA: 0x000148F0 File Offset: 0x00012AF0
		public void Combine(int crc, int length)
		{
			uint[] array = new uint[32];
			uint[] array2 = new uint[32];
			if (length != 0)
			{
				uint num = ~this.uint_2;
				array2[0] = this.uint_0;
				uint num2 = 1u;
				for (int i = 1; i < 32; i++)
				{
					array2[i] = num2;
					num2 <<= 1;
				}
				this.method_5(array, array2);
				this.method_5(array2, array);
				uint num3 = (uint)length;
				do
				{
					this.method_5(array, array2);
					if ((num3 & 1u) == 1u)
					{
						num = this.method_4(array, num);
					}
					num3 >>= 1;
					if (num3 == 0u)
					{
						break;
					}
					this.method_5(array2, array);
					if ((num3 & 1u) == 1u)
					{
						num = this.method_4(array2, num);
					}
					num3 >>= 1;
				}
				while (num3 > 0u);
				num ^= (uint)crc;
				this.uint_2 = ~num;
			}
		}

		// Token: 0x06000286 RID: 646 RVA: 0x00005986 File Offset: 0x00003B86
		public CRC32()
		{
			Class35.NkAVmDjz8ZWXG();
			this..ctor(false);
		}

		// Token: 0x06000287 RID: 647 RVA: 0x00005994 File Offset: 0x00003B94
		public CRC32(bool reverseBits)
		{
			Class35.NkAVmDjz8ZWXG();
			this..ctor(-306674912, reverseBits);
		}

		// Token: 0x06000288 RID: 648 RVA: 0x000059A7 File Offset: 0x00003BA7
		public CRC32(int polynomial, bool reverseBits)
		{
			Class35.NkAVmDjz8ZWXG();
			this.uint_2 = uint.MaxValue;
			base..ctor();
			this.bool_0 = reverseBits;
			this.uint_0 = (uint)polynomial;
			this.method_3();
		}

		// Token: 0x06000289 RID: 649 RVA: 0x000059CF File Offset: 0x00003BCF
		public void Reset()
		{
			this.uint_2 = uint.MaxValue;
		}

		// Token: 0x04000295 RID: 661
		private uint uint_0;

		// Token: 0x04000296 RID: 662
		private long long_0;

		// Token: 0x04000297 RID: 663
		private bool bool_0;

		// Token: 0x04000298 RID: 664
		private uint[] uint_1;

		// Token: 0x04000299 RID: 665
		private uint uint_2;
	}
}
