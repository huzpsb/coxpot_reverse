﻿using System;
using System.IO;

namespace Ionic.Crc
{
	// Token: 0x0200008A RID: 138
	public class CrcCalculatorStream : Stream, IDisposable
	{
		// Token: 0x0600028A RID: 650 RVA: 0x000059D8 File Offset: 0x00003BD8
		public CrcCalculatorStream(Stream stream)
		{
			Class35.NkAVmDjz8ZWXG();
			this..ctor(true, CrcCalculatorStream.long_0, stream, null);
		}

		// Token: 0x0600028B RID: 651 RVA: 0x000059ED File Offset: 0x00003BED
		public CrcCalculatorStream(Stream stream, bool leaveOpen)
		{
			Class35.NkAVmDjz8ZWXG();
			this..ctor(leaveOpen, CrcCalculatorStream.long_0, stream, null);
		}

		// Token: 0x0600028C RID: 652 RVA: 0x00005A02 File Offset: 0x00003C02
		public CrcCalculatorStream(Stream stream, long length)
		{
			Class35.NkAVmDjz8ZWXG();
			this..ctor(true, length, stream, null);
			if (length < 0L)
			{
				throw new ArgumentException("length");
			}
		}

		// Token: 0x0600028D RID: 653 RVA: 0x00005A2C File Offset: 0x00003C2C
		public CrcCalculatorStream(Stream stream, long length, bool leaveOpen)
		{
			Class35.NkAVmDjz8ZWXG();
			this..ctor(leaveOpen, length, stream, null);
			if (length < 0L)
			{
				throw new ArgumentException("length");
			}
		}

		// Token: 0x0600028E RID: 654 RVA: 0x00005A56 File Offset: 0x00003C56
		public CrcCalculatorStream(Stream stream, long length, bool leaveOpen, CRC32 crc32)
		{
			Class35.NkAVmDjz8ZWXG();
			this..ctor(leaveOpen, length, stream, crc32);
			if (length < 0L)
			{
				throw new ArgumentException("length");
			}
		}

		// Token: 0x0600028F RID: 655 RVA: 0x000149BC File Offset: 0x00012BBC
		private CrcCalculatorStream(bool leaveOpen, long length, Stream stream, CRC32 crc32)
		{
			Class35.NkAVmDjz8ZWXG();
			this.long_1 = -99L;
			base..ctor();
			this.stream_0 = stream;
			this.crc32_0 = (crc32 ?? new CRC32());
			this.long_1 = length;
			this.bool_0 = leaveOpen;
		}

		// Token: 0x17000059 RID: 89
		// (get) Token: 0x06000290 RID: 656 RVA: 0x00014A0C File Offset: 0x00012C0C
		public long TotalBytesSlurped
		{
			get
			{
				return this.crc32_0.TotalBytesRead;
			}
		}

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x06000291 RID: 657 RVA: 0x00014A28 File Offset: 0x00012C28
		public int Crc
		{
			get
			{
				return this.crc32_0.Int32_0;
			}
		}

		// Token: 0x1700005B RID: 91
		// (get) Token: 0x06000292 RID: 658 RVA: 0x00005A81 File Offset: 0x00003C81
		// (set) Token: 0x06000293 RID: 659 RVA: 0x00005A89 File Offset: 0x00003C89
		public bool LeaveOpen
		{
			get
			{
				return this.bool_0;
			}
			set
			{
				this.bool_0 = value;
			}
		}

		// Token: 0x06000294 RID: 660 RVA: 0x00014A44 File Offset: 0x00012C44
		public override int Read(byte[] buffer, int offset, int count)
		{
			int count2 = count;
			if (this.long_1 != CrcCalculatorStream.long_0)
			{
				if (this.crc32_0.TotalBytesRead >= this.long_1)
				{
					return 0;
				}
				long num = this.long_1 - this.crc32_0.TotalBytesRead;
				if (num < (long)count)
				{
					count2 = (int)num;
				}
			}
			int num2 = this.stream_0.Read(buffer, offset, count2);
			if (num2 > 0)
			{
				this.crc32_0.SlurpBlock(buffer, offset, num2);
			}
			return num2;
		}

		// Token: 0x06000295 RID: 661 RVA: 0x00005A92 File Offset: 0x00003C92
		public override void Write(byte[] buffer, int offset, int count)
		{
			if (count > 0)
			{
				this.crc32_0.SlurpBlock(buffer, offset, count);
			}
			this.stream_0.Write(buffer, offset, count);
		}

		// Token: 0x1700005C RID: 92
		// (get) Token: 0x06000296 RID: 662 RVA: 0x00005AB6 File Offset: 0x00003CB6
		public override bool CanRead
		{
			get
			{
				return this.stream_0.CanRead;
			}
		}

		// Token: 0x1700005D RID: 93
		// (get) Token: 0x06000297 RID: 663 RVA: 0x00005551 File Offset: 0x00003751
		public override bool CanSeek
		{
			get
			{
				return false;
			}
		}

		// Token: 0x1700005E RID: 94
		// (get) Token: 0x06000298 RID: 664 RVA: 0x00005AC3 File Offset: 0x00003CC3
		public override bool CanWrite
		{
			get
			{
				return this.stream_0.CanWrite;
			}
		}

		// Token: 0x06000299 RID: 665 RVA: 0x00005AD0 File Offset: 0x00003CD0
		public override void Flush()
		{
			this.stream_0.Flush();
		}

		// Token: 0x1700005F RID: 95
		// (get) Token: 0x0600029A RID: 666 RVA: 0x00014AC4 File Offset: 0x00012CC4
		public override long Length
		{
			get
			{
				long length;
				if (this.long_1 == CrcCalculatorStream.long_0)
				{
					length = this.stream_0.Length;
				}
				else
				{
					length = this.long_1;
				}
				return length;
			}
		}

		// Token: 0x17000060 RID: 96
		// (get) Token: 0x0600029B RID: 667 RVA: 0x00014A0C File Offset: 0x00012C0C
		// (set) Token: 0x0600029C RID: 668 RVA: 0x0000595C File Offset: 0x00003B5C
		public override long Position
		{
			get
			{
				return this.crc32_0.TotalBytesRead;
			}
			set
			{
				throw new NotSupportedException();
			}
		}

		// Token: 0x0600029D RID: 669 RVA: 0x0000595C File Offset: 0x00003B5C
		public override long Seek(long offset, SeekOrigin origin)
		{
			throw new NotSupportedException();
		}

		// Token: 0x0600029E RID: 670 RVA: 0x0000595C File Offset: 0x00003B5C
		public override void SetLength(long value)
		{
			throw new NotSupportedException();
		}

		// Token: 0x0600029F RID: 671 RVA: 0x00005ADD File Offset: 0x00003CDD
		void IDisposable.Dispose()
		{
			this.Close();
		}

		// Token: 0x060002A0 RID: 672 RVA: 0x00005AE5 File Offset: 0x00003CE5
		public override void Close()
		{
			base.Close();
			if (!this.bool_0)
			{
				this.stream_0.Close();
			}
		}

		// Token: 0x060002A1 RID: 673 RVA: 0x00005B03 File Offset: 0x00003D03
		static CrcCalculatorStream()
		{
			Class35.NkAVmDjz8ZWXG();
			CrcCalculatorStream.long_0 = -99L;
		}

		// Token: 0x0400029A RID: 666
		private static readonly long long_0;

		// Token: 0x0400029B RID: 667
		internal Stream stream_0;

		// Token: 0x0400029C RID: 668
		private CRC32 crc32_0;

		// Token: 0x0400029D RID: 669
		private long long_1;

		// Token: 0x0400029E RID: 670
		private bool bool_0;
	}
}
