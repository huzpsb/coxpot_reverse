﻿using System;

// Token: 0x020000BF RID: 191
internal class Class35
{
	// Token: 0x060003A1 RID: 929 RVA: 0x0000606C File Offset: 0x0000426C
	internal static void NkAVmDjz8ZWXG()
	{
	}

	// Token: 0x0400032E RID: 814
	private static bool bool_0;
}
