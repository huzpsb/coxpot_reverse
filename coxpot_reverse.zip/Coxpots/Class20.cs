﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Threading;
using Coxpots;
using Coxpots.Protocol.Server;

// Token: 0x02000092 RID: 146
internal class Class20
{
	// Token: 0x060002BB RID: 699 RVA: 0x00015AD8 File Offset: 0x00013CD8
	private static void Main(string[] args)
	{
		Setting.LoadDefault();
		if (args.Length != 0)
		{
			string string_ = string.Empty;
			foreach (string text in args)
			{
				if (text.StartsWith("host:"))
				{
					string_ = text.Replace("host:", "");
				}
			}
			List<string> list = new List<string>();
			list.AddRange(File.ReadAllText(Setting.chatlist, Encoding.UTF8).Split(new char[]
			{
				'\n'
			}));
			Class18.smethod_3(string_);
			ServerInfo serverInfo = new ServerInfo(Class18.string_0, Class18.int_0);
			if (serverInfo.method_0())
			{
				Class28 @class = new Class28(serverInfo, Setting.name, Setting.threads, list, 0);
				@class.method_0(0);
			}
		}
		else
		{
			Class20.smethod_0();
		}
	}

	// Token: 0x060002BC RID: 700 RVA: 0x00015BA0 File Offset: 0x00013DA0
	private static void smethod_0()
	{
		string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
		if (!File.Exists(baseDirectory + "list.txt"))
		{
			Console.WriteLine("检测到目录缺少语言文本.将自动给你生成一份哦");
			StreamWriter streamWriter = new StreamWriter(new FileStream(baseDirectory + "list.txt", FileMode.CreateNew));
			streamWriter.Write("/reg 132465798 132465798\n欢迎使用黑河最新代理集群压测");
			streamWriter.Flush();
			Console.WriteLine("生成完成.");
			Thread.Sleep(1000);
			Console.ReadLine();
			return;
		}
		if (!Class20.smethod_8("http://lksf.13x.top/a/1578254549.zip"))
		{
			Console.WriteLine("数据接收成功.欢迎进入");
			Console.WriteLine("huzpsb破解.什么混淆都是弟弟.");
			Thread.Sleep(1000);
			Console.Clear();
			Class20.smethod_1();
			return;
		}
		Console.WriteLine("数据接收失败");
		Console.WriteLine("当前版本已经失效.具体原因请联系QQ1612275520");
		Console.ReadKey();
	}

	// Token: 0x060002BD RID: 701 RVA: 0x00015C64 File Offset: 0x00013E64
	public static void smethod_1()
	{
		Console.ForegroundColor = ConsoleColor.DarkGray;
		Console.WriteLine("");
		Console.WriteLine("==================================");
		Console.ForegroundColor = ConsoleColor.White;
		Console.WriteLine(">> 1:压测系统");
		Console.WriteLine(">> 2:查询信息");
		Console.WriteLine(">> 3:Srv");
		Console.WriteLine(">> 4:检测服务器端口");
		Console.WriteLine(">> Cracked by huzpsb");
		Console.ForegroundColor = ConsoleColor.DarkGray;
		Console.WriteLine("==================================");
		Console.ForegroundColor = ConsoleColor.Gray;
		Console.Write(">> ");
		switch (Convert.ToInt32(Console.ReadLine()))
		{
		case 1:
			Console.Clear();
			Class18.smethod_0();
			return;
		case 2:
			Console.Clear();
			Class14.smethod_0();
			return;
		case 3:
			Console.Clear();
			Pin.SetServerIP(null);
			return;
		case 4:
			Console.Clear();
			Class13.smethod_0();
			return;
		case 5:
			Console.Clear();
			end2535.End253();
			return;
		default:
			Console.WriteLine("选择错误哦,请重新选择叭");
			Thread.Sleep(1000);
			Console.Clear();
			Class20.smethod_1();
			return;
		}
	}

	// Token: 0x060002BE RID: 702 RVA: 0x00015D64 File Offset: 0x00013F64
	private static void smethod_2()
	{
		string ip = "127.0.0.1";
		string string_ = "%RANDOM%";
		int int_ = 500;
		List<string> list = new List<string>();
		list.Add("仅供测试！");
		ServerInfo serverInfo = new ServerInfo(ip, 25565);
		if (serverInfo.method_0())
		{
			Class28 @class = new Class28(serverInfo, string_, int_, list, 0);
			@class.method_0(0);
		}
	}

	// Token: 0x060002BF RID: 703 RVA: 0x00005BCB File Offset: 0x00003DCB
	public static void smethod_3()
	{
		Console.WriteLine("按任意键退出...");
		Console.ReadKey();
		Environment.Exit(0);
	}

	// Token: 0x060002C0 RID: 704 RVA: 0x00015DC0 File Offset: 0x00013FC0
	private static bool smethod_4(string string_0)
	{
		bool result;
		try
		{
			HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.CreateDefault(new Uri(string_0));
			httpWebRequest.Method = "HEAD";
			httpWebRequest.Timeout = 1000;
			result = (((HttpWebResponse)httpWebRequest.GetResponse()).StatusCode == HttpStatusCode.OK);
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x060002C1 RID: 705 RVA: 0x00015E28 File Offset: 0x00014028
	private static int smethod_5(string string_0)
	{
		if (string_0.Length > 1)
		{
			HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(new Uri(string_0));
			ServicePointManager.Expect100Continue = false;
			try
			{
				((HttpWebResponse)httpWebRequest.GetResponse()).Close();
			}
			catch (WebException ex)
			{
				if (ex.Status != WebExceptionStatus.ProtocolError)
				{
					return 1;
				}
				if (ex.Message.IndexOf("500") > 0)
				{
					return 500;
				}
				if (ex.Message.IndexOf("401") > 0)
				{
					return 401;
				}
				if (ex.Message.IndexOf("404") > 0)
				{
					return 404;
				}
			}
		}
		return 1;
	}

	// Token: 0x060002C2 RID: 706 RVA: 0x00015EEC File Offset: 0x000140EC
	private static bool smethod_6(string string_0)
	{
		bool result = false;
		WebResponse webResponse = null;
		try
		{
			WebRequest webRequest = WebRequest.Create(string_0);
			webResponse = webRequest.GetResponse();
			result = (webResponse != null);
		}
		catch (Exception)
		{
			result = false;
		}
		finally
		{
			if (webResponse != null)
			{
				webResponse.Close();
			}
		}
		return result;
	}

	// Token: 0x060002C3 RID: 707 RVA: 0x00015DC0 File Offset: 0x00013FC0
	private static bool smethod_7(string string_0)
	{
		bool result;
		try
		{
			HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.CreateDefault(new Uri(string_0));
			httpWebRequest.Method = "HEAD";
			httpWebRequest.Timeout = 1000;
			result = (((HttpWebResponse)httpWebRequest.GetResponse()).StatusCode == HttpStatusCode.OK);
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x060002C4 RID: 708 RVA: 0x00015F48 File Offset: 0x00014148
	private static bool smethod_8(string string_0)
	{
		bool result;
		try
		{
			using (new WebClient().OpenRead(string_0))
			{
			}
			result = true;
		}
		catch (WebException)
		{
			result = false;
		}
		return result;
	}

	// Token: 0x060002C5 RID: 709 RVA: 0x0000480C File Offset: 0x00002A0C
	public Class20()
	{
		Class35.NkAVmDjz8ZWXG();
		base..ctor();
	}
}
