﻿using System;
using Ionic.Zlib;

// Token: 0x02000075 RID: 117
internal sealed class Class6
{
	// Token: 0x06000202 RID: 514 RVA: 0x0000561E File Offset: 0x0000381E
	internal Class6()
	{
		Class35.NkAVmDjz8ZWXG();
		this.int_2 = 0;
		base..ctor();
	}

	// Token: 0x06000203 RID: 515 RVA: 0x00005632 File Offset: 0x00003832
	internal void method_0(int int_11, int int_12, int[] int_13, int int_14, int[] int_15, int int_16)
	{
		this.goKtrnweCF = 0;
		this.byte_0 = (byte)int_11;
		this.byte_1 = (byte)int_12;
		this.int_7 = int_13;
		this.int_8 = int_14;
		this.int_9 = int_15;
		this.int_10 = int_16;
		this.int_1 = null;
	}

	// Token: 0x06000204 RID: 516 RVA: 0x00010168 File Offset: 0x0000E368
	internal int method_1(Class4 class4_0, int int_11)
	{
		ZlibCodec zlibCodec_ = class4_0.zlibCodec_0;
		int num = zlibCodec_.NextIn;
		int num2 = zlibCodec_.AvailableBytesIn;
		int num3 = class4_0.int_8;
		int i = class4_0.int_7;
		int num4 = class4_0.int_12;
		int num5 = (num4 < class4_0.int_11) ? (class4_0.int_11 - num4 - 1) : (class4_0.int_10 - num4);
		for (;;)
		{
			int num6;
			switch (this.goKtrnweCF)
			{
			case 0:
				if (num5 >= 258 && num2 >= 10)
				{
					class4_0.int_8 = num3;
					class4_0.int_7 = i;
					zlibCodec_.AvailableBytesIn = num2;
					zlibCodec_.TotalBytesIn += (long)(num - zlibCodec_.NextIn);
					zlibCodec_.NextIn = num;
					class4_0.int_12 = num4;
					int_11 = this.method_2((int)this.byte_0, (int)this.byte_1, this.int_7, this.int_8, this.int_9, this.int_10, class4_0, zlibCodec_);
					num = zlibCodec_.NextIn;
					num2 = zlibCodec_.AvailableBytesIn;
					num3 = class4_0.int_8;
					i = class4_0.int_7;
					num4 = class4_0.int_12;
					num5 = ((num4 < class4_0.int_11) ? (class4_0.int_11 - num4 - 1) : (class4_0.int_10 - num4));
					if (int_11 != 0)
					{
						this.goKtrnweCF = ((int_11 == 1) ? 7 : 9);
						continue;
					}
				}
				this.int_3 = (int)this.byte_0;
				this.int_1 = this.int_7;
				this.int_2 = this.int_8;
				this.goKtrnweCF = 1;
				goto IL_48D;
			case 1:
				goto IL_48D;
			case 2:
				num6 = this.int_5;
				while (i < num6)
				{
					if (num2 == 0)
					{
						goto IL_7EE;
					}
					int_11 = 0;
					num2--;
					num3 |= (int)(zlibCodec_.InputBuffer[num++] & byte.MaxValue) << i;
					i += 8;
				}
				this.int_0 += (num3 & Class5.int_0[num6]);
				num3 >>= num6;
				i -= num6;
				this.int_3 = (int)this.byte_1;
				this.int_1 = this.int_9;
				this.int_2 = this.int_10;
				this.goKtrnweCF = 3;
				goto IL_314;
			case 3:
				goto IL_314;
			case 4:
				num6 = this.int_5;
				while (i < num6)
				{
					if (num2 == 0)
					{
						goto IL_8E1;
					}
					int_11 = 0;
					num2--;
					num3 |= (int)(zlibCodec_.InputBuffer[num++] & byte.MaxValue) << i;
					i += 8;
				}
				this.int_6 += (num3 & Class5.int_0[num6]);
				num3 >>= num6;
				i -= num6;
				this.goKtrnweCF = 5;
				goto IL_154;
			case 5:
				goto IL_154;
			case 6:
				if (num5 == 0)
				{
					if (num4 == class4_0.int_10 && class4_0.int_11 != 0)
					{
						num4 = 0;
						num5 = ((0 < class4_0.int_11) ? (class4_0.int_11 - num4 - 1) : (class4_0.int_10 - num4));
					}
					if (num5 == 0)
					{
						class4_0.int_12 = num4;
						int_11 = class4_0.method_4(int_11);
						num4 = class4_0.int_12;
						num5 = ((num4 < class4_0.int_11) ? (class4_0.int_11 - num4 - 1) : (class4_0.int_10 - num4));
						if (num4 == class4_0.int_10 && class4_0.int_11 != 0)
						{
							num4 = 0;
							num5 = ((0 < class4_0.int_11) ? (class4_0.int_11 - num4 - 1) : (class4_0.int_10 - num4));
						}
						if (num5 == 0)
						{
							goto IL_973;
						}
					}
				}
				int_11 = 0;
				class4_0.byte_0[num4++] = (byte)this.int_4;
				num5--;
				this.goKtrnweCF = 0;
				continue;
			case 7:
				goto IL_9BC;
			case 8:
				goto IL_A6E;
			case 9:
				goto IL_AB7;
			}
			break;
			IL_154:
			int j;
			for (j = num4 - this.int_6; j < 0; j += class4_0.int_10)
			{
			}
			while (this.int_0 != 0)
			{
				if (num5 == 0)
				{
					if (num4 == class4_0.int_10 && class4_0.int_11 != 0)
					{
						num4 = 0;
						num5 = ((0 < class4_0.int_11) ? (class4_0.int_11 - num4 - 1) : (class4_0.int_10 - num4));
					}
					if (num5 == 0)
					{
						class4_0.int_12 = num4;
						int_11 = class4_0.method_4(int_11);
						num4 = class4_0.int_12;
						num5 = ((num4 < class4_0.int_11) ? (class4_0.int_11 - num4 - 1) : (class4_0.int_10 - num4));
						if (num4 == class4_0.int_10 && class4_0.int_11 != 0)
						{
							num4 = 0;
							num5 = ((0 < class4_0.int_11) ? (class4_0.int_11 - num4 - 1) : (class4_0.int_10 - num4));
						}
						if (num5 == 0)
						{
							goto IL_92A;
						}
					}
				}
				class4_0.byte_0[num4++] = class4_0.byte_0[j++];
				num5--;
				if (j == class4_0.int_10)
				{
					j = 0;
				}
				this.int_0--;
			}
			this.goKtrnweCF = 0;
			continue;
			IL_314:
			num6 = this.int_3;
			while (i < num6)
			{
				if (num2 == 0)
				{
					goto IL_898;
				}
				int_11 = 0;
				num2--;
				num3 |= (int)(zlibCodec_.InputBuffer[num++] & byte.MaxValue) << i;
				i += 8;
			}
			int num7 = (this.int_2 + (num3 & Class5.int_0[num6])) * 3;
			num3 >>= this.int_1[num7 + 1];
			i -= this.int_1[num7 + 1];
			int num8 = this.int_1[num7];
			if ((num8 & 16) != 0)
			{
				this.int_5 = (num8 & 15);
				this.int_6 = this.int_1[num7 + 2];
				this.goKtrnweCF = 4;
				continue;
			}
			if ((num8 & 64) == 0)
			{
				this.int_3 = num8;
				this.int_2 = num7 / 3 + this.int_1[num7 + 2];
				continue;
			}
			goto IL_837;
			IL_48D:
			num6 = this.int_3;
			while (i < num6)
			{
				if (num2 == 0)
				{
					goto IL_7A5;
				}
				int_11 = 0;
				num2--;
				num3 |= (int)(zlibCodec_.InputBuffer[num++] & byte.MaxValue) << i;
				i += 8;
			}
			num7 = (this.int_2 + (num3 & Class5.int_0[num6])) * 3;
			num3 >>= this.int_1[num7 + 1];
			i -= this.int_1[num7 + 1];
			num8 = this.int_1[num7];
			if (num8 == 0)
			{
				this.int_4 = this.int_1[num7 + 2];
				this.goKtrnweCF = 6;
			}
			else if ((num8 & 16) != 0)
			{
				this.int_5 = (num8 & 15);
				this.int_0 = this.int_1[num7 + 2];
				this.goKtrnweCF = 2;
			}
			else if ((num8 & 64) == 0)
			{
				this.int_3 = num8;
				this.int_2 = num7 / 3 + this.int_1[num7 + 2];
			}
			else
			{
				if ((num8 & 32) == 0)
				{
					goto IL_744;
				}
				this.goKtrnweCF = 7;
			}
		}
		int_11 = -2;
		class4_0.int_8 = num3;
		class4_0.int_7 = i;
		zlibCodec_.AvailableBytesIn = num2;
		zlibCodec_.TotalBytesIn += (long)(num - zlibCodec_.NextIn);
		zlibCodec_.NextIn = num;
		class4_0.int_12 = num4;
		return class4_0.method_4(-2);
		IL_744:
		this.goKtrnweCF = 9;
		zlibCodec_.Message = "invalid literal/length code";
		int_11 = -3;
		class4_0.int_8 = num3;
		class4_0.int_7 = i;
		zlibCodec_.AvailableBytesIn = num2;
		zlibCodec_.TotalBytesIn += (long)(num - zlibCodec_.NextIn);
		zlibCodec_.NextIn = num;
		class4_0.int_12 = num4;
		return class4_0.method_4(-3);
		IL_7A5:
		class4_0.int_8 = num3;
		class4_0.int_7 = i;
		zlibCodec_.AvailableBytesIn = num2;
		zlibCodec_.TotalBytesIn += (long)(num - zlibCodec_.NextIn);
		zlibCodec_.NextIn = num;
		class4_0.int_12 = num4;
		return class4_0.method_4(int_11);
		IL_7EE:
		class4_0.int_8 = num3;
		class4_0.int_7 = i;
		zlibCodec_.AvailableBytesIn = num2;
		zlibCodec_.TotalBytesIn += (long)(num - zlibCodec_.NextIn);
		zlibCodec_.NextIn = num;
		class4_0.int_12 = num4;
		return class4_0.method_4(int_11);
		IL_837:
		this.goKtrnweCF = 9;
		zlibCodec_.Message = "invalid distance code";
		int_11 = -3;
		class4_0.int_8 = num3;
		class4_0.int_7 = i;
		zlibCodec_.AvailableBytesIn = num2;
		zlibCodec_.TotalBytesIn += (long)(num - zlibCodec_.NextIn);
		zlibCodec_.NextIn = num;
		class4_0.int_12 = num4;
		return class4_0.method_4(-3);
		IL_898:
		class4_0.int_8 = num3;
		class4_0.int_7 = i;
		zlibCodec_.AvailableBytesIn = num2;
		zlibCodec_.TotalBytesIn += (long)(num - zlibCodec_.NextIn);
		zlibCodec_.NextIn = num;
		class4_0.int_12 = num4;
		return class4_0.method_4(int_11);
		IL_8E1:
		class4_0.int_8 = num3;
		class4_0.int_7 = i;
		zlibCodec_.AvailableBytesIn = num2;
		zlibCodec_.TotalBytesIn += (long)(num - zlibCodec_.NextIn);
		zlibCodec_.NextIn = num;
		class4_0.int_12 = num4;
		return class4_0.method_4(int_11);
		IL_92A:
		class4_0.int_8 = num3;
		class4_0.int_7 = i;
		zlibCodec_.AvailableBytesIn = num2;
		zlibCodec_.TotalBytesIn += (long)(num - zlibCodec_.NextIn);
		zlibCodec_.NextIn = num;
		class4_0.int_12 = num4;
		return class4_0.method_4(int_11);
		IL_973:
		class4_0.int_8 = num3;
		class4_0.int_7 = i;
		zlibCodec_.AvailableBytesIn = num2;
		zlibCodec_.TotalBytesIn += (long)(num - zlibCodec_.NextIn);
		zlibCodec_.NextIn = num;
		class4_0.int_12 = num4;
		return class4_0.method_4(int_11);
		IL_9BC:
		if (i > 7)
		{
			i -= 8;
			num2++;
			num--;
		}
		class4_0.int_12 = num4;
		int_11 = class4_0.method_4(int_11);
		num4 = class4_0.int_12;
		int num9 = (num4 < class4_0.int_11) ? (class4_0.int_11 - num4 - 1) : (class4_0.int_10 - num4);
		if (class4_0.int_11 != class4_0.int_12)
		{
			class4_0.int_8 = num3;
			class4_0.int_7 = i;
			zlibCodec_.AvailableBytesIn = num2;
			zlibCodec_.TotalBytesIn += (long)(num - zlibCodec_.NextIn);
			zlibCodec_.NextIn = num;
			class4_0.int_12 = num4;
			return class4_0.method_4(int_11);
		}
		this.goKtrnweCF = 8;
		IL_A6E:
		int_11 = 1;
		class4_0.int_8 = num3;
		class4_0.int_7 = i;
		zlibCodec_.AvailableBytesIn = num2;
		zlibCodec_.TotalBytesIn += (long)(num - zlibCodec_.NextIn);
		zlibCodec_.NextIn = num;
		class4_0.int_12 = num4;
		return class4_0.method_4(1);
		IL_AB7:
		int_11 = -3;
		class4_0.int_8 = num3;
		class4_0.int_7 = i;
		zlibCodec_.AvailableBytesIn = num2;
		zlibCodec_.TotalBytesIn += (long)(num - zlibCodec_.NextIn);
		zlibCodec_.NextIn = num;
		class4_0.int_12 = num4;
		return class4_0.method_4(-3);
	}

	// Token: 0x06000205 RID: 517 RVA: 0x00010C78 File Offset: 0x0000EE78
	internal int method_2(int int_11, int int_12, int[] int_13, int int_14, int[] int_15, int int_16, Class4 class4_0, ZlibCodec zlibCodec_0)
	{
		int num = zlibCodec_0.NextIn;
		int num2 = zlibCodec_0.AvailableBytesIn;
		int num3 = class4_0.int_8;
		int i = class4_0.int_7;
		int num4 = class4_0.int_12;
		int num5 = (num4 < class4_0.int_11) ? (class4_0.int_11 - num4 - 1) : (class4_0.int_10 - num4);
		int num6 = Class5.int_0[int_11];
		int num7 = Class5.int_0[int_12];
		int num10;
		int num11;
		for (;;)
		{
			if (i >= 20)
			{
				int num8 = num3 & num6;
				int num9 = (int_14 + num8) * 3;
				if ((num10 = int_13[num9]) == 0)
				{
					num3 >>= int_13[num9 + 1];
					i -= int_13[num9 + 1];
					class4_0.byte_0[num4++] = (byte)int_13[num9 + 2];
					num5--;
				}
				else
				{
					for (;;)
					{
						num3 >>= int_13[num9 + 1];
						i -= int_13[num9 + 1];
						if ((num10 & 16) != 0)
						{
							break;
						}
						if ((num10 & 64) != 0)
						{
							goto IL_578;
						}
						num8 += int_13[num9 + 2];
						num8 += (num3 & Class5.int_0[num10]);
						num9 = (int_14 + num8) * 3;
						if ((num10 = int_13[num9]) == 0)
						{
							goto IL_425;
						}
					}
					num10 &= 15;
					num11 = int_13[num9 + 2] + (num3 & Class5.int_0[num10]);
					num3 >>= num10;
					for (i -= num10; i < 15; i += 8)
					{
						num2--;
						num3 |= (int)(zlibCodec_0.InputBuffer[num++] & byte.MaxValue) << i;
					}
					num8 = (num3 & num7);
					num9 = (int_16 + num8) * 3;
					num10 = int_15[num9];
					for (;;)
					{
						num3 >>= int_15[num9 + 1];
						i -= int_15[num9 + 1];
						if ((num10 & 16) != 0)
						{
							break;
						}
						if ((num10 & 64) != 0)
						{
							goto IL_481;
						}
						num8 += int_15[num9 + 2];
						num8 += (num3 & Class5.int_0[num10]);
						num9 = (int_16 + num8) * 3;
						num10 = int_15[num9];
					}
					num10 &= 15;
					while (i < num10)
					{
						num2--;
						num3 |= (int)(zlibCodec_0.InputBuffer[num++] & byte.MaxValue) << i;
						i += 8;
					}
					int num12 = int_15[num9 + 2] + (num3 & Class5.int_0[num10]);
					num3 >>= num10;
					i -= num10;
					num5 -= num11;
					int num13;
					if (num4 >= num12)
					{
						num13 = num4 - num12;
						if (num4 - num13 > 0 && 2 > num4 - num13)
						{
							class4_0.byte_0[num4++] = class4_0.byte_0[num13++];
							class4_0.byte_0[num4++] = class4_0.byte_0[num13++];
							num11 -= 2;
						}
						else
						{
							Array.Copy(class4_0.byte_0, num13, class4_0.byte_0, num4, 2);
							num4 += 2;
							num13 += 2;
							num11 -= 2;
						}
					}
					else
					{
						num13 = num4 - num12;
						do
						{
							num13 += class4_0.int_10;
						}
						while (num13 < 0);
						num10 = class4_0.int_10 - num13;
						if (num11 > num10)
						{
							num11 -= num10;
							if (num4 - num13 > 0 && num10 > num4 - num13)
							{
								do
								{
									class4_0.byte_0[num4++] = class4_0.byte_0[num13++];
								}
								while (--num10 != 0);
							}
							else
							{
								Array.Copy(class4_0.byte_0, num13, class4_0.byte_0, num4, num10);
								num4 += num10;
								num13 += num10;
							}
							num13 = 0;
						}
					}
					if (num4 - num13 > 0 && num11 > num4 - num13)
					{
						do
						{
							class4_0.byte_0[num4++] = class4_0.byte_0[num13++];
						}
						while (--num11 != 0);
						goto IL_459;
					}
					Array.Copy(class4_0.byte_0, num13, class4_0.byte_0, num4, num11);
					num4 += num11;
					num13 += num11;
					goto IL_459;
					IL_425:
					num3 >>= int_13[num9 + 1];
					i -= int_13[num9 + 1];
					class4_0.byte_0[num4++] = (byte)int_13[num9 + 2];
					num5--;
				}
				IL_459:
				if (num5 < 258 || num2 < 10)
				{
					goto IL_503;
				}
			}
			else
			{
				num2--;
				num3 |= (int)(zlibCodec_0.InputBuffer[num++] & byte.MaxValue) << i;
				i += 8;
			}
		}
		IL_481:
		zlibCodec_0.Message = "invalid distance code";
		num11 = zlibCodec_0.AvailableBytesIn - num2;
		num11 = ((i >> 3 < num11) ? (i >> 3) : num11);
		num2 += num11;
		num -= num11;
		i -= num11 << 3;
		class4_0.int_8 = num3;
		class4_0.int_7 = i;
		zlibCodec_0.AvailableBytesIn = num2;
		zlibCodec_0.TotalBytesIn += (long)(num - zlibCodec_0.NextIn);
		zlibCodec_0.NextIn = num;
		class4_0.int_12 = num4;
		return -3;
		IL_503:
		num11 = zlibCodec_0.AvailableBytesIn - num2;
		num11 = ((i >> 3 < num11) ? (i >> 3) : num11);
		num2 += num11;
		num -= num11;
		i -= num11 << 3;
		class4_0.int_8 = num3;
		class4_0.int_7 = i;
		zlibCodec_0.AvailableBytesIn = num2;
		zlibCodec_0.TotalBytesIn += (long)(num - zlibCodec_0.NextIn);
		zlibCodec_0.NextIn = num;
		class4_0.int_12 = num4;
		return 0;
		IL_578:
		int result;
		if ((num10 & 32) != 0)
		{
			num11 = zlibCodec_0.AvailableBytesIn - num2;
			num11 = ((i >> 3 < num11) ? (i >> 3) : num11);
			num2 += num11;
			num -= num11;
			i -= num11 << 3;
			class4_0.int_8 = num3;
			class4_0.int_7 = i;
			zlibCodec_0.AvailableBytesIn = num2;
			zlibCodec_0.TotalBytesIn += (long)(num - zlibCodec_0.NextIn);
			zlibCodec_0.NextIn = num;
			class4_0.int_12 = num4;
			result = 1;
		}
		else
		{
			zlibCodec_0.Message = "invalid literal/length code";
			num11 = zlibCodec_0.AvailableBytesIn - num2;
			num11 = ((i >> 3 < num11) ? (i >> 3) : num11);
			num2 += num11;
			num -= num11;
			i -= num11 << 3;
			class4_0.int_8 = num3;
			class4_0.int_7 = i;
			zlibCodec_0.AvailableBytesIn = num2;
			zlibCodec_0.TotalBytesIn += (long)(num - zlibCodec_0.NextIn);
			zlibCodec_0.NextIn = num;
			class4_0.int_12 = num4;
			result = -3;
		}
		return result;
	}

	// Token: 0x04000203 RID: 515
	internal int goKtrnweCF;

	// Token: 0x04000204 RID: 516
	internal int int_0;

	// Token: 0x04000205 RID: 517
	internal int[] int_1;

	// Token: 0x04000206 RID: 518
	internal int int_2;

	// Token: 0x04000207 RID: 519
	internal int int_3;

	// Token: 0x04000208 RID: 520
	internal int int_4;

	// Token: 0x04000209 RID: 521
	internal int int_5;

	// Token: 0x0400020A RID: 522
	internal int int_6;

	// Token: 0x0400020B RID: 523
	internal byte byte_0;

	// Token: 0x0400020C RID: 524
	internal byte byte_1;

	// Token: 0x0400020D RID: 525
	internal int[] int_7;

	// Token: 0x0400020E RID: 526
	internal int int_8;

	// Token: 0x0400020F RID: 527
	internal int[] int_9;

	// Token: 0x04000210 RID: 528
	internal int int_10;
}
