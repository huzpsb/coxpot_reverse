﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;
using System.Xml;
using Coxpots;

// Token: 0x020000A8 RID: 168
internal class Class26
{
	// Token: 0x0600036B RID: 875 RVA: 0x0001A244 File Offset: 0x00018444
	public static void smethod_0(List<string> list_0)
	{
		string proxy_url = Setting.proxy_url;
		HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(proxy_url);
		try
		{
			httpWebRequest.UserAgent = "Mozilla/5.0 (Windows NT 6.3; Win64; x64; rv:63.0) Gecko/20100101 Firefox/63.0";
			httpWebRequest.CookieContainer = Class26.smethod_4(Setting.proxy_cookie, ".89ip.cn");
			httpWebRequest.Method = "GET";
			HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
			StreamReader streamReader = new StreamReader(httpWebResponse.GetResponseStream());
			MatchCollection matchCollection = Regex.Matches(streamReader.ReadToEnd(), Setting.proxy_regex);
			foreach (object obj in matchCollection)
			{
				Match match = (Match)obj;
				list_0.Add(match.Value);
			}
			Class16.smethod_0("#2_Get Soniu:" + matchCollection.Count.ToString(), "Coiun");
		}
		catch (WebException ex)
		{
			HttpWebResponse httpWebResponse = (HttpWebResponse)ex.Response;
			if (Convert.ToInt32(httpWebResponse.StatusCode) == 521)
			{
				Class16.smethod_0("#2_SetCookie\r\n" + ex.Message, "Coiun");
				if (httpWebResponse.Headers["Set-Cookie"] != null)
				{
					Setting.proxy_cookie = httpWebResponse.Headers["Set-Cookie"];
				}
				Setting.IniWriteValue("Proxy", "cookie", Setting.proxy_cookie);
			}
			Class26.smethod_1(list_0);
		}
		catch (Exception ex2)
		{
			Class16.smethod_0("#2_Failed\r\n" + ex2.Message, "Coiun");
		}
	}

	// Token: 0x0600036C RID: 876 RVA: 0x0001A3FC File Offset: 0x000185FC
	public static void smethod_1(List<string> list_0)
	{
		string requestUriString = "http://proxy.catlr.cn/get_all/";
		HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(requestUriString);
		try
		{
			httpWebRequest.Method = "GET";
			HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
			StreamReader streamReader = new StreamReader(httpWebResponse.GetResponseStream());
			string[] array = Class26.smethod_3(streamReader.ReadToEnd(), "[", "]").Split(new char[]
			{
				','
			});
			foreach (string string_ in array)
			{
				string item = Class26.smethod_3(string_, "\"", "\"");
				list_0.Add(item);
			}
			Console.WriteLine("#3_Get Soniu:" + array.Length.ToString());
		}
		catch (Exception ex)
		{
			Console.WriteLine("#3_Failed\r\n" + ex.Message);
		}
	}

	// Token: 0x0600036D RID: 877 RVA: 0x0001A4E8 File Offset: 0x000186E8
	internal static bool smethod_2(string string_0, string string_1)
	{
		bool result;
		try
		{
			HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(string_0);
			httpWebRequest.Method = "POST";
			httpWebRequest.ContentType = "application/x-www-form-urlencoded";
			StreamWriter streamWriter = new StreamWriter(httpWebRequest.GetRequestStream());
			streamWriter.Write(string_1);
			streamWriter.Close();
			HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
			StreamReader streamReader = new StreamReader(httpWebResponse.GetResponseStream());
			string xml = streamReader.ReadToEnd();
			streamReader.Close();
			XmlDocument xmlDocument = new XmlDocument();
			xmlDocument.LoadXml(xml);
			XmlNode xmlNode = xmlDocument.SelectSingleNode("state");
			if (xmlNode.InnerText == "success")
			{
				result = true;
			}
			else
			{
				result = false;
			}
		}
		catch
		{
			result = false;
		}
		return result;
	}

	// Token: 0x0600036E RID: 878 RVA: 0x0001A5AC File Offset: 0x000187AC
	private static string smethod_3(string string_0, string string_1, string string_2)
	{
		int startIndex = string_0.IndexOf(string_1) + string_1.Length;
		return string_0.Substring(startIndex, string_0.Substring(startIndex).IndexOf(string_2));
	}

	// Token: 0x0600036F RID: 879 RVA: 0x0001A5E0 File Offset: 0x000187E0
	public static CookieContainer smethod_4(string string_0, string string_1 = ".xxx.com")
	{
		CookieContainer cookieContainer = new CookieContainer();
		string[] array = string_0.Split(new char[]
		{
			';'
		});
		Cookie cookie = new Cookie();
		cookie.Domain = string_1;
		for (int i = 0; i < array.Length; i++)
		{
			string text = array[i];
			if (text.Contains("="))
			{
				int num = text.IndexOf('=');
				string text2 = text.Substring(0, num).Trim();
				string text3 = text.Substring(num + 1);
				if (i == 0)
				{
					cookie.Name = text2;
					cookie.Value = text3;
				}
				else if (text2.Equals("Domain", StringComparison.OrdinalIgnoreCase))
				{
					cookie.Domain = text3;
				}
				else if (text2.Equals("Expires", StringComparison.OrdinalIgnoreCase))
				{
					DateTime expires;
					DateTime.TryParse(text3, out expires);
					cookie.Expires = expires;
				}
				else if (text2.Equals("Path", StringComparison.OrdinalIgnoreCase))
				{
					cookie.Path = text3;
				}
				else if (text2.Equals("Version", StringComparison.OrdinalIgnoreCase))
				{
					cookie.Version = Convert.ToInt32(text3);
				}
			}
			else if (text.Trim().Equals("HttpOnly", StringComparison.OrdinalIgnoreCase))
			{
				cookie.HttpOnly = true;
			}
		}
		cookieContainer.Add(cookie);
		return cookieContainer;
	}

	// Token: 0x06000370 RID: 880 RVA: 0x0000480C File Offset: 0x00002A0C
	public Class26()
	{
		Class35.NkAVmDjz8ZWXG();
		base..ctor();
	}
}
