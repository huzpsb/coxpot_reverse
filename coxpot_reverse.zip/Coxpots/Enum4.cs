﻿using System;

// Token: 0x0200006D RID: 109
internal enum Enum4
{

}
