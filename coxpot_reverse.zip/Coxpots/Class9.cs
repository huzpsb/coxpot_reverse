﻿using System;

// Token: 0x02000079 RID: 121
internal sealed class Class9
{
	// Token: 0x06000219 RID: 537 RVA: 0x00012508 File Offset: 0x00010708
	internal static int smethod_0(int int_7)
	{
		return (int)((int_7 < 256) ? Class9.sbyte_1[int_7] : Class9.sbyte_1[256 + Class10.smethod_0(int_7, 7)]);
	}

	// Token: 0x0600021A RID: 538 RVA: 0x0001253C File Offset: 0x0001073C
	internal void method_0(Class2 class2_0)
	{
		short[] array = this.short_0;
		short[] short_ = this.class12_0.short_2;
		int[] array2 = this.class12_0.int_0;
		int num = this.class12_0.int_1;
		int num2 = this.class12_0.int_3;
		int num3 = 0;
		for (int i = 0; i <= Class11.int_0; i++)
		{
			class2_0.short_5[i] = 0;
		}
		array[class2_0.int_39[class2_0.xokuGhDon1] * 2 + 1] = 0;
		int j;
		for (j = class2_0.xokuGhDon1 + 1; j < Class9.int_0; j++)
		{
			int k = class2_0.int_39[j];
			int i = (int)(array[(int)(array[k * 2 + 1] * 2 + 1)] + 1);
			if (i > num2)
			{
				i = num2;
				num3++;
			}
			array[k * 2 + 1] = (short)i;
			if (k <= this.int_6)
			{
				short[] short_2 = class2_0.short_5;
				int num4 = i;
				short_2[num4] += 1;
				int num5 = 0;
				if (k >= num)
				{
					num5 = array2[k - num];
				}
				short num6 = array[k * 2];
				class2_0.int_44 += (int)num6 * (i + num5);
				if (short_ != null)
				{
					class2_0.IyxuFiuMr8 += (int)num6 * ((int)short_[k * 2 + 1] + num5);
				}
			}
		}
		if (num3 != 0)
		{
			do
			{
				int i = num2 - 1;
				while (class2_0.short_5[i] == 0)
				{
					i--;
				}
				short[] short_3 = class2_0.short_5;
				int num7 = i;
				short_3[num7] -= 1;
				class2_0.short_5[i + 1] = class2_0.short_5[i + 1] + 2;
				short[] short_4 = class2_0.short_5;
				int num8 = num2;
				short_4[num8] -= 1;
				num3 -= 2;
			}
			while (num3 > 0);
			for (int i = num2; i != 0; i--)
			{
				int k = (int)class2_0.short_5[i];
				while (k != 0)
				{
					int num9 = class2_0.int_39[--j];
					if (num9 <= this.int_6)
					{
						if ((int)array[num9 * 2 + 1] != i)
						{
							class2_0.int_44 = (int)((long)class2_0.int_44 + ((long)i - (long)array[num9 * 2 + 1]) * (long)array[num9 * 2]);
							array[num9 * 2 + 1] = (short)i;
						}
						k--;
					}
				}
			}
		}
	}

	// Token: 0x0600021B RID: 539 RVA: 0x0001278C File Offset: 0x0001098C
	internal void method_1(Class2 class2_0)
	{
		short[] array = this.short_0;
		short[] short_ = this.class12_0.short_2;
		int num = this.class12_0.int_2;
		int num2 = -1;
		class2_0.int_40 = 0;
		class2_0.xokuGhDon1 = Class9.int_0;
		int num3;
		for (int i = 0; i < num; i++)
		{
			if (array[i * 2] != 0)
			{
				int[] int_ = class2_0.int_39;
				num3 = class2_0.int_40 + 1;
				class2_0.int_40 = num3;
				num2 = (int_[num3] = i);
				class2_0.sbyte_1[i] = 0;
			}
			else
			{
				array[i * 2 + 1] = 0;
			}
		}
		int num4;
		while (class2_0.int_40 < 2)
		{
			int[] int_2 = class2_0.int_39;
			num3 = class2_0.int_40 + 1;
			class2_0.int_40 = num3;
			num4 = (int_2[num3] = ((num2 < 2) ? (++num2) : 0));
			array[num4 * 2] = 1;
			class2_0.sbyte_1[num4] = 0;
			class2_0.int_44--;
			if (short_ != null)
			{
				class2_0.IyxuFiuMr8 -= (int)short_[num4 * 2 + 1];
			}
		}
		this.int_6 = num2;
		for (int i = class2_0.int_40 / 2; i >= 1; i--)
		{
			class2_0.method_3(array, i);
		}
		num4 = num;
		do
		{
			int i = class2_0.int_39[1];
			int[] int_3 = class2_0.int_39;
			int num5 = 1;
			int[] int_4 = class2_0.int_39;
			num3 = class2_0.int_40;
			class2_0.int_40 = num3 - 1;
			int_3[num5] = int_4[num3];
			class2_0.method_3(array, 1);
			int num6 = class2_0.int_39[1];
			int[] int_5 = class2_0.int_39;
			num3 = class2_0.xokuGhDon1 - 1;
			class2_0.xokuGhDon1 = num3;
			int_5[num3] = i;
			int[] int_6 = class2_0.int_39;
			num3 = class2_0.xokuGhDon1 - 1;
			class2_0.xokuGhDon1 = num3;
			int_6[num3] = num6;
			array[num4 * 2] = array[i * 2] + array[num6 * 2];
			class2_0.sbyte_1[num4] = (sbyte)(Math.Max((byte)class2_0.sbyte_1[i], (byte)class2_0.sbyte_1[num6]) + 1);
			array[i * 2 + 1] = (array[num6 * 2 + 1] = (short)num4);
			class2_0.int_39[1] = num4++;
			class2_0.method_3(array, 1);
		}
		while (class2_0.int_40 >= 2);
		int[] int_7 = class2_0.int_39;
		num3 = class2_0.xokuGhDon1 - 1;
		class2_0.xokuGhDon1 = num3;
		int_7[num3] = class2_0.int_39[1];
		this.method_0(class2_0);
		Class9.smethod_1(array, num2, class2_0.short_5);
	}

	// Token: 0x0600021C RID: 540 RVA: 0x000129EC File Offset: 0x00010BEC
	internal static void smethod_1(short[] short_1, int int_7, short[] short_2)
	{
		short[] array = new short[Class11.int_0 + 1];
		short num = 0;
		for (int i = 1; i <= Class11.int_0; i++)
		{
			num = (array[i] = (short)(num + short_2[i - 1] << 1));
		}
		for (int j = 0; j <= int_7; j++)
		{
			int num2 = (int)short_1[j * 2 + 1];
			if (num2 != 0)
			{
				int num3 = j * 2;
				short[] array2 = array;
				int num4 = num2;
				short num5 = array2[num4];
				array2[num4] = num5 + 1;
				short_1[num3] = (short)Class9.smethod_2((int)num5, num2);
			}
		}
	}

	// Token: 0x0600021D RID: 541 RVA: 0x00012A70 File Offset: 0x00010C70
	internal static int smethod_2(int int_7, int int_8)
	{
		int num = 0;
		do
		{
			num |= (int_7 & 1);
			int_7 >>= 1;
			num <<= 1;
		}
		while (--int_8 > 0);
		return num >> 1;
	}

	// Token: 0x0600021E RID: 542 RVA: 0x0000480C File Offset: 0x00002A0C
	public Class9()
	{
		Class35.NkAVmDjz8ZWXG();
		base..ctor();
	}

	// Token: 0x0600021F RID: 543 RVA: 0x00012AA0 File Offset: 0x00010CA0
	static Class9()
	{
		Class35.NkAVmDjz8ZWXG();
		Class9.int_0 = 2 * Class11.int_5 + 1;
		Class9.int_1 = new int[]
		{
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			1,
			1,
			1,
			1,
			2,
			2,
			2,
			2,
			3,
			3,
			3,
			3,
			4,
			4,
			4,
			4,
			5,
			5,
			5,
			5,
			0
		};
		Class9.int_2 = new int[]
		{
			0,
			0,
			0,
			0,
			1,
			1,
			2,
			2,
			3,
			3,
			4,
			4,
			5,
			5,
			6,
			6,
			7,
			7,
			8,
			8,
			9,
			9,
			10,
			10,
			11,
			11,
			12,
			12,
			13,
			13
		};
		Class9.int_3 = new int[]
		{
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			0,
			2,
			3,
			7
		};
		Class9.sbyte_0 = new sbyte[]
		{
			16,
			17,
			18,
			0,
			8,
			7,
			9,
			6,
			10,
			5,
			11,
			4,
			12,
			3,
			13,
			2,
			14,
			1,
			15
		};
		Class9.sbyte_1 = new sbyte[]
		{
			0,
			1,
			2,
			3,
			4,
			4,
			5,
			5,
			6,
			6,
			6,
			6,
			7,
			7,
			7,
			7,
			8,
			8,
			8,
			8,
			8,
			8,
			8,
			8,
			9,
			9,
			9,
			9,
			9,
			9,
			9,
			9,
			10,
			10,
			10,
			10,
			10,
			10,
			10,
			10,
			10,
			10,
			10,
			10,
			10,
			10,
			10,
			10,
			11,
			11,
			11,
			11,
			11,
			11,
			11,
			11,
			11,
			11,
			11,
			11,
			11,
			11,
			11,
			11,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			12,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			13,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			14,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			15,
			0,
			0,
			16,
			17,
			18,
			18,
			19,
			19,
			20,
			20,
			20,
			20,
			21,
			21,
			21,
			21,
			22,
			22,
			22,
			22,
			22,
			22,
			22,
			22,
			23,
			23,
			23,
			23,
			23,
			23,
			23,
			23,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			28,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29,
			29
		};
		Class9.sbyte_2 = new sbyte[]
		{
			0,
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8,
			8,
			9,
			9,
			10,
			10,
			11,
			11,
			12,
			12,
			12,
			12,
			13,
			13,
			13,
			13,
			14,
			14,
			14,
			14,
			15,
			15,
			15,
			15,
			16,
			16,
			16,
			16,
			16,
			16,
			16,
			16,
			17,
			17,
			17,
			17,
			17,
			17,
			17,
			17,
			18,
			18,
			18,
			18,
			18,
			18,
			18,
			18,
			19,
			19,
			19,
			19,
			19,
			19,
			19,
			19,
			20,
			20,
			20,
			20,
			20,
			20,
			20,
			20,
			20,
			20,
			20,
			20,
			20,
			20,
			20,
			20,
			21,
			21,
			21,
			21,
			21,
			21,
			21,
			21,
			21,
			21,
			21,
			21,
			21,
			21,
			21,
			21,
			22,
			22,
			22,
			22,
			22,
			22,
			22,
			22,
			22,
			22,
			22,
			22,
			22,
			22,
			22,
			22,
			23,
			23,
			23,
			23,
			23,
			23,
			23,
			23,
			23,
			23,
			23,
			23,
			23,
			23,
			23,
			23,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			24,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			25,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			26,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			27,
			28
		};
		Class9.int_4 = new int[]
		{
			0,
			1,
			2,
			3,
			4,
			5,
			6,
			7,
			8,
			10,
			12,
			14,
			16,
			20,
			24,
			28,
			32,
			40,
			48,
			56,
			64,
			80,
			96,
			112,
			128,
			160,
			192,
			224,
			0
		};
		Class9.int_5 = new int[]
		{
			0,
			1,
			2,
			3,
			4,
			6,
			8,
			12,
			16,
			24,
			32,
			48,
			64,
			96,
			128,
			192,
			256,
			384,
			512,
			768,
			1024,
			1536,
			2048,
			3072,
			4096,
			6144,
			8192,
			12288,
			16384,
			24576
		};
	}

	// Token: 0x04000228 RID: 552
	private static readonly int int_0;

	// Token: 0x04000229 RID: 553
	internal static readonly int[] int_1;

	// Token: 0x0400022A RID: 554
	internal static readonly int[] int_2;

	// Token: 0x0400022B RID: 555
	internal static readonly int[] int_3;

	// Token: 0x0400022C RID: 556
	internal static readonly sbyte[] sbyte_0;

	// Token: 0x0400022D RID: 557
	private static readonly sbyte[] sbyte_1;

	// Token: 0x0400022E RID: 558
	internal static readonly sbyte[] sbyte_2;

	// Token: 0x0400022F RID: 559
	internal static readonly int[] int_4;

	// Token: 0x04000230 RID: 560
	internal static readonly int[] int_5;

	// Token: 0x04000231 RID: 561
	internal short[] short_0;

	// Token: 0x04000232 RID: 562
	internal int int_6;

	// Token: 0x04000233 RID: 563
	internal Class12 class12_0;
}
