﻿using System;

// Token: 0x020000A9 RID: 169
internal class Class27
{
	// Token: 0x06000371 RID: 881 RVA: 0x0000480C File Offset: 0x00002A0C
	public Class27()
	{
		Class35.NkAVmDjz8ZWXG();
		base..ctor();
	}
}
