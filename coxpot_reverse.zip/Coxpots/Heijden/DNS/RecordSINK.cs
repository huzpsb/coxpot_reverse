﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000028 RID: 40
	public class RecordSINK : Record
	{
		// Token: 0x060000E2 RID: 226 RVA: 0x000093D0 File Offset: 0x000075D0
		public RecordSINK(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			ushort intLength = rr.method_1(-2);
			this.RDATA = rr.ReadBytes((int)intLength);
		}

		// Token: 0x060000E3 RID: 227 RVA: 0x000090E0 File Offset: 0x000072E0
		public override string ToString()
		{
			return string.Format("not-used", new object[0]);
		}

		// Token: 0x04000049 RID: 73
		public byte[] RDATA;
	}
}
