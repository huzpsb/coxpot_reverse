﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

namespace Heijden.DNS
{
	// Token: 0x02000056 RID: 86
	public class Resolver
	{
		// Token: 0x17000029 RID: 41
		// (get) Token: 0x06000145 RID: 325 RVA: 0x0000A794 File Offset: 0x00008994
		public string Version
		{
			get
			{
				return Assembly.GetExecutingAssembly().GetName().Version.ToString();
			}
		}

		// Token: 0x06000146 RID: 326 RVA: 0x0000A7B8 File Offset: 0x000089B8
		public Resolver(IPEndPoint[] DnsServers)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.dictionary_0 = new Dictionary<string, Response>();
			this.list_0 = new List<IPEndPoint>();
			this.list_0.AddRange(DnsServers);
			this.ushort_0 = (ushort)new Random().Next();
			this.int_0 = 3;
			this.int_1 = 1;
			this.bool_1 = true;
			this.bool_0 = true;
			this.transportType_0 = TransportType.Udp;
		}

		// Token: 0x06000147 RID: 327 RVA: 0x0000524D File Offset: 0x0000344D
		public Resolver(IPEndPoint DnsServer)
		{
			Class35.NkAVmDjz8ZWXG();
			this..ctor(new IPEndPoint[]
			{
				DnsServer
			});
		}

		// Token: 0x06000148 RID: 328 RVA: 0x00005264 File Offset: 0x00003464
		public Resolver(IPAddress ServerIpAddress, int ServerPortNumber)
		{
			Class35.NkAVmDjz8ZWXG();
			this..ctor(new IPEndPoint(ServerIpAddress, ServerPortNumber));
		}

		// Token: 0x06000149 RID: 329 RVA: 0x00005278 File Offset: 0x00003478
		public Resolver(string ServerIpAddress, int ServerPortNumber)
		{
			Class35.NkAVmDjz8ZWXG();
			this..ctor(IPAddress.Parse(ServerIpAddress), ServerPortNumber);
		}

		// Token: 0x0600014A RID: 330 RVA: 0x0000528C File Offset: 0x0000348C
		public Resolver(string ServerIpAddress)
		{
			Class35.NkAVmDjz8ZWXG();
			this..ctor(IPAddress.Parse(ServerIpAddress), 53);
		}

		// Token: 0x0600014B RID: 331 RVA: 0x000052A1 File Offset: 0x000034A1
		public Resolver()
		{
			Class35.NkAVmDjz8ZWXG();
			this..ctor(Resolver.GetDnsServers());
		}

		// Token: 0x0600014C RID: 332 RVA: 0x000052B3 File Offset: 0x000034B3
		private void method_0(string string_0, params object[] args)
		{
			if (this.verboseEventHandler_0 != null)
			{
				this.verboseEventHandler_0(this, new Resolver.VerboseEventArgs(string.Format(string_0, args)));
			}
		}

		// Token: 0x14000006 RID: 6
		// (add) Token: 0x0600014D RID: 333 RVA: 0x0000A828 File Offset: 0x00008A28
		// (remove) Token: 0x0600014E RID: 334 RVA: 0x0000A860 File Offset: 0x00008A60
		public event Resolver.VerboseEventHandler OnVerbose
		{
			[CompilerGenerated]
			add
			{
				Resolver.VerboseEventHandler verboseEventHandler = this.verboseEventHandler_0;
				Resolver.VerboseEventHandler verboseEventHandler2;
				do
				{
					verboseEventHandler2 = verboseEventHandler;
					Resolver.VerboseEventHandler value2 = (Resolver.VerboseEventHandler)Delegate.Combine(verboseEventHandler2, value);
					verboseEventHandler = Interlocked.CompareExchange<Resolver.VerboseEventHandler>(ref this.verboseEventHandler_0, value2, verboseEventHandler2);
				}
				while (verboseEventHandler != verboseEventHandler2);
			}
			[CompilerGenerated]
			remove
			{
				Resolver.VerboseEventHandler verboseEventHandler = this.verboseEventHandler_0;
				Resolver.VerboseEventHandler verboseEventHandler2;
				do
				{
					verboseEventHandler2 = verboseEventHandler;
					Resolver.VerboseEventHandler value2 = (Resolver.VerboseEventHandler)Delegate.Remove(verboseEventHandler2, value);
					verboseEventHandler = Interlocked.CompareExchange<Resolver.VerboseEventHandler>(ref this.verboseEventHandler_0, value2, verboseEventHandler2);
				}
				while (verboseEventHandler != verboseEventHandler2);
			}
		}

		// Token: 0x1700002A RID: 42
		// (get) Token: 0x0600014F RID: 335 RVA: 0x0000A898 File Offset: 0x00008A98
		// (set) Token: 0x06000150 RID: 336 RVA: 0x000052D8 File Offset: 0x000034D8
		public int TimeOut
		{
			get
			{
				return this.int_1;
			}
			set
			{
				this.int_1 = value;
			}
		}

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x06000151 RID: 337 RVA: 0x0000A8B0 File Offset: 0x00008AB0
		// (set) Token: 0x06000152 RID: 338 RVA: 0x000052E1 File Offset: 0x000034E1
		public int Retries
		{
			get
			{
				return this.int_0;
			}
			set
			{
				if (value >= 1)
				{
					this.int_0 = value;
				}
			}
		}

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x06000153 RID: 339 RVA: 0x000052F3 File Offset: 0x000034F3
		// (set) Token: 0x06000154 RID: 340 RVA: 0x000052FB File Offset: 0x000034FB
		public bool Recursion
		{
			get
			{
				return this.bool_1;
			}
			set
			{
				this.bool_1 = value;
			}
		}

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x06000155 RID: 341 RVA: 0x0000A8C8 File Offset: 0x00008AC8
		// (set) Token: 0x06000156 RID: 342 RVA: 0x00005304 File Offset: 0x00003504
		public TransportType TransportType
		{
			get
			{
				return this.transportType_0;
			}
			set
			{
				this.transportType_0 = value;
			}
		}

		// Token: 0x1700002E RID: 46
		// (get) Token: 0x06000157 RID: 343 RVA: 0x0000A8E0 File Offset: 0x00008AE0
		// (set) Token: 0x06000158 RID: 344 RVA: 0x0000530D File Offset: 0x0000350D
		public IPEndPoint[] DnsServers
		{
			get
			{
				return this.list_0.ToArray();
			}
			set
			{
				this.list_0.Clear();
				this.list_0.AddRange(value);
			}
		}

		// Token: 0x1700002F RID: 47
		// (get) Token: 0x06000159 RID: 345 RVA: 0x0000A8FC File Offset: 0x00008AFC
		// (set) Token: 0x0600015A RID: 346 RVA: 0x0000A924 File Offset: 0x00008B24
		public string DnsServer
		{
			get
			{
				return this.list_0[0].Address.ToString();
			}
			set
			{
				IPAddress address;
				if (IPAddress.TryParse(value, out address))
				{
					this.list_0.Clear();
					this.list_0.Add(new IPEndPoint(address, 53));
				}
				else
				{
					Response response = this.Query(value, QType.A);
					if (response.RecordsA.Length != 0)
					{
						this.list_0.Clear();
						this.list_0.Add(new IPEndPoint(response.RecordsA[0].Address, 53));
					}
				}
			}
		}

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x0600015B RID: 347 RVA: 0x00005326 File Offset: 0x00003526
		// (set) Token: 0x0600015C RID: 348 RVA: 0x0000532E File Offset: 0x0000352E
		public bool UseCache
		{
			get
			{
				return this.bool_0;
			}
			set
			{
				this.bool_0 = value;
				if (!this.bool_0)
				{
					this.dictionary_0.Clear();
				}
			}
		}

		// Token: 0x0600015D RID: 349 RVA: 0x0000534D File Offset: 0x0000354D
		public void ClearCache()
		{
			this.dictionary_0.Clear();
		}

		// Token: 0x0600015E RID: 350 RVA: 0x0000A99C File Offset: 0x00008B9C
		private Response method_1(Question question_0)
		{
			Response result;
			if (!this.bool_0)
			{
				result = null;
			}
			else
			{
				string key = string.Concat(new string[]
				{
					question_0.QClass.ToString(),
					"-",
					question_0.QType.ToString(),
					"-",
					question_0.QName
				});
				Response response = null;
				Dictionary<string, Response> obj = this.dictionary_0;
				lock (obj)
				{
					if (!this.dictionary_0.ContainsKey(key))
					{
						return null;
					}
					response = this.dictionary_0[key];
				}
				int timeLived = (int)((DateTime.Now.Ticks - response.TimeStamp.Ticks) / 10000000L);
				foreach (RR rr in response.RecordsRR)
				{
					rr.TimeLived = timeLived;
					if (rr.TTL == 0u)
					{
						return null;
					}
				}
				result = response;
			}
			return result;
		}

		// Token: 0x0600015F RID: 351 RVA: 0x0000AAC0 File Offset: 0x00008CC0
		private void method_2(Response response_0)
		{
			if (this.bool_0 && response_0.Questions.Count != 0 && response_0.header.RCODE <= RCode.NoError)
			{
				Question question = response_0.Questions[0];
				string key = string.Concat(new string[]
				{
					question.QClass.ToString(),
					"-",
					question.QType.ToString(),
					"-",
					question.QName
				});
				Dictionary<string, Response> obj = this.dictionary_0;
				lock (obj)
				{
					if (this.dictionary_0.ContainsKey(key))
					{
						this.dictionary_0.Remove(key);
					}
					this.dictionary_0.Add(key, response_0);
				}
			}
		}

		// Token: 0x06000160 RID: 352 RVA: 0x0000ABB0 File Offset: 0x00008DB0
		private Response method_3(Request request_0)
		{
			byte[] array = new byte[512];
			for (int i = 0; i < this.int_0; i++)
			{
				for (int j = 0; j < this.list_0.Count; j++)
				{
					Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
					socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReceiveTimeout, this.int_1 * 1000);
					try
					{
						socket.SendTo(request_0.Data, this.list_0[j]);
						int num = socket.Receive(array);
						byte[] array2 = new byte[num];
						Array.Copy(array, array2, num);
						Response response = new Response(this.list_0[j], array2);
						this.method_2(response);
						return response;
					}
					catch (SocketException)
					{
						this.method_0(string.Format(";; Connection to nameserver {0} failed", j + 1), new object[0]);
					}
					finally
					{
						this.ushort_0 += 1;
						socket.Close();
					}
				}
			}
			return new Response
			{
				Error = "Timeout Error"
			};
		}

		// Token: 0x06000161 RID: 353 RVA: 0x0000ACF0 File Offset: 0x00008EF0
		private Response method_4(Request request_0)
		{
			for (int i = 0; i < this.int_0; i++)
			{
				for (int j = 0; j < this.list_0.Count; j++)
				{
					TcpClient tcpClient = new TcpClient();
					tcpClient.ReceiveTimeout = this.int_1 * 1000;
					try
					{
						IAsyncResult asyncResult = tcpClient.BeginConnect(this.list_0[j].Address, this.list_0[j].Port, null, null);
						if (!asyncResult.AsyncWaitHandle.WaitOne(this.int_1 * 1000, true) || !tcpClient.Connected)
						{
							tcpClient.Close();
							this.method_0(string.Format(";; Connection to nameserver {0} failed", j + 1), new object[0]);
							goto IL_2FC;
						}
						BufferedStream bufferedStream = new BufferedStream(tcpClient.GetStream());
						byte[] array = request_0.Data;
						bufferedStream.WriteByte((byte)(array.Length >> 8 & 255));
						bufferedStream.WriteByte((byte)(array.Length & 255));
						bufferedStream.Write(array, 0, array.Length);
						bufferedStream.Flush();
						Response response = new Response();
						int num = 0;
						int num2 = 0;
						Response response2;
						for (;;)
						{
							int num3 = bufferedStream.ReadByte() << 8 | bufferedStream.ReadByte();
							if (num3 <= 0)
							{
								break;
							}
							num2 += num3;
							array = new byte[num3];
							bufferedStream.Read(array, 0, num3);
							response2 = new Response(this.list_0[j], array);
							if (response2.header.RCODE > RCode.NoError)
							{
								goto IL_24D;
							}
							if (response2.Questions[0].QType != QType.AXFR)
							{
								goto IL_256;
							}
							if (response.Questions.Count == 0)
							{
								response.Questions.AddRange(response2.Questions);
							}
							response.Answers.AddRange(response2.Answers);
							response.Authorities.AddRange(response2.Authorities);
							response.Additionals.AddRange(response2.Additionals);
							if (response2.Answers[0].Type == Type.SOA)
							{
								num++;
							}
							if (num == 2)
							{
								goto IL_267;
							}
						}
						tcpClient.Close();
						this.method_0(string.Format(";; Connection to nameserver {0} failed", j + 1), new object[0]);
						throw new SocketException();
						IL_24D:
						return response2;
						IL_256:
						this.method_2(response2);
						return response2;
						IL_267:
						response.header.QDCOUNT = (ushort)response.Questions.Count;
						response.header.ANCOUNT = (ushort)response.Answers.Count;
						response.header.NSCOUNT = (ushort)response.Authorities.Count;
						response.header.ARCOUNT = (ushort)response.Additionals.Count;
						response.MessageSize = num2;
						return response;
					}
					catch (SocketException)
					{
						goto IL_2FC;
					}
					finally
					{
						this.ushort_0 += 1;
						tcpClient.Close();
					}
					break;
					IL_2FC:;
				}
			}
			return new Response
			{
				Error = "Timeout Error"
			};
		}

		// Token: 0x06000162 RID: 354 RVA: 0x0000B050 File Offset: 0x00009250
		public Response Query(string name, QType qtype, QClass qclass)
		{
			Question question = new Question(name, qtype, qclass);
			Response response = this.method_1(question);
			Response result;
			if (response != null)
			{
				result = response;
			}
			else
			{
				Request request = new Request();
				request.AddQuestion(question);
				result = this.method_5(request);
			}
			return result;
		}

		// Token: 0x06000163 RID: 355 RVA: 0x0000B090 File Offset: 0x00009290
		public Response Query(string name, QType qtype)
		{
			Question question = new Question(name, qtype, QClass.IN);
			Response response = this.method_1(question);
			Response result;
			if (response != null)
			{
				result = response;
			}
			else
			{
				Request request = new Request();
				request.AddQuestion(question);
				result = this.method_5(request);
			}
			return result;
		}

		// Token: 0x06000164 RID: 356 RVA: 0x0000B0D0 File Offset: 0x000092D0
		private Response method_5(Request request_0)
		{
			request_0.header.ID = this.ushort_0;
			request_0.header.RD = this.bool_1;
			Response result;
			if (this.transportType_0 == TransportType.Udp)
			{
				result = this.method_3(request_0);
			}
			else if (this.transportType_0 == TransportType.Tcp)
			{
				result = this.method_4(request_0);
			}
			else
			{
				result = new Response
				{
					Error = "Unknown TransportType"
				};
			}
			return result;
		}

		// Token: 0x06000165 RID: 357 RVA: 0x0000B140 File Offset: 0x00009340
		public static IPEndPoint[] GetDnsServers()
		{
			List<IPEndPoint> list = new List<IPEndPoint>();
			NetworkInterface[] allNetworkInterfaces = NetworkInterface.GetAllNetworkInterfaces();
			foreach (NetworkInterface networkInterface in allNetworkInterfaces)
			{
				if (networkInterface.OperationalStatus == OperationalStatus.Up)
				{
					IPInterfaceProperties ipproperties = networkInterface.GetIPProperties();
					foreach (IPAddress address in ipproperties.DnsAddresses)
					{
						IPEndPoint item = new IPEndPoint(address, 53);
						if (!list.Contains(item))
						{
							list.Add(item);
						}
					}
				}
			}
			return list.ToArray();
		}

		// Token: 0x06000166 RID: 358 RVA: 0x0000B1F0 File Offset: 0x000093F0
		private IPHostEntry method_6(string string_0)
		{
			IPHostEntry iphostEntry = new IPHostEntry();
			iphostEntry.HostName = string_0;
			Response response = this.Query(string_0, QType.A, QClass.IN);
			List<IPAddress> list = new List<IPAddress>();
			List<string> list2 = new List<string>();
			foreach (AnswerRR answerRR in response.Answers)
			{
				if (answerRR.Type == Type.A)
				{
					list.Add(IPAddress.Parse(answerRR.RECORD.ToString()));
					iphostEntry.HostName = answerRR.NAME;
				}
				else if (answerRR.Type == Type.CNAME)
				{
					list2.Add(answerRR.NAME);
				}
			}
			iphostEntry.AddressList = list.ToArray();
			iphostEntry.Aliases = list2.ToArray();
			return iphostEntry;
		}

		// Token: 0x06000167 RID: 359 RVA: 0x0000B2CC File Offset: 0x000094CC
		public static string GetArpaFromIp(IPAddress ip)
		{
			string result;
			if (ip.AddressFamily == AddressFamily.InterNetwork)
			{
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append("in-addr.arpa.");
				foreach (byte b in ip.GetAddressBytes())
				{
					stringBuilder.Insert(0, string.Format("{0}.", b));
				}
				result = stringBuilder.ToString();
			}
			else if (ip.AddressFamily == AddressFamily.InterNetworkV6)
			{
				StringBuilder stringBuilder2 = new StringBuilder();
				stringBuilder2.Append("ip6.arpa.");
				foreach (byte b2 in ip.GetAddressBytes())
				{
					stringBuilder2.Insert(0, string.Format("{0:x}.", b2 >> 4 & 15));
					stringBuilder2.Insert(0, string.Format("{0:x}.", (int)(b2 & 15)));
				}
				result = stringBuilder2.ToString();
			}
			else
			{
				result = "?";
			}
			return result;
		}

		// Token: 0x06000168 RID: 360 RVA: 0x0000B3C4 File Offset: 0x000095C4
		public static string GetArpaFromEnum(string strEnum)
		{
			StringBuilder stringBuilder = new StringBuilder();
			string text = Regex.Replace(strEnum, "[^0-9]", "");
			stringBuilder.Append("e164.arpa.");
			foreach (char c in text)
			{
				stringBuilder.Insert(0, string.Format("{0}.", c));
			}
			return stringBuilder.ToString();
		}

		// Token: 0x06000169 RID: 361 RVA: 0x0000B434 File Offset: 0x00009634
		public IPAddress[] GetHostAddresses(string hostNameOrAddress)
		{
			IPHostEntry hostEntry = this.GetHostEntry(hostNameOrAddress);
			return hostEntry.AddressList;
		}

		// Token: 0x0600016A RID: 362 RVA: 0x0000B454 File Offset: 0x00009654
		public IAsyncResult BeginGetHostAddresses(string hostNameOrAddress, AsyncCallback requestCallback, object stateObject)
		{
			Resolver.Delegate0 @delegate = new Resolver.Delegate0(this.GetHostAddresses);
			return @delegate.BeginInvoke(hostNameOrAddress, requestCallback, stateObject);
		}

		// Token: 0x0600016B RID: 363 RVA: 0x0000B47C File Offset: 0x0000967C
		public IPAddress[] EndGetHostAddresses(IAsyncResult AsyncResult)
		{
			AsyncResult asyncResult = (AsyncResult)AsyncResult;
			Resolver.Delegate0 @delegate = (Resolver.Delegate0)asyncResult.AsyncDelegate;
			return @delegate.EndInvoke(AsyncResult);
		}

		// Token: 0x0600016C RID: 364 RVA: 0x0000B4A8 File Offset: 0x000096A8
		public IPHostEntry GetHostByAddress(IPAddress ip)
		{
			return this.GetHostEntry(ip);
		}

		// Token: 0x0600016D RID: 365 RVA: 0x0000B4C0 File Offset: 0x000096C0
		public IPHostEntry GetHostByAddress(string address)
		{
			return this.GetHostEntry(address);
		}

		// Token: 0x0600016E RID: 366 RVA: 0x0000B4D8 File Offset: 0x000096D8
		public IPHostEntry GetHostByName(string hostName)
		{
			return this.method_6(hostName);
		}

		// Token: 0x0600016F RID: 367 RVA: 0x0000B4F0 File Offset: 0x000096F0
		public IAsyncResult BeginGetHostByName(string hostName, AsyncCallback requestCallback, object stateObject)
		{
			Resolver.Delegate1 @delegate = new Resolver.Delegate1(this.GetHostByName);
			return @delegate.BeginInvoke(hostName, requestCallback, stateObject);
		}

		// Token: 0x06000170 RID: 368 RVA: 0x0000B518 File Offset: 0x00009718
		public IPHostEntry EndGetHostByName(IAsyncResult AsyncResult)
		{
			AsyncResult asyncResult = (AsyncResult)AsyncResult;
			Resolver.Delegate1 @delegate = (Resolver.Delegate1)asyncResult.AsyncDelegate;
			return @delegate.EndInvoke(AsyncResult);
		}

		// Token: 0x06000171 RID: 369 RVA: 0x0000B4D8 File Offset: 0x000096D8
		public IPHostEntry Resolve(string hostName)
		{
			return this.method_6(hostName);
		}

		// Token: 0x06000172 RID: 370 RVA: 0x0000B544 File Offset: 0x00009744
		public IAsyncResult BeginResolve(string hostName, AsyncCallback requestCallback, object stateObject)
		{
			Resolver.Delegate2 @delegate = new Resolver.Delegate2(this.Resolve);
			return @delegate.BeginInvoke(hostName, requestCallback, stateObject);
		}

		// Token: 0x06000173 RID: 371 RVA: 0x0000B56C File Offset: 0x0000976C
		public IPHostEntry EndResolve(IAsyncResult AsyncResult)
		{
			AsyncResult asyncResult = (AsyncResult)AsyncResult;
			Resolver.Delegate2 @delegate = (Resolver.Delegate2)asyncResult.AsyncDelegate;
			return @delegate.EndInvoke(AsyncResult);
		}

		// Token: 0x06000174 RID: 372 RVA: 0x0000B598 File Offset: 0x00009798
		public IPHostEntry GetHostEntry(IPAddress ip)
		{
			Response response = this.Query(Resolver.GetArpaFromIp(ip), QType.PTR, QClass.IN);
			IPHostEntry result;
			if (response.RecordPTR_0.Length != 0)
			{
				result = this.method_6(response.RecordPTR_0[0].PTRDNAME);
			}
			else
			{
				result = new IPHostEntry();
			}
			return result;
		}

		// Token: 0x06000175 RID: 373 RVA: 0x0000B5E0 File Offset: 0x000097E0
		public IPHostEntry GetHostEntry(string hostNameOrAddress)
		{
			IPAddress ip;
			IPHostEntry result;
			if (IPAddress.TryParse(hostNameOrAddress, out ip))
			{
				result = this.GetHostEntry(ip);
			}
			else
			{
				result = this.method_6(hostNameOrAddress);
			}
			return result;
		}

		// Token: 0x06000176 RID: 374 RVA: 0x0000B60C File Offset: 0x0000980C
		public IAsyncResult BeginGetHostEntry(string hostNameOrAddress, AsyncCallback requestCallback, object stateObject)
		{
			Resolver.Delegate4 @delegate = new Resolver.Delegate4(this.GetHostEntry);
			return @delegate.BeginInvoke(hostNameOrAddress, requestCallback, stateObject);
		}

		// Token: 0x06000177 RID: 375 RVA: 0x0000B634 File Offset: 0x00009834
		public IAsyncResult BeginGetHostEntry(IPAddress ip, AsyncCallback requestCallback, object stateObject)
		{
			Resolver.Delegate3 @delegate = new Resolver.Delegate3(this.GetHostEntry);
			return @delegate.BeginInvoke(ip, requestCallback, stateObject);
		}

		// Token: 0x06000178 RID: 376 RVA: 0x0000B65C File Offset: 0x0000985C
		public IPHostEntry EndGetHostEntry(IAsyncResult AsyncResult)
		{
			AsyncResult asyncResult = (AsyncResult)AsyncResult;
			IPHostEntry result;
			if (asyncResult.AsyncDelegate is Resolver.Delegate4)
			{
				Resolver.Delegate4 @delegate = (Resolver.Delegate4)asyncResult.AsyncDelegate;
				result = @delegate.EndInvoke(AsyncResult);
			}
			else if (asyncResult.AsyncDelegate is Resolver.Delegate3)
			{
				Resolver.Delegate3 delegate2 = (Resolver.Delegate3)asyncResult.AsyncDelegate;
				result = delegate2.EndInvoke(AsyncResult);
			}
			else
			{
				result = null;
			}
			return result;
		}

		// Token: 0x06000179 RID: 377 RVA: 0x0000B6C0 File Offset: 0x000098C0
		public void LoadRootFile(string strPath)
		{
			StreamReader streamReader = new StreamReader(strPath);
			while (!streamReader.EndOfStream)
			{
				string text = streamReader.ReadLine();
				if (text == null)
				{
					break;
				}
				int i = text.IndexOf(';');
				if (i >= 0)
				{
					text = text.Substring(0, i);
				}
				text = text.Trim();
				if (text.Length != 0)
				{
					Resolver.Enum2 @enum = (Resolver.Enum2)1;
					string text2 = "";
					foreach (char c in text)
					{
						if (c <= ' ' && text2 != "")
						{
							switch (@enum)
							{
							case (Resolver.Enum2)1:
								@enum = (Resolver.Enum2)2;
								break;
							case (Resolver.Enum2)2:
								@enum = (Resolver.Enum2)3;
								break;
							case (Resolver.Enum2)3:
								@enum = (Resolver.Enum2)4;
								break;
							case (Resolver.Enum2)4:
								@enum = (Resolver.Enum2)5;
								break;
							case (Resolver.Enum2)5:
								@enum = (Resolver.Enum2)0;
								break;
							}
							text2 = "";
						}
						if (c > ' ')
						{
							text2 += c.ToString();
						}
					}
				}
			}
			streamReader.Close();
		}

		// Token: 0x0600017A RID: 378 RVA: 0x0000535A File Offset: 0x0000355A
		static Resolver()
		{
			Class35.NkAVmDjz8ZWXG();
			Resolver.DefaultDnsServers = new IPEndPoint[]
			{
				new IPEndPoint(IPAddress.Parse("208.67.222.222"), 53),
				new IPEndPoint(IPAddress.Parse("208.67.220.220"), 53)
			};
		}

		// Token: 0x040000BA RID: 186
		public const int DefaultPort = 53;

		// Token: 0x040000BB RID: 187
		public static readonly IPEndPoint[] DefaultDnsServers;

		// Token: 0x040000BC RID: 188
		private ushort ushort_0;

		// Token: 0x040000BD RID: 189
		private bool bool_0;

		// Token: 0x040000BE RID: 190
		private bool bool_1;

		// Token: 0x040000BF RID: 191
		private int int_0;

		// Token: 0x040000C0 RID: 192
		private int int_1;

		// Token: 0x040000C1 RID: 193
		private TransportType transportType_0;

		// Token: 0x040000C2 RID: 194
		private List<IPEndPoint> list_0;

		// Token: 0x040000C3 RID: 195
		private Dictionary<string, Response> dictionary_0;

		// Token: 0x040000C4 RID: 196
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private Resolver.VerboseEventHandler verboseEventHandler_0;

		// Token: 0x02000057 RID: 87
		public class VerboseOutputEventArgs : EventArgs
		{
			// Token: 0x0600017B RID: 379 RVA: 0x00005394 File Offset: 0x00003594
			public VerboseOutputEventArgs(string Message)
			{
				Class35.NkAVmDjz8ZWXG();
				base..ctor();
				this.Message = Message;
			}

			// Token: 0x040000C5 RID: 197
			public string Message;
		}

		// Token: 0x02000058 RID: 88
		// (Invoke) Token: 0x0600017D RID: 381
		public delegate void VerboseEventHandler(object sender, Resolver.VerboseEventArgs e);

		// Token: 0x02000059 RID: 89
		public class VerboseEventArgs : EventArgs
		{
			// Token: 0x06000180 RID: 384 RVA: 0x000053A8 File Offset: 0x000035A8
			public VerboseEventArgs(string Message)
			{
				Class35.NkAVmDjz8ZWXG();
				base..ctor();
				this.Message = Message;
			}

			// Token: 0x040000C6 RID: 198
			public string Message;
		}

		// Token: 0x0200005A RID: 90
		// (Invoke) Token: 0x06000182 RID: 386
		private delegate IPAddress[] Delegate0(string hostNameOrAddress);

		// Token: 0x0200005B RID: 91
		// (Invoke) Token: 0x06000186 RID: 390
		private delegate IPHostEntry Delegate1(string hostName);

		// Token: 0x0200005C RID: 92
		// (Invoke) Token: 0x0600018A RID: 394
		private delegate IPHostEntry Delegate2(string hostName);

		// Token: 0x0200005D RID: 93
		// (Invoke) Token: 0x0600018E RID: 398
		private delegate IPHostEntry Delegate3(IPAddress ip);

		// Token: 0x0200005E RID: 94
		// (Invoke) Token: 0x06000192 RID: 402
		private delegate IPHostEntry Delegate4(string hostNameOrAddress);

		// Token: 0x0200005F RID: 95
		private enum Enum2
		{

		}
	}
}
