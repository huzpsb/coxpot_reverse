﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000029 RID: 41
	public class RecordSPF : Record
	{
		// Token: 0x060000E4 RID: 228 RVA: 0x00009400 File Offset: 0x00007600
		public RecordSPF(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			ushort intLength = rr.method_1(-2);
			this.RDATA = rr.ReadBytes((int)intLength);
		}

		// Token: 0x060000E5 RID: 229 RVA: 0x000090E0 File Offset: 0x000072E0
		public override string ToString()
		{
			return string.Format("not-used", new object[0]);
		}

		// Token: 0x0400004A RID: 74
		public byte[] RDATA;
	}
}
