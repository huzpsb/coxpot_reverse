﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000022 RID: 34
	public class RecordNIMLOC : Record
	{
		// Token: 0x060000D6 RID: 214 RVA: 0x000092B0 File Offset: 0x000074B0
		public RecordNIMLOC(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			ushort intLength = rr.method_1(-2);
			this.RDATA = rr.ReadBytes((int)intLength);
		}

		// Token: 0x060000D7 RID: 215 RVA: 0x000090E0 File Offset: 0x000072E0
		public override string ToString()
		{
			return string.Format("not-used", new object[0]);
		}

		// Token: 0x04000043 RID: 67
		public byte[] RDATA;
	}
}
