﻿using System;

namespace Heijden.DNS
{
	// Token: 0x0200003D RID: 61
	public class RecordKEY : Record
	{
		// Token: 0x0600010B RID: 267 RVA: 0x00004FC6 File Offset: 0x000031C6
		public RecordKEY(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.FLAGS = rr.method_0();
			this.PROTOCOL = rr.ReadByte();
			this.ALGORITHM = rr.ReadByte();
			this.PUBLICKEY = rr.ReadString();
		}

		// Token: 0x0600010C RID: 268 RVA: 0x00009974 File Offset: 0x00007B74
		public override string ToString()
		{
			return string.Format("{0} {1} {2} \"{3}\"", new object[]
			{
				this.FLAGS,
				this.PROTOCOL,
				this.ALGORITHM,
				this.PUBLICKEY
			});
		}

		// Token: 0x04000067 RID: 103
		public ushort FLAGS;

		// Token: 0x04000068 RID: 104
		public byte PROTOCOL;

		// Token: 0x04000069 RID: 105
		public byte ALGORITHM;

		// Token: 0x0400006A RID: 106
		public string PUBLICKEY;
	}
}
