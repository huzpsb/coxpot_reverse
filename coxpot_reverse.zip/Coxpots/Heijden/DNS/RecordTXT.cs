﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000052 RID: 82
	public class RecordTXT : Record
	{
		// Token: 0x0600013C RID: 316 RVA: 0x000051D2 File Offset: 0x000033D2
		public RecordTXT(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.TXT = rr.ReadString();
		}

		// Token: 0x0600013D RID: 317 RVA: 0x0000A5FC File Offset: 0x000087FC
		public override string ToString()
		{
			return string.Format("\"{0}\"", this.TXT);
		}

		// Token: 0x040000B3 RID: 179
		public string TXT;
	}
}
