﻿using System;

namespace Heijden.DNS
{
	// Token: 0x0200001A RID: 26
	public class RecordATMA : Record
	{
		// Token: 0x060000C6 RID: 198 RVA: 0x00009130 File Offset: 0x00007330
		public RecordATMA(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			ushort intLength = rr.method_1(-2);
			this.RDATA = rr.ReadBytes((int)intLength);
		}

		// Token: 0x060000C7 RID: 199 RVA: 0x000090E0 File Offset: 0x000072E0
		public override string ToString()
		{
			return string.Format("not-used", new object[0]);
		}

		// Token: 0x0400003B RID: 59
		public byte[] RDATA;
	}
}
