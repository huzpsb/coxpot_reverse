﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000050 RID: 80
	public class RecordTKEY : Record
	{
		// Token: 0x06000138 RID: 312 RVA: 0x0000A3E4 File Offset: 0x000085E4
		public RecordTKEY(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.ALGORITHM = rr.ReadDomainName();
			this.INCEPTION = rr.method_2();
			this.EXPIRATION = rr.method_2();
			this.MODE = rr.method_0();
			this.ERROR = rr.method_0();
			this.KEYSIZE = rr.method_0();
			this.KEYDATA = rr.ReadBytes((int)this.KEYSIZE);
			this.OTHERSIZE = rr.method_0();
			this.OTHERDATA = rr.ReadBytes((int)this.OTHERSIZE);
		}

		// Token: 0x06000139 RID: 313 RVA: 0x0000A474 File Offset: 0x00008674
		public override string ToString()
		{
			return string.Format("{0} {1} {2} {3} {4}", new object[]
			{
				this.ALGORITHM,
				this.INCEPTION,
				this.EXPIRATION,
				this.MODE,
				this.ERROR
			});
		}

		// Token: 0x040000A1 RID: 161
		public string ALGORITHM;

		// Token: 0x040000A2 RID: 162
		public uint INCEPTION;

		// Token: 0x040000A3 RID: 163
		public uint EXPIRATION;

		// Token: 0x040000A4 RID: 164
		public ushort MODE;

		// Token: 0x040000A5 RID: 165
		public ushort ERROR;

		// Token: 0x040000A6 RID: 166
		public ushort KEYSIZE;

		// Token: 0x040000A7 RID: 167
		public byte[] KEYDATA;

		// Token: 0x040000A8 RID: 168
		public ushort OTHERSIZE;

		// Token: 0x040000A9 RID: 169
		public byte[] OTHERDATA;
	}
}
