﻿using System;

namespace Heijden.DNS
{
	// Token: 0x0200001F RID: 31
	public class RecordGID : Record
	{
		// Token: 0x060000D0 RID: 208 RVA: 0x00009220 File Offset: 0x00007420
		public RecordGID(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			ushort intLength = rr.method_1(-2);
			this.RDATA = rr.ReadBytes((int)intLength);
		}

		// Token: 0x060000D1 RID: 209 RVA: 0x000090E0 File Offset: 0x000072E0
		public override string ToString()
		{
			return string.Format("not-used", new object[0]);
		}

		// Token: 0x04000040 RID: 64
		public byte[] RDATA;
	}
}
