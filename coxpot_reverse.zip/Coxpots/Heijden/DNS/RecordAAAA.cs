﻿using System;
using System.Net;

namespace Heijden.DNS
{
	// Token: 0x02000036 RID: 54
	public class RecordAAAA : Record
	{
		// Token: 0x060000FD RID: 253 RVA: 0x0000971C File Offset: 0x0000791C
		public RecordAAAA(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			IPAddress.TryParse(string.Format("{0:x}:{1:x}:{2:x}:{3:x}:{4:x}:{5:x}:{6:x}:{7:x}", new object[]
			{
				rr.method_0(),
				rr.method_0(),
				rr.method_0(),
				rr.method_0(),
				rr.method_0(),
				rr.method_0(),
				rr.method_0(),
				rr.method_0()
			}), out this.Address);
		}

		// Token: 0x060000FE RID: 254 RVA: 0x000097C0 File Offset: 0x000079C0
		public override string ToString()
		{
			return this.Address.ToString();
		}

		// Token: 0x0400005A RID: 90
		public IPAddress Address;
	}
}
