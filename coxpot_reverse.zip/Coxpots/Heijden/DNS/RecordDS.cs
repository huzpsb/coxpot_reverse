﻿using System;
using System.Text;

namespace Heijden.DNS
{
	// Token: 0x0200003A RID: 58
	public class RecordDS : Record
	{
		// Token: 0x06000105 RID: 261 RVA: 0x00009838 File Offset: 0x00007A38
		public RecordDS(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			ushort num = rr.method_1(-2);
			this.KEYTAG = rr.method_0();
			this.ALGORITHM = rr.ReadByte();
			this.DIGESTTYPE = rr.ReadByte();
			num -= 4;
			this.DIGEST = new byte[(int)num];
			this.DIGEST = rr.ReadBytes((int)num);
		}

		// Token: 0x06000106 RID: 262 RVA: 0x0000989C File Offset: 0x00007A9C
		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			for (int i = 0; i < this.DIGEST.Length; i++)
			{
				stringBuilder.AppendFormat("{0:x2}", this.DIGEST[i]);
			}
			return string.Format("{0} {1} {2} {3}", new object[]
			{
				this.KEYTAG,
				this.ALGORITHM,
				this.DIGESTTYPE,
				stringBuilder.ToString()
			});
		}

		// Token: 0x0400005F RID: 95
		public ushort KEYTAG;

		// Token: 0x04000060 RID: 96
		public byte ALGORITHM;

		// Token: 0x04000061 RID: 97
		public byte DIGESTTYPE;

		// Token: 0x04000062 RID: 98
		public byte[] DIGEST;
	}
}
