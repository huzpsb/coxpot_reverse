﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000040 RID: 64
	public class RecordMB : Record
	{
		// Token: 0x06000116 RID: 278 RVA: 0x00005028 File Offset: 0x00003228
		public RecordMB(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.MADNAME = rr.ReadDomainName();
		}

		// Token: 0x06000117 RID: 279 RVA: 0x00009D18 File Offset: 0x00007F18
		public override string ToString()
		{
			return this.MADNAME;
		}

		// Token: 0x04000074 RID: 116
		public string MADNAME;
	}
}
