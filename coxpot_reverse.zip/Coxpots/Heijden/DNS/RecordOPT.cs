﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000026 RID: 38
	public class RecordOPT : Record
	{
		// Token: 0x060000DE RID: 222 RVA: 0x00009370 File Offset: 0x00007570
		public RecordOPT(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			ushort intLength = rr.method_1(-2);
			this.RDATA = rr.ReadBytes((int)intLength);
		}

		// Token: 0x060000DF RID: 223 RVA: 0x000090E0 File Offset: 0x000072E0
		public override string ToString()
		{
			return string.Format("not-used", new object[0]);
		}

		// Token: 0x04000047 RID: 71
		public byte[] RDATA;
	}
}
