﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000032 RID: 50
	public class RecordNSAPPTR : Record
	{
		// Token: 0x060000F5 RID: 245 RVA: 0x00004F0C File Offset: 0x0000310C
		public RecordNSAPPTR(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.OWNER = rr.ReadString();
		}

		// Token: 0x060000F6 RID: 246 RVA: 0x0000957C File Offset: 0x0000777C
		public override string ToString()
		{
			return string.Format("{0}", this.OWNER);
		}

		// Token: 0x04000055 RID: 85
		public string OWNER;
	}
}
