﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000064 RID: 100
	public class AdditionalRR : RR
	{
		// Token: 0x060001A7 RID: 423 RVA: 0x000053C5 File Offset: 0x000035C5
		public AdditionalRR(RecordReader br)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor(br);
		}
	}
}
