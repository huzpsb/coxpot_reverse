﻿using System;
using System.Text;

namespace Heijden.DNS
{
	// Token: 0x02000047 RID: 71
	public class RecordNSAP : Record
	{
		// Token: 0x06000125 RID: 293 RVA: 0x000050D6 File Offset: 0x000032D6
		public RecordNSAP(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.LENGTH = rr.method_0();
			this.NSAPADDRESS = rr.ReadBytes((int)this.LENGTH);
		}

		// Token: 0x06000126 RID: 294 RVA: 0x00009EE8 File Offset: 0x000080E8
		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendFormat("{0} ", this.LENGTH);
			for (int i = 0; i < this.NSAPADDRESS.Length; i++)
			{
				stringBuilder.AppendFormat("{0:X00}", this.NSAPADDRESS[i]);
			}
			return stringBuilder.ToString();
		}

		// Token: 0x06000127 RID: 295 RVA: 0x00009F48 File Offset: 0x00008148
		public string method_0()
		{
			return string.Format("{0:X}.{1:X}.{2:X}.{3:X}.{4:X}.{5:X}.{6:X}{7:X}.{8:X}", new object[]
			{
				this.NSAPADDRESS[0],
				(int)this.NSAPADDRESS[1] << 8 | (int)this.NSAPADDRESS[2],
				this.NSAPADDRESS[3],
				(int)this.NSAPADDRESS[4] << 16 | (int)this.NSAPADDRESS[5] << 8 | (int)this.NSAPADDRESS[6],
				(int)this.NSAPADDRESS[7] << 8 | (int)this.NSAPADDRESS[8],
				(int)this.NSAPADDRESS[9] << 8 | (int)this.NSAPADDRESS[10],
				(int)this.NSAPADDRESS[11] << 8 | (int)this.NSAPADDRESS[12],
				(int)this.NSAPADDRESS[13] << 16 | (int)this.NSAPADDRESS[14] << 8 | (int)this.NSAPADDRESS[15],
				(int)this.NSAPADDRESS[16] << 16 | (int)this.NSAPADDRESS[17] << 8 | (int)this.NSAPADDRESS[18],
				this.NSAPADDRESS[19]
			});
		}

		// Token: 0x04000082 RID: 130
		public ushort LENGTH;

		// Token: 0x04000083 RID: 131
		public byte[] NSAPADDRESS;
	}
}
