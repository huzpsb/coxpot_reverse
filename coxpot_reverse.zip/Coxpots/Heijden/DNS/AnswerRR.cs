﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000062 RID: 98
	public class AnswerRR : RR
	{
		// Token: 0x060001A5 RID: 421 RVA: 0x000053C5 File Offset: 0x000035C5
		public AnswerRR(RecordReader br)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor(br);
		}
	}
}
