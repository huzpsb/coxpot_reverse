﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000065 RID: 101
	public enum Type : ushort
	{
		// Token: 0x040000D9 RID: 217
		A = 1,
		// Token: 0x040000DA RID: 218
		NS,
		// Token: 0x040000DB RID: 219
		MD,
		// Token: 0x040000DC RID: 220
		MF,
		// Token: 0x040000DD RID: 221
		CNAME,
		// Token: 0x040000DE RID: 222
		SOA,
		// Token: 0x040000DF RID: 223
		MB,
		// Token: 0x040000E0 RID: 224
		MG,
		// Token: 0x040000E1 RID: 225
		MR,
		// Token: 0x040000E2 RID: 226
		NULL,
		// Token: 0x040000E3 RID: 227
		WKS,
		// Token: 0x040000E4 RID: 228
		PTR,
		// Token: 0x040000E5 RID: 229
		HINFO,
		// Token: 0x040000E6 RID: 230
		MINFO,
		// Token: 0x040000E7 RID: 231
		MX,
		// Token: 0x040000E8 RID: 232
		TXT,
		// Token: 0x040000E9 RID: 233
		RP,
		// Token: 0x040000EA RID: 234
		AFSDB,
		// Token: 0x040000EB RID: 235
		X25,
		// Token: 0x040000EC RID: 236
		ISDN,
		// Token: 0x040000ED RID: 237
		RT,
		// Token: 0x040000EE RID: 238
		NSAP,
		// Token: 0x040000EF RID: 239
		NSAPPTR,
		// Token: 0x040000F0 RID: 240
		SIG,
		// Token: 0x040000F1 RID: 241
		KEY,
		// Token: 0x040000F2 RID: 242
		PX,
		// Token: 0x040000F3 RID: 243
		GPOS,
		// Token: 0x040000F4 RID: 244
		AAAA,
		// Token: 0x040000F5 RID: 245
		LOC,
		// Token: 0x040000F6 RID: 246
		NXT,
		// Token: 0x040000F7 RID: 247
		EID,
		// Token: 0x040000F8 RID: 248
		NIMLOC,
		// Token: 0x040000F9 RID: 249
		SRV,
		// Token: 0x040000FA RID: 250
		ATMA,
		// Token: 0x040000FB RID: 251
		NAPTR,
		// Token: 0x040000FC RID: 252
		KX,
		// Token: 0x040000FD RID: 253
		CERT,
		// Token: 0x040000FE RID: 254
		A6,
		// Token: 0x040000FF RID: 255
		DNAME,
		// Token: 0x04000100 RID: 256
		SINK,
		// Token: 0x04000101 RID: 257
		OPT,
		// Token: 0x04000102 RID: 258
		APL,
		// Token: 0x04000103 RID: 259
		DS,
		// Token: 0x04000104 RID: 260
		SSHFP,
		// Token: 0x04000105 RID: 261
		IPSECKEY,
		// Token: 0x04000106 RID: 262
		RRSIG,
		// Token: 0x04000107 RID: 263
		NSEC,
		// Token: 0x04000108 RID: 264
		DNSKEY,
		// Token: 0x04000109 RID: 265
		DHCID,
		// Token: 0x0400010A RID: 266
		NSEC3,
		// Token: 0x0400010B RID: 267
		const_50,
		// Token: 0x0400010C RID: 268
		HIP = 55,
		// Token: 0x0400010D RID: 269
		SPF = 99,
		// Token: 0x0400010E RID: 270
		UINFO,
		// Token: 0x0400010F RID: 271
		UID,
		// Token: 0x04000110 RID: 272
		GID,
		// Token: 0x04000111 RID: 273
		UNSPEC,
		// Token: 0x04000112 RID: 274
		TKEY = 249,
		// Token: 0x04000113 RID: 275
		TSIG,
		// Token: 0x04000114 RID: 276
		TA = 32768,
		// Token: 0x04000115 RID: 277
		DLV
	}
}
