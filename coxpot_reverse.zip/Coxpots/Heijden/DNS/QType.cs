﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000066 RID: 102
	public enum QType : ushort
	{
		// Token: 0x04000117 RID: 279
		A = 1,
		// Token: 0x04000118 RID: 280
		NS,
		// Token: 0x04000119 RID: 281
		MD,
		// Token: 0x0400011A RID: 282
		MF,
		// Token: 0x0400011B RID: 283
		CNAME,
		// Token: 0x0400011C RID: 284
		SOA,
		// Token: 0x0400011D RID: 285
		MB,
		// Token: 0x0400011E RID: 286
		MG,
		// Token: 0x0400011F RID: 287
		MR,
		// Token: 0x04000120 RID: 288
		NULL,
		// Token: 0x04000121 RID: 289
		WKS,
		// Token: 0x04000122 RID: 290
		PTR,
		// Token: 0x04000123 RID: 291
		HINFO,
		// Token: 0x04000124 RID: 292
		MINFO,
		// Token: 0x04000125 RID: 293
		MX,
		// Token: 0x04000126 RID: 294
		TXT,
		// Token: 0x04000127 RID: 295
		RP,
		// Token: 0x04000128 RID: 296
		AFSDB,
		// Token: 0x04000129 RID: 297
		X25,
		// Token: 0x0400012A RID: 298
		ISDN,
		// Token: 0x0400012B RID: 299
		RT,
		// Token: 0x0400012C RID: 300
		NSAP,
		// Token: 0x0400012D RID: 301
		NSAP_PTR,
		// Token: 0x0400012E RID: 302
		SIG,
		// Token: 0x0400012F RID: 303
		KEY,
		// Token: 0x04000130 RID: 304
		PX,
		// Token: 0x04000131 RID: 305
		GPOS,
		// Token: 0x04000132 RID: 306
		AAAA,
		// Token: 0x04000133 RID: 307
		LOC,
		// Token: 0x04000134 RID: 308
		NXT,
		// Token: 0x04000135 RID: 309
		EID,
		// Token: 0x04000136 RID: 310
		NIMLOC,
		// Token: 0x04000137 RID: 311
		SRV,
		// Token: 0x04000138 RID: 312
		ATMA,
		// Token: 0x04000139 RID: 313
		NAPTR,
		// Token: 0x0400013A RID: 314
		KX,
		// Token: 0x0400013B RID: 315
		CERT,
		// Token: 0x0400013C RID: 316
		A6,
		// Token: 0x0400013D RID: 317
		DNAME,
		// Token: 0x0400013E RID: 318
		SINK,
		// Token: 0x0400013F RID: 319
		OPT,
		// Token: 0x04000140 RID: 320
		APL,
		// Token: 0x04000141 RID: 321
		DS,
		// Token: 0x04000142 RID: 322
		SSHFP,
		// Token: 0x04000143 RID: 323
		IPSECKEY,
		// Token: 0x04000144 RID: 324
		RRSIG,
		// Token: 0x04000145 RID: 325
		NSEC,
		// Token: 0x04000146 RID: 326
		DNSKEY,
		// Token: 0x04000147 RID: 327
		DHCID,
		// Token: 0x04000148 RID: 328
		NSEC3,
		// Token: 0x04000149 RID: 329
		const_50,
		// Token: 0x0400014A RID: 330
		HIP = 55,
		// Token: 0x0400014B RID: 331
		SPF = 99,
		// Token: 0x0400014C RID: 332
		UINFO,
		// Token: 0x0400014D RID: 333
		UID,
		// Token: 0x0400014E RID: 334
		GID,
		// Token: 0x0400014F RID: 335
		UNSPEC,
		// Token: 0x04000150 RID: 336
		TKEY = 249,
		// Token: 0x04000151 RID: 337
		TSIG,
		// Token: 0x04000152 RID: 338
		IXFR,
		// Token: 0x04000153 RID: 339
		AXFR,
		// Token: 0x04000154 RID: 340
		MAILB,
		// Token: 0x04000155 RID: 341
		MAILA,
		// Token: 0x04000156 RID: 342
		ANY,
		// Token: 0x04000157 RID: 343
		TA = 32768,
		// Token: 0x04000158 RID: 344
		DLV
	}
}
