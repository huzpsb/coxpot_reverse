﻿using System;

namespace Heijden.DNS
{
	// Token: 0x0200002F RID: 47
	public class RecordGPOS : Record
	{
		// Token: 0x060000EF RID: 239 RVA: 0x00004EA9 File Offset: 0x000030A9
		public RecordGPOS(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.LONGITUDE = rr.ReadString();
			this.LATITUDE = rr.ReadString();
			this.ALTITUDE = rr.ReadString();
		}

		// Token: 0x060000F0 RID: 240 RVA: 0x00009520 File Offset: 0x00007720
		public override string ToString()
		{
			return string.Format("{0} {1} {2}", this.LONGITUDE, this.LATITUDE, this.ALTITUDE);
		}

		// Token: 0x04000050 RID: 80
		public string LONGITUDE;

		// Token: 0x04000051 RID: 81
		public string LATITUDE;

		// Token: 0x04000052 RID: 82
		public string ALTITUDE;
	}
}
