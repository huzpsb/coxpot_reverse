﻿using System;

namespace Heijden.DNS
{
	// Token: 0x0200002A RID: 42
	public class RecordSSHFP : Record
	{
		// Token: 0x060000E6 RID: 230 RVA: 0x00009430 File Offset: 0x00007630
		public RecordSSHFP(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			ushort intLength = rr.method_1(-2);
			this.RDATA = rr.ReadBytes((int)intLength);
		}

		// Token: 0x060000E7 RID: 231 RVA: 0x000090E0 File Offset: 0x000072E0
		public override string ToString()
		{
			return string.Format("not-used", new object[0]);
		}

		// Token: 0x0400004B RID: 75
		public byte[] RDATA;
	}
}
