﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Heijden.DNS
{
	// Token: 0x02000017 RID: 23
	public class RecordReader
	{
		// Token: 0x060000B5 RID: 181 RVA: 0x00004E6A File Offset: 0x0000306A
		public RecordReader(byte[] data)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.byte_0 = data;
			this.int_0 = 0;
		}

		// Token: 0x17000027 RID: 39
		// (get) Token: 0x060000B6 RID: 182 RVA: 0x00008A58 File Offset: 0x00006C58
		// (set) Token: 0x060000B7 RID: 183 RVA: 0x00004E85 File Offset: 0x00003085
		public int Position
		{
			get
			{
				return this.int_0;
			}
			set
			{
				this.int_0 = value;
			}
		}

		// Token: 0x060000B8 RID: 184 RVA: 0x00004E8E File Offset: 0x0000308E
		public RecordReader(byte[] data, int Position)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.byte_0 = data;
			this.int_0 = Position;
		}

		// Token: 0x060000B9 RID: 185 RVA: 0x00008A70 File Offset: 0x00006C70
		public byte ReadByte()
		{
			byte result;
			if (this.int_0 >= this.byte_0.Length)
			{
				result = 0;
			}
			else
			{
				byte[] array = this.byte_0;
				int num = this.int_0;
				this.int_0 = num + 1;
				result = array[num];
			}
			return result;
		}

		// Token: 0x060000BA RID: 186 RVA: 0x00008AB0 File Offset: 0x00006CB0
		public char ReadChar()
		{
			return (char)this.ReadByte();
		}

		// Token: 0x060000BB RID: 187 RVA: 0x00008AC8 File Offset: 0x00006CC8
		public ushort method_0()
		{
			return (ushort)((int)this.ReadByte() << 8 | (int)this.ReadByte());
		}

		// Token: 0x060000BC RID: 188 RVA: 0x00008AE8 File Offset: 0x00006CE8
		public ushort method_1(int offset)
		{
			this.int_0 += offset;
			return this.method_0();
		}

		// Token: 0x060000BD RID: 189 RVA: 0x00008B0C File Offset: 0x00006D0C
		public uint method_2()
		{
			return (uint)((int)this.method_0() << 16 | (int)this.method_0());
		}

		// Token: 0x060000BE RID: 190 RVA: 0x00008B2C File Offset: 0x00006D2C
		public string ReadDomainName()
		{
			StringBuilder stringBuilder = new StringBuilder();
			int i;
			while ((i = (int)this.ReadByte()) != 0)
			{
				if ((i & 192) == 192)
				{
					RecordReader recordReader = new RecordReader(this.byte_0, (i & 63) << 8 | (int)this.ReadByte());
					stringBuilder.Append(recordReader.ReadDomainName());
					return stringBuilder.ToString();
				}
				while (i > 0)
				{
					stringBuilder.Append(this.ReadChar());
					i--;
				}
				stringBuilder.Append('.');
			}
			if (stringBuilder.Length == 0)
			{
				return ".";
			}
			return stringBuilder.ToString();
		}

		// Token: 0x060000BF RID: 191 RVA: 0x00008BCC File Offset: 0x00006DCC
		public string ReadString()
		{
			short num = (short)this.ReadByte();
			StringBuilder stringBuilder = new StringBuilder();
			for (int i = 0; i < (int)num; i++)
			{
				stringBuilder.Append(this.ReadChar());
			}
			return stringBuilder.ToString();
		}

		// Token: 0x060000C0 RID: 192 RVA: 0x00008C0C File Offset: 0x00006E0C
		public byte[] ReadBytes(int intLength)
		{
			List<byte> list = new List<byte>();
			for (int i = 0; i < intLength; i++)
			{
				list.Add(this.ReadByte());
			}
			return list.ToArray();
		}

		// Token: 0x060000C1 RID: 193 RVA: 0x00008C44 File Offset: 0x00006E44
		public Record ReadRecord(Type type)
		{
			switch (type)
			{
			case Type.A:
				return new RecordA(this);
			case Type.NS:
				return new RecordNS(this);
			case Type.MD:
				return new RecordMD(this);
			case Type.MF:
				return new RecordMF(this);
			case Type.CNAME:
				return new RecordCNAME(this);
			case Type.SOA:
				return new RecordSOA(this);
			case Type.MB:
				return new RecordMB(this);
			case Type.MG:
				return new RecordMG(this);
			case Type.MR:
				return new RecordMR(this);
			case Type.NULL:
				return new RecordNULL(this);
			case Type.WKS:
				return new RecordWKS(this);
			case Type.PTR:
				return new RecordPTR(this);
			case Type.HINFO:
				return new RecordHINFO(this);
			case Type.MINFO:
				return new RecordMINFO(this);
			case Type.MX:
				return new RecordMX(this);
			case Type.TXT:
				return new RecordTXT(this);
			case Type.RP:
				return new RecordRP(this);
			case Type.AFSDB:
				return new RecordAFSDB(this);
			case Type.X25:
				return new RecordX25(this);
			case Type.ISDN:
				return new RecordISDN(this);
			case Type.RT:
				return new RecordRT(this);
			case Type.NSAP:
				return new RecordNSAP(this);
			case Type.NSAPPTR:
				return new RecordNSAPPTR(this);
			case Type.SIG:
				return new RecordSIG(this);
			case Type.KEY:
				return new RecordKEY(this);
			case Type.PX:
				return new RecordPX(this);
			case Type.GPOS:
				return new RecordGPOS(this);
			case Type.AAAA:
				return new RecordAAAA(this);
			case Type.LOC:
				return new RecordLOC(this);
			case Type.NXT:
				return new RecordNXT(this);
			case Type.EID:
				return new RecordEID(this);
			case Type.NIMLOC:
				return new RecordNIMLOC(this);
			case Type.SRV:
				return new RecordSRV(this);
			case Type.ATMA:
				return new RecordATMA(this);
			case Type.NAPTR:
				return new RecordNAPTR(this);
			case Type.KX:
				return new RecordKX(this);
			case Type.CERT:
				return new RecordCERT(this);
			case Type.A6:
				return new RecordA6(this);
			case Type.DNAME:
				return new RecordDNAME(this);
			case Type.SINK:
				return new RecordSINK(this);
			case Type.OPT:
				return new RecordOPT(this);
			case Type.APL:
				return new RecordAPL(this);
			case Type.DS:
				return new RecordDS(this);
			case Type.SSHFP:
				return new RecordSSHFP(this);
			case Type.IPSECKEY:
				return new RecordIPSECKEY(this);
			case Type.RRSIG:
				return new RecordRRSIG(this);
			case Type.NSEC:
				return new RecordNSEC(this);
			case Type.DNSKEY:
				return new RecordDNSKEY(this);
			case Type.DHCID:
				return new RecordDHCID(this);
			case Type.NSEC3:
				return new RecordNSEC3(this);
			case Type.const_50:
				return new RecordNSEC3PARAM(this);
			case (Type)52:
			case (Type)53:
			case (Type)54:
			case (Type)56:
			case (Type)57:
			case (Type)58:
			case (Type)59:
			case (Type)60:
			case (Type)61:
			case (Type)62:
			case (Type)63:
			case (Type)64:
			case (Type)65:
			case (Type)66:
			case (Type)67:
			case (Type)68:
			case (Type)69:
			case (Type)70:
			case (Type)71:
			case (Type)72:
			case (Type)73:
			case (Type)74:
			case (Type)75:
			case (Type)76:
			case (Type)77:
			case (Type)78:
			case (Type)79:
			case (Type)80:
			case (Type)81:
			case (Type)82:
			case (Type)83:
			case (Type)84:
			case (Type)85:
			case (Type)86:
			case (Type)87:
			case (Type)88:
			case (Type)89:
			case (Type)90:
			case (Type)91:
			case (Type)92:
			case (Type)93:
			case (Type)94:
			case (Type)95:
			case (Type)96:
			case (Type)97:
			case (Type)98:
				break;
			case Type.HIP:
				return new RecordHIP(this);
			case Type.SPF:
				return new RecordSPF(this);
			case Type.UINFO:
				return new RecordUINFO(this);
			case Type.UID:
				return new RecordUID(this);
			case Type.GID:
				return new RecordGID(this);
			case Type.UNSPEC:
				return new RecordUNSPEC(this);
			default:
				if (type == Type.TKEY)
				{
					return new RecordTKEY(this);
				}
				if (type == Type.TSIG)
				{
					return new RecordTSIG(this);
				}
				break;
			}
			return new RecordUnknown(this);
		}

		// Token: 0x04000037 RID: 55
		private byte[] byte_0;

		// Token: 0x04000038 RID: 56
		private int int_0;
	}
}
