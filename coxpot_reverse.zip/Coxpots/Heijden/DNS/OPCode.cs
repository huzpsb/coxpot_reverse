﻿using System;

namespace Heijden.DNS
{
	// Token: 0x0200006A RID: 106
	public enum OPCode
	{
		// Token: 0x0400017D RID: 381
		Query,
		// Token: 0x0400017E RID: 382
		IQUERY,
		// Token: 0x0400017F RID: 383
		Status,
		// Token: 0x04000180 RID: 384
		const_3,
		// Token: 0x04000181 RID: 385
		Notify,
		// Token: 0x04000182 RID: 386
		Update,
		// Token: 0x04000183 RID: 387
		const_6,
		// Token: 0x04000184 RID: 388
		const_7,
		// Token: 0x04000185 RID: 389
		const_8,
		// Token: 0x04000186 RID: 390
		const_9,
		// Token: 0x04000187 RID: 391
		const_10,
		// Token: 0x04000188 RID: 392
		const_11,
		// Token: 0x04000189 RID: 393
		const_12,
		// Token: 0x0400018A RID: 394
		const_13,
		// Token: 0x0400018B RID: 395
		const_14,
		// Token: 0x0400018C RID: 396
		const_15
	}
}
