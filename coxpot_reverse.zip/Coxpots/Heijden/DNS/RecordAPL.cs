﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000019 RID: 25
	public class RecordAPL : Record
	{
		// Token: 0x060000C4 RID: 196 RVA: 0x00009100 File Offset: 0x00007300
		public RecordAPL(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			ushort intLength = rr.method_1(-2);
			this.RDATA = rr.ReadBytes((int)intLength);
		}

		// Token: 0x060000C5 RID: 197 RVA: 0x000090E0 File Offset: 0x000072E0
		public override string ToString()
		{
			return string.Format("not-used", new object[0]);
		}

		// Token: 0x0400003A RID: 58
		public byte[] RDATA;
	}
}
