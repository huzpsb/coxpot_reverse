﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000018 RID: 24
	public class RecordA6 : Record
	{
		// Token: 0x060000C2 RID: 194 RVA: 0x000090B0 File Offset: 0x000072B0
		public RecordA6(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			ushort intLength = rr.method_1(-2);
			this.RDATA = rr.ReadBytes((int)intLength);
		}

		// Token: 0x060000C3 RID: 195 RVA: 0x000090E0 File Offset: 0x000072E0
		public override string ToString()
		{
			return string.Format("not-used", new object[0]);
		}

		// Token: 0x04000039 RID: 57
		public byte[] RDATA;
	}
}
