﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000027 RID: 39
	public class RecordRRSIG : Record
	{
		// Token: 0x060000E0 RID: 224 RVA: 0x000093A0 File Offset: 0x000075A0
		public RecordRRSIG(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			ushort intLength = rr.method_1(-2);
			this.RDATA = rr.ReadBytes((int)intLength);
		}

		// Token: 0x060000E1 RID: 225 RVA: 0x000090E0 File Offset: 0x000072E0
		public override string ToString()
		{
			return string.Format("not-used", new object[0]);
		}

		// Token: 0x04000048 RID: 72
		public byte[] RDATA;
	}
}
