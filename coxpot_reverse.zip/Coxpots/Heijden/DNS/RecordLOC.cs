﻿using System;
using System.Text;

namespace Heijden.DNS
{
	// Token: 0x0200003F RID: 63
	public class RecordLOC : Record
	{
		// Token: 0x06000110 RID: 272 RVA: 0x00009A50 File Offset: 0x00007C50
		private string method_0(byte byte_0)
		{
			string value = "cm";
			int num = byte_0 >> 4;
			int i = (int)(byte_0 & 15);
			if (i >= 2)
			{
				i -= 2;
				value = "m";
			}
			StringBuilder stringBuilder = new StringBuilder();
			stringBuilder.AppendFormat("{0}", num);
			while (i > 0)
			{
				stringBuilder.Append('0');
				i--;
			}
			stringBuilder.Append(value);
			return stringBuilder.ToString();
		}

		// Token: 0x06000111 RID: 273 RVA: 0x00009AC0 File Offset: 0x00007CC0
		private string method_1(uint uint_0)
		{
			uint num = 2147483648u;
			char c = 'E';
			if (uint_0 > 2147483648u)
			{
				c = 'W';
				uint_0 -= num;
			}
			double num2 = uint_0 / 3600000.0;
			double num3 = 60.0 * (num2 - (double)((int)num2));
			double num4 = 60.0 * (num3 - (double)((int)num3));
			return string.Format("{0} {1} {2:0.000} {3}", new object[]
			{
				(int)num2,
				(int)num3,
				num4,
				c
			});
		}

		// Token: 0x06000112 RID: 274 RVA: 0x00009B54 File Offset: 0x00007D54
		private string method_2(uint uint_0, char char_0, char char_1)
		{
			uint num = 2147483648u;
			char c;
			if (uint_0 > 2147483648u)
			{
				c = char_1;
				uint_0 -= num;
			}
			else
			{
				c = char_0;
				uint_0 = num - uint_0;
			}
			double num2 = uint_0 / 3600000.0;
			double num3 = 60.0 * (num2 - (double)((int)num2));
			double num4 = 60.0 * (num3 - (double)((int)num3));
			return string.Format("{0} {1} {2:0.000} {3}", new object[]
			{
				(int)num2,
				(int)num3,
				num4,
				c
			});
		}

		// Token: 0x06000113 RID: 275 RVA: 0x00009BF0 File Offset: 0x00007DF0
		private string method_3(uint uint_0)
		{
			double num = uint_0 / 100.0 - 100000.0;
			return string.Format("{0:0.00}m", num);
		}

		// Token: 0x06000114 RID: 276 RVA: 0x00009C28 File Offset: 0x00007E28
		public RecordLOC(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.VERSION = rr.ReadByte();
			this.SIZE = rr.ReadByte();
			this.HORIZPRE = rr.ReadByte();
			this.VERTPRE = rr.ReadByte();
			this.LATITUDE = rr.method_2();
			this.LONGITUDE = rr.method_2();
			this.ALTITUDE = rr.method_2();
		}

		// Token: 0x06000115 RID: 277 RVA: 0x00009C94 File Offset: 0x00007E94
		public override string ToString()
		{
			return string.Format("{0} {1} {2} {3} {4} {5}", new object[]
			{
				this.method_2(this.LATITUDE, 'S', 'N'),
				this.method_2(this.LONGITUDE, 'W', 'E'),
				this.method_3(this.ALTITUDE),
				this.method_0(this.SIZE),
				this.method_0(this.HORIZPRE),
				this.method_0(this.VERTPRE)
			});
		}

		// Token: 0x0400006D RID: 109
		public byte VERSION;

		// Token: 0x0400006E RID: 110
		public byte SIZE;

		// Token: 0x0400006F RID: 111
		public byte HORIZPRE;

		// Token: 0x04000070 RID: 112
		public byte VERTPRE;

		// Token: 0x04000071 RID: 113
		public uint LATITUDE;

		// Token: 0x04000072 RID: 114
		public uint LONGITUDE;

		// Token: 0x04000073 RID: 115
		public uint ALTITUDE;
	}
}
