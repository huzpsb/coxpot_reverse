﻿using System;
using System.Collections.Generic;
using System.Net;

namespace Heijden.DNS
{
	// Token: 0x02000060 RID: 96
	public class Response
	{
		// Token: 0x06000195 RID: 405 RVA: 0x0000B7C8 File Offset: 0x000099C8
		public Response()
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.Questions = new List<Question>();
			this.Answers = new List<AnswerRR>();
			this.Authorities = new List<AuthorityRR>();
			this.Additionals = new List<AdditionalRR>();
			this.Server = new IPEndPoint(0L, 0);
			this.Error = "";
			this.MessageSize = 0;
			this.TimeStamp = DateTime.Now;
			this.header = new Header();
		}

		// Token: 0x06000196 RID: 406 RVA: 0x0000B84C File Offset: 0x00009A4C
		public Response(IPEndPoint ipendPoint_0, byte[] data)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.Error = "";
			this.Server = ipendPoint_0;
			this.TimeStamp = DateTime.Now;
			this.MessageSize = data.Length;
			RecordReader recordReader = new RecordReader(data);
			this.Questions = new List<Question>();
			this.Answers = new List<AnswerRR>();
			this.Authorities = new List<AuthorityRR>();
			this.Additionals = new List<AdditionalRR>();
			this.header = new Header(recordReader);
			for (int i = 0; i < (int)this.header.QDCOUNT; i++)
			{
				this.Questions.Add(new Question(recordReader));
			}
			for (int j = 0; j < (int)this.header.ANCOUNT; j++)
			{
				this.Answers.Add(new AnswerRR(recordReader));
			}
			for (int k = 0; k < (int)this.header.NSCOUNT; k++)
			{
				this.Authorities.Add(new AuthorityRR(recordReader));
			}
			for (int l = 0; l < (int)this.header.ARCOUNT; l++)
			{
				this.Additionals.Add(new AdditionalRR(recordReader));
			}
		}

		// Token: 0x17000031 RID: 49
		// (get) Token: 0x06000197 RID: 407 RVA: 0x0000B974 File Offset: 0x00009B74
		public RecordMX[] RecordsMX
		{
			get
			{
				List<RecordMX> list = new List<RecordMX>();
				foreach (AnswerRR answerRR in this.Answers)
				{
					RecordMX recordMX = answerRR.RECORD as RecordMX;
					if (recordMX != null)
					{
						list.Add(recordMX);
					}
				}
				list.Sort();
				return list.ToArray();
			}
		}

		// Token: 0x17000032 RID: 50
		// (get) Token: 0x06000198 RID: 408 RVA: 0x0000B9F0 File Offset: 0x00009BF0
		public RecordTXT[] RecordTXT_0
		{
			get
			{
				List<RecordTXT> list = new List<RecordTXT>();
				foreach (AnswerRR answerRR in this.Answers)
				{
					RecordTXT recordTXT = answerRR.RECORD as RecordTXT;
					if (recordTXT != null)
					{
						list.Add(recordTXT);
					}
				}
				return list.ToArray();
			}
		}

		// Token: 0x17000033 RID: 51
		// (get) Token: 0x06000199 RID: 409 RVA: 0x0000BA68 File Offset: 0x00009C68
		public RecordA[] RecordsA
		{
			get
			{
				List<RecordA> list = new List<RecordA>();
				foreach (AnswerRR answerRR in this.Answers)
				{
					RecordA recordA = answerRR.RECORD as RecordA;
					if (recordA != null)
					{
						list.Add(recordA);
					}
				}
				return list.ToArray();
			}
		}

		// Token: 0x17000034 RID: 52
		// (get) Token: 0x0600019A RID: 410 RVA: 0x0000BAE0 File Offset: 0x00009CE0
		public RecordPTR[] RecordPTR_0
		{
			get
			{
				List<RecordPTR> list = new List<RecordPTR>();
				foreach (AnswerRR answerRR in this.Answers)
				{
					RecordPTR recordPTR = answerRR.RECORD as RecordPTR;
					if (recordPTR != null)
					{
						list.Add(recordPTR);
					}
				}
				return list.ToArray();
			}
		}

		// Token: 0x17000035 RID: 53
		// (get) Token: 0x0600019B RID: 411 RVA: 0x0000BB58 File Offset: 0x00009D58
		public RecordCNAME[] RecordsCNAME
		{
			get
			{
				List<RecordCNAME> list = new List<RecordCNAME>();
				foreach (AnswerRR answerRR in this.Answers)
				{
					RecordCNAME recordCNAME = answerRR.RECORD as RecordCNAME;
					if (recordCNAME != null)
					{
						list.Add(recordCNAME);
					}
				}
				return list.ToArray();
			}
		}

		// Token: 0x17000036 RID: 54
		// (get) Token: 0x0600019C RID: 412 RVA: 0x0000BBD0 File Offset: 0x00009DD0
		public RecordAAAA[] RecordAAAA_0
		{
			get
			{
				List<RecordAAAA> list = new List<RecordAAAA>();
				foreach (AnswerRR answerRR in this.Answers)
				{
					RecordAAAA recordAAAA = answerRR.RECORD as RecordAAAA;
					if (recordAAAA != null)
					{
						list.Add(recordAAAA);
					}
				}
				return list.ToArray();
			}
		}

		// Token: 0x17000037 RID: 55
		// (get) Token: 0x0600019D RID: 413 RVA: 0x0000BC48 File Offset: 0x00009E48
		public RecordNS[] RecordsNS
		{
			get
			{
				List<RecordNS> list = new List<RecordNS>();
				foreach (AnswerRR answerRR in this.Answers)
				{
					RecordNS recordNS = answerRR.RECORD as RecordNS;
					if (recordNS != null)
					{
						list.Add(recordNS);
					}
				}
				return list.ToArray();
			}
		}

		// Token: 0x17000038 RID: 56
		// (get) Token: 0x0600019E RID: 414 RVA: 0x0000BCC0 File Offset: 0x00009EC0
		public RecordSOA[] RecordSOA_0
		{
			get
			{
				List<RecordSOA> list = new List<RecordSOA>();
				foreach (AnswerRR answerRR in this.Answers)
				{
					RecordSOA recordSOA = answerRR.RECORD as RecordSOA;
					if (recordSOA != null)
					{
						list.Add(recordSOA);
					}
				}
				return list.ToArray();
			}
		}

		// Token: 0x17000039 RID: 57
		// (get) Token: 0x0600019F RID: 415 RVA: 0x0000BD38 File Offset: 0x00009F38
		public RecordSRV[] RecordSRV_0
		{
			get
			{
				List<RecordSRV> list = new List<RecordSRV>();
				foreach (AnswerRR answerRR in this.Answers)
				{
					RecordSRV recordSRV = answerRR.RECORD as RecordSRV;
					if (recordSRV != null)
					{
						list.Add(recordSRV);
					}
				}
				return list.ToArray();
			}
		}

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x060001A0 RID: 416 RVA: 0x0000BDB0 File Offset: 0x00009FB0
		public RR[] RecordsRR
		{
			get
			{
				List<RR> list = new List<RR>();
				foreach (RR item in this.Answers)
				{
					list.Add(item);
				}
				foreach (RR item2 in this.Answers)
				{
					list.Add(item2);
				}
				foreach (RR item3 in this.Authorities)
				{
					list.Add(item3);
				}
				foreach (RR item4 in this.Additionals)
				{
					list.Add(item4);
				}
				return list.ToArray();
			}
		}

		// Token: 0x040000C8 RID: 200
		public List<Question> Questions;

		// Token: 0x040000C9 RID: 201
		public List<AnswerRR> Answers;

		// Token: 0x040000CA RID: 202
		public List<AuthorityRR> Authorities;

		// Token: 0x040000CB RID: 203
		public List<AdditionalRR> Additionals;

		// Token: 0x040000CC RID: 204
		public Header header;

		// Token: 0x040000CD RID: 205
		public string Error;

		// Token: 0x040000CE RID: 206
		public int MessageSize;

		// Token: 0x040000CF RID: 207
		public DateTime TimeStamp;

		// Token: 0x040000D0 RID: 208
		public IPEndPoint Server;
	}
}
