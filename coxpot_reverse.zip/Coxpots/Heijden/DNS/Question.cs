﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace Heijden.DNS
{
	// Token: 0x02000016 RID: 22
	public class Question
	{
		// Token: 0x17000025 RID: 37
		// (get) Token: 0x060000AD RID: 173 RVA: 0x000088F8 File Offset: 0x00006AF8
		// (set) Token: 0x060000AE RID: 174 RVA: 0x00004DE3 File Offset: 0x00002FE3
		public string QName
		{
			get
			{
				return this.string_0;
			}
			set
			{
				this.string_0 = value;
				if (!this.string_0.EndsWith("."))
				{
					this.string_0 += ".";
				}
			}
		}

		// Token: 0x060000AF RID: 175 RVA: 0x00004E17 File Offset: 0x00003017
		public Question(string QName, QType QType, QClass QClass)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.QName = QName;
			this.QType = QType;
			this.QClass = QClass;
		}

		// Token: 0x060000B0 RID: 176 RVA: 0x00004E39 File Offset: 0x00003039
		public Question(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.QName = rr.ReadDomainName();
			this.QType = (QType)rr.method_0();
			this.QClass = (QClass)rr.method_0();
		}

		// Token: 0x060000B1 RID: 177 RVA: 0x00008910 File Offset: 0x00006B10
		private byte[] method_0(string string_1)
		{
			if (!string_1.EndsWith("."))
			{
				string_1 += ".";
			}
			byte[] result;
			if (string_1 == ".")
			{
				result = new byte[1];
			}
			else
			{
				StringBuilder stringBuilder = new StringBuilder();
				int length = string_1.Length;
				stringBuilder.Append('\0');
				int i = 0;
				int num = 0;
				while (i < length)
				{
					stringBuilder.Append(string_1[i]);
					if (string_1[i] == '.')
					{
						stringBuilder[i - num] = (char)(num & 255);
						num = -1;
					}
					i++;
					num++;
				}
				stringBuilder[stringBuilder.Length - 1] = '\0';
				result = Encoding.ASCII.GetBytes(stringBuilder.ToString());
			}
			return result;
		}

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x060000B2 RID: 178 RVA: 0x000089CC File Offset: 0x00006BCC
		public byte[] Data
		{
			get
			{
				List<byte> list = new List<byte>();
				list.AddRange(this.method_0(this.QName));
				list.AddRange(this.method_1((ushort)this.QType));
				list.AddRange(this.method_1((ushort)this.QClass));
				return list.ToArray();
			}
		}

		// Token: 0x060000B3 RID: 179 RVA: 0x0000887C File Offset: 0x00006A7C
		private byte[] method_1(ushort ushort_0)
		{
			return BitConverter.GetBytes(IPAddress.HostToNetworkOrder((short)ushort_0));
		}

		// Token: 0x060000B4 RID: 180 RVA: 0x00008A20 File Offset: 0x00006C20
		public override string ToString()
		{
			return string.Format("{0,-32}\t{1}\t{2}", this.QName, this.QClass, this.QType);
		}

		// Token: 0x04000034 RID: 52
		private string string_0;

		// Token: 0x04000035 RID: 53
		public QType QType;

		// Token: 0x04000036 RID: 54
		public QClass QClass;
	}
}
