﻿using System;

namespace Heijden.DNS
{
	// Token: 0x0200004D RID: 77
	public class RecordSIG : Record
	{
		// Token: 0x06000132 RID: 306 RVA: 0x0000A194 File Offset: 0x00008394
		public RecordSIG(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.TYPECOVERED = rr.method_0();
			this.ALGORITHM = rr.ReadByte();
			this.LABELS = rr.ReadByte();
			this.ORIGINALTTL = rr.method_2();
			this.SIGNATUREEXPIRATION = rr.method_2();
			this.SIGNATUREINCEPTION = rr.method_2();
			this.KEYTAG = rr.method_0();
			this.SIGNERSNAME = rr.ReadDomainName();
			this.SIGNATURE = rr.ReadString();
		}

		// Token: 0x06000133 RID: 307 RVA: 0x0000A218 File Offset: 0x00008418
		public override string ToString()
		{
			return string.Format("{0} {1} {2} {3} {4} {5} {6} {7} \"{8}\"", new object[]
			{
				this.TYPECOVERED,
				this.ALGORITHM,
				this.LABELS,
				this.ORIGINALTTL,
				this.SIGNATUREEXPIRATION,
				this.SIGNATUREINCEPTION,
				this.KEYTAG,
				this.SIGNERSNAME,
				this.SIGNATURE
			});
		}

		// Token: 0x0400008D RID: 141
		public ushort TYPECOVERED;

		// Token: 0x0400008E RID: 142
		public byte ALGORITHM;

		// Token: 0x0400008F RID: 143
		public byte LABELS;

		// Token: 0x04000090 RID: 144
		public uint ORIGINALTTL;

		// Token: 0x04000091 RID: 145
		public uint SIGNATUREEXPIRATION;

		// Token: 0x04000092 RID: 146
		public uint SIGNATUREINCEPTION;

		// Token: 0x04000093 RID: 147
		public ushort KEYTAG;

		// Token: 0x04000094 RID: 148
		public string SIGNERSNAME;

		// Token: 0x04000095 RID: 149
		public string SIGNATURE;
	}
}
