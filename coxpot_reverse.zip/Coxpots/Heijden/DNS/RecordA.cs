﻿using System;
using System.Net;

namespace Heijden.DNS
{
	// Token: 0x02000035 RID: 53
	public class RecordA : Record
	{
		// Token: 0x060000FB RID: 251 RVA: 0x00009694 File Offset: 0x00007894
		public RecordA(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			IPAddress.TryParse(string.Format("{0}.{1}.{2}.{3}", new object[]
			{
				rr.ReadByte(),
				rr.ReadByte(),
				rr.ReadByte(),
				rr.ReadByte()
			}), out this.Address);
		}

		// Token: 0x060000FC RID: 252 RVA: 0x00009700 File Offset: 0x00007900
		public override string ToString()
		{
			return this.Address.ToString();
		}

		// Token: 0x04000059 RID: 89
		public IPAddress Address;
	}
}
