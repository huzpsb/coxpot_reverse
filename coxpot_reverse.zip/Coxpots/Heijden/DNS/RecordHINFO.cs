﻿using System;

namespace Heijden.DNS
{
	// Token: 0x0200003B RID: 59
	public class RecordHINFO : Record
	{
		// Token: 0x06000107 RID: 263 RVA: 0x00004F7C File Offset: 0x0000317C
		public RecordHINFO(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.CPU = rr.ReadString();
			this.OS = rr.ReadString();
		}

		// Token: 0x06000108 RID: 264 RVA: 0x00009924 File Offset: 0x00007B24
		public override string ToString()
		{
			return string.Format("CPU={0} OS={1}", this.CPU, this.OS);
		}

		// Token: 0x04000063 RID: 99
		public string CPU;

		// Token: 0x04000064 RID: 100
		public string OS;
	}
}
