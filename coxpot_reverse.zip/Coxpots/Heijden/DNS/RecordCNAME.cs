﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000038 RID: 56
	public class RecordCNAME : Record
	{
		// Token: 0x06000101 RID: 257 RVA: 0x00004F4A File Offset: 0x0000314A
		public RecordCNAME(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.CNAME = rr.ReadDomainName();
		}

		// Token: 0x06000102 RID: 258 RVA: 0x00009808 File Offset: 0x00007A08
		public override string ToString()
		{
			return this.CNAME;
		}

		// Token: 0x0400005D RID: 93
		public string CNAME;
	}
}
