﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000039 RID: 57
	public class RecordDNAME : Record
	{
		// Token: 0x06000103 RID: 259 RVA: 0x00004F63 File Offset: 0x00003163
		public RecordDNAME(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.TARGET = rr.ReadDomainName();
		}

		// Token: 0x06000104 RID: 260 RVA: 0x00009820 File Offset: 0x00007A20
		public override string ToString()
		{
			return this.TARGET;
		}

		// Token: 0x0400005E RID: 94
		public string TARGET;
	}
}
