﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000045 RID: 69
	public class RecordNAPTR : Record
	{
		// Token: 0x06000121 RID: 289 RVA: 0x00009E10 File Offset: 0x00008010
		public RecordNAPTR(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.ORDER = rr.method_0();
			this.PREFERENCE = rr.method_0();
			this.FLAGS = rr.ReadString();
			this.SERVICES = rr.ReadString();
			this.REGEXP = rr.ReadString();
			this.REPLACEMENT = rr.ReadDomainName();
		}

		// Token: 0x06000122 RID: 290 RVA: 0x00009E70 File Offset: 0x00008070
		public override string ToString()
		{
			return string.Format("{0} {1} \"{2}\" \"{3}\" \"{4}\" {5}", new object[]
			{
				this.ORDER,
				this.PREFERENCE,
				this.FLAGS,
				this.SERVICES,
				this.REGEXP,
				this.REPLACEMENT
			});
		}

		// Token: 0x0400007B RID: 123
		public ushort ORDER;

		// Token: 0x0400007C RID: 124
		public ushort PREFERENCE;

		// Token: 0x0400007D RID: 125
		public string FLAGS;

		// Token: 0x0400007E RID: 126
		public string SERVICES;

		// Token: 0x0400007F RID: 127
		public string REGEXP;

		// Token: 0x04000080 RID: 128
		public string REPLACEMENT;
	}
}
