﻿using System;

namespace Heijden.DNS
{
	// Token: 0x0200004F RID: 79
	public class RecordSRV : Record
	{
		// Token: 0x06000136 RID: 310 RVA: 0x00005195 File Offset: 0x00003395
		public RecordSRV(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.PRIORITY = rr.method_0();
			this.WEIGHT = rr.method_0();
			this.PORT = rr.method_0();
			this.TARGET = rr.ReadDomainName();
		}

		// Token: 0x06000137 RID: 311 RVA: 0x0000A390 File Offset: 0x00008590
		public override string ToString()
		{
			return string.Format("{0} {1} {2} {3}", new object[]
			{
				this.PRIORITY,
				this.WEIGHT,
				this.PORT,
				this.TARGET
			});
		}

		// Token: 0x0400009D RID: 157
		public ushort PRIORITY;

		// Token: 0x0400009E RID: 158
		public ushort WEIGHT;

		// Token: 0x0400009F RID: 159
		public ushort PORT;

		// Token: 0x040000A0 RID: 160
		public string TARGET;
	}
}
