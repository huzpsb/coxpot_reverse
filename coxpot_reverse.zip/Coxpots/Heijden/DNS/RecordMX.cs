﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000044 RID: 68
	public class RecordMX : Record, IComparable
	{
		// Token: 0x0600011E RID: 286 RVA: 0x00005098 File Offset: 0x00003298
		public RecordMX(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.PREFERENCE = rr.method_0();
			this.EXCHANGE = rr.ReadDomainName();
		}

		// Token: 0x0600011F RID: 287 RVA: 0x00009D88 File Offset: 0x00007F88
		public override string ToString()
		{
			return string.Format("{0} {1}", this.PREFERENCE, this.EXCHANGE);
		}

		// Token: 0x06000120 RID: 288 RVA: 0x00009DB4 File Offset: 0x00007FB4
		public int CompareTo(object objA)
		{
			RecordMX recordMX = objA as RecordMX;
			int result;
			if (recordMX == null)
			{
				result = -1;
			}
			else if (this.PREFERENCE > recordMX.PREFERENCE)
			{
				result = 1;
			}
			else if (this.PREFERENCE < recordMX.PREFERENCE)
			{
				result = -1;
			}
			else
			{
				result = string.Compare(this.EXCHANGE, recordMX.EXCHANGE, true);
			}
			return result;
		}

		// Token: 0x04000079 RID: 121
		public ushort PREFERENCE;

		// Token: 0x0400007A RID: 122
		public string EXCHANGE;
	}
}
