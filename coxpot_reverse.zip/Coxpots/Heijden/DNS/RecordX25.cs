﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000054 RID: 84
	public class RecordX25 : Record
	{
		// Token: 0x06000140 RID: 320 RVA: 0x000051EB File Offset: 0x000033EB
		public RecordX25(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.PSDNADDRESS = rr.ReadString();
		}

		// Token: 0x06000141 RID: 321 RVA: 0x0000A6E4 File Offset: 0x000088E4
		public override string ToString()
		{
			return string.Format("{0}", this.PSDNADDRESS);
		}

		// Token: 0x040000B7 RID: 183
		public string PSDNADDRESS;
	}
}
