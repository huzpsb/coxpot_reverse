﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000051 RID: 81
	public class RecordTSIG : Record
	{
		// Token: 0x0600013A RID: 314 RVA: 0x0000A4D4 File Offset: 0x000086D4
		public RecordTSIG(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.ALGORITHMNAME = rr.ReadDomainName();
			this.TIMESIGNED = (long)((ulong)(rr.method_2() | rr.method_2()));
			this.FUDGE = rr.method_0();
			this.MACSIZE = rr.method_0();
			this.MAC = rr.ReadBytes((int)this.MACSIZE);
			this.ORIGINALID = rr.method_0();
			this.ERROR = rr.method_0();
			this.OTHERLEN = rr.method_0();
			this.OTHERDATA = rr.ReadBytes((int)this.OTHERLEN);
		}

		// Token: 0x0600013B RID: 315 RVA: 0x0000A56C File Offset: 0x0000876C
		public override string ToString()
		{
			DateTime dateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0);
			dateTime = dateTime.AddSeconds((double)this.TIMESIGNED);
			string text = dateTime.ToShortDateString() + " " + dateTime.ToShortTimeString();
			return string.Format("{0} {1} {2} {3} {4}", new object[]
			{
				this.ALGORITHMNAME,
				text,
				this.FUDGE,
				this.ORIGINALID,
				this.ERROR
			});
		}

		// Token: 0x040000AA RID: 170
		public string ALGORITHMNAME;

		// Token: 0x040000AB RID: 171
		public long TIMESIGNED;

		// Token: 0x040000AC RID: 172
		public ushort FUDGE;

		// Token: 0x040000AD RID: 173
		public ushort MACSIZE;

		// Token: 0x040000AE RID: 174
		public byte[] MAC;

		// Token: 0x040000AF RID: 175
		public ushort ORIGINALID;

		// Token: 0x040000B0 RID: 176
		public ushort ERROR;

		// Token: 0x040000B1 RID: 177
		public ushort OTHERLEN;

		// Token: 0x040000B2 RID: 178
		public byte[] OTHERDATA;
	}
}
