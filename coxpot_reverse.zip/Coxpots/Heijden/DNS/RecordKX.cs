﻿using System;

namespace Heijden.DNS
{
	// Token: 0x0200003E RID: 62
	public class RecordKX : Record, IComparable
	{
		// Token: 0x0600010D RID: 269 RVA: 0x00005003 File Offset: 0x00003203
		public RecordKX(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.PREFERENCE = rr.method_0();
			this.EXCHANGER = rr.ReadDomainName();
		}

		// Token: 0x0600010E RID: 270 RVA: 0x000099C8 File Offset: 0x00007BC8
		public override string ToString()
		{
			return string.Format("{0} {1}", this.PREFERENCE, this.EXCHANGER);
		}

		// Token: 0x0600010F RID: 271 RVA: 0x000099F4 File Offset: 0x00007BF4
		public int CompareTo(object objA)
		{
			RecordKX recordKX = objA as RecordKX;
			int result;
			if (recordKX == null)
			{
				result = -1;
			}
			else if (this.PREFERENCE > recordKX.PREFERENCE)
			{
				result = 1;
			}
			else if (this.PREFERENCE < recordKX.PREFERENCE)
			{
				result = -1;
			}
			else
			{
				result = string.Compare(this.EXCHANGER, recordKX.EXCHANGER, true);
			}
			return result;
		}

		// Token: 0x0400006B RID: 107
		public ushort PREFERENCE;

		// Token: 0x0400006C RID: 108
		public string EXCHANGER;
	}
}
