﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000030 RID: 48
	public class RecordMD : Record
	{
		// Token: 0x060000F1 RID: 241 RVA: 0x00004EDA File Offset: 0x000030DA
		public RecordMD(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.MADNAME = rr.ReadDomainName();
		}

		// Token: 0x060000F2 RID: 242 RVA: 0x0000954C File Offset: 0x0000774C
		public override string ToString()
		{
			return this.MADNAME;
		}

		// Token: 0x04000053 RID: 83
		public string MADNAME;
	}
}
