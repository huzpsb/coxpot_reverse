﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000049 RID: 73
	public class RecordPTR : Record
	{
		// Token: 0x0600012A RID: 298 RVA: 0x00005101 File Offset: 0x00003301
		public RecordPTR(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.PTRDNAME = rr.ReadDomainName();
		}

		// Token: 0x0600012B RID: 299 RVA: 0x0000A0F8 File Offset: 0x000082F8
		public override string ToString()
		{
			return this.PTRDNAME;
		}

		// Token: 0x04000085 RID: 133
		public string PTRDNAME;
	}
}
