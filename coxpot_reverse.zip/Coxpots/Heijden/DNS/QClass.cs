﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000068 RID: 104
	public enum QClass : ushort
	{
		// Token: 0x0400015F RID: 351
		IN = 1,
		// Token: 0x04000160 RID: 352
		CS,
		// Token: 0x04000161 RID: 353
		CH,
		// Token: 0x04000162 RID: 354
		HS,
		// Token: 0x04000163 RID: 355
		ANY = 255
	}
}
