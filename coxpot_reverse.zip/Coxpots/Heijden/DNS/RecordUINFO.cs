﻿using System;

namespace Heijden.DNS
{
	// Token: 0x0200002C RID: 44
	public class RecordUINFO : Record
	{
		// Token: 0x060000EA RID: 234 RVA: 0x00009490 File Offset: 0x00007690
		public RecordUINFO(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			ushort intLength = rr.method_1(-2);
			this.RDATA = rr.ReadBytes((int)intLength);
		}

		// Token: 0x060000EB RID: 235 RVA: 0x000090E0 File Offset: 0x000072E0
		public override string ToString()
		{
			return string.Format("not-used", new object[0]);
		}

		// Token: 0x0400004D RID: 77
		public byte[] RDATA;
	}
}
