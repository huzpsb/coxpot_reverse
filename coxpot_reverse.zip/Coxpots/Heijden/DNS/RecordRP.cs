﻿using System;

namespace Heijden.DNS
{
	// Token: 0x0200004B RID: 75
	public class RecordRP : Record
	{
		// Token: 0x0600012E RID: 302 RVA: 0x0000514B File Offset: 0x0000334B
		public RecordRP(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.MBOXDNAME = rr.ReadDomainName();
			this.TXTDNAME = rr.ReadDomainName();
		}

		// Token: 0x0600012F RID: 303 RVA: 0x0000A140 File Offset: 0x00008340
		public override string ToString()
		{
			return string.Format("{0} {1}", this.MBOXDNAME, this.TXTDNAME);
		}

		// Token: 0x04000089 RID: 137
		public string MBOXDNAME;

		// Token: 0x0400008A RID: 138
		public string TXTDNAME;
	}
}
