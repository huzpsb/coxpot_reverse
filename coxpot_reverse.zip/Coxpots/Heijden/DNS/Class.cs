﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000067 RID: 103
	public enum Class : ushort
	{
		// Token: 0x0400015A RID: 346
		IN = 1,
		// Token: 0x0400015B RID: 347
		CS,
		// Token: 0x0400015C RID: 348
		CH,
		// Token: 0x0400015D RID: 349
		HS
	}
}
