﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000025 RID: 37
	public class RecordNSEC3PARAM : Record
	{
		// Token: 0x060000DC RID: 220 RVA: 0x00009340 File Offset: 0x00007540
		public RecordNSEC3PARAM(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			ushort intLength = rr.method_1(-2);
			this.RDATA = rr.ReadBytes((int)intLength);
		}

		// Token: 0x060000DD RID: 221 RVA: 0x000090E0 File Offset: 0x000072E0
		public override string ToString()
		{
			return string.Format("not-used", new object[0]);
		}

		// Token: 0x04000046 RID: 70
		public byte[] RDATA;
	}
}
