﻿using System;

namespace Heijden.DNS
{
	// Token: 0x0200003C RID: 60
	public class RecordISDN : Record
	{
		// Token: 0x06000109 RID: 265 RVA: 0x00004FA1 File Offset: 0x000031A1
		public RecordISDN(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.ISDNADDRESS = rr.ReadString();
			this.SA = rr.ReadString();
		}

		// Token: 0x0600010A RID: 266 RVA: 0x0000994C File Offset: 0x00007B4C
		public override string ToString()
		{
			return string.Format("{0} {1}", this.ISDNADDRESS, this.SA);
		}

		// Token: 0x04000065 RID: 101
		public string ISDNADDRESS;

		// Token: 0x04000066 RID: 102
		public string SA;
	}
}
