﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000061 RID: 97
	public class RR
	{
		// Token: 0x1700003B RID: 59
		// (get) Token: 0x060001A1 RID: 417 RVA: 0x0000BEE8 File Offset: 0x0000A0E8
		// (set) Token: 0x060001A2 RID: 418 RVA: 0x000053BC File Offset: 0x000035BC
		public uint TTL
		{
			get
			{
				return (uint)Math.Max(0L, (long)((ulong)this.uint_0 - (ulong)((long)this.TimeLived)));
			}
			set
			{
				this.uint_0 = value;
			}
		}

		// Token: 0x060001A3 RID: 419 RVA: 0x0000BF18 File Offset: 0x0000A118
		public RR(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.TimeLived = 0;
			this.NAME = rr.ReadDomainName();
			this.Type = (Type)rr.method_0();
			this.Class = (Class)rr.method_0();
			this.TTL = rr.method_2();
			this.RDLENGTH = rr.method_0();
			this.RECORD = rr.ReadRecord(this.Type);
			this.RECORD.RR = this;
		}

		// Token: 0x060001A4 RID: 420 RVA: 0x0000BF94 File Offset: 0x0000A194
		public override string ToString()
		{
			return string.Format("{0,-32} {1}\t{2}\t{3}\t{4}", new object[]
			{
				this.NAME,
				this.TTL,
				this.Class,
				this.Type,
				this.RECORD
			});
		}

		// Token: 0x040000D1 RID: 209
		public string NAME;

		// Token: 0x040000D2 RID: 210
		public Type Type;

		// Token: 0x040000D3 RID: 211
		public Class Class;

		// Token: 0x040000D4 RID: 212
		private uint uint_0;

		// Token: 0x040000D5 RID: 213
		public ushort RDLENGTH;

		// Token: 0x040000D6 RID: 214
		public Record RECORD;

		// Token: 0x040000D7 RID: 215
		public int TimeLived;
	}
}
