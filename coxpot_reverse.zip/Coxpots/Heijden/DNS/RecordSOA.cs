﻿using System;

namespace Heijden.DNS
{
	// Token: 0x0200004E RID: 78
	public class RecordSOA : Record
	{
		// Token: 0x06000134 RID: 308 RVA: 0x0000A2AC File Offset: 0x000084AC
		public RecordSOA(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.MNAME = rr.ReadDomainName();
			this.RNAME = rr.ReadDomainName();
			this.SERIAL = rr.method_2();
			this.REFRESH = rr.method_2();
			this.RETRY = rr.method_2();
			this.EXPIRE = rr.method_2();
			this.MINIMUM = rr.method_2();
		}

		// Token: 0x06000135 RID: 309 RVA: 0x0000A318 File Offset: 0x00008518
		public override string ToString()
		{
			return string.Format("{0} {1} {2} {3} {4} {5} {6}", new object[]
			{
				this.MNAME,
				this.RNAME,
				this.SERIAL,
				this.REFRESH,
				this.RETRY,
				this.EXPIRE,
				this.MINIMUM
			});
		}

		// Token: 0x04000096 RID: 150
		public string MNAME;

		// Token: 0x04000097 RID: 151
		public string RNAME;

		// Token: 0x04000098 RID: 152
		public uint SERIAL;

		// Token: 0x04000099 RID: 153
		public uint REFRESH;

		// Token: 0x0400009A RID: 154
		public uint RETRY;

		// Token: 0x0400009B RID: 155
		public uint EXPIRE;

		// Token: 0x0400009C RID: 156
		public uint MINIMUM;
	}
}
