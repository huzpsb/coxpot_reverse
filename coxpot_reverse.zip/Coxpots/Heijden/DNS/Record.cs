﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000034 RID: 52
	public abstract class Record
	{
		// Token: 0x060000FA RID: 250 RVA: 0x0000480C File Offset: 0x00002A0C
		protected Record()
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
		}

		// Token: 0x04000058 RID: 88
		public RR RR;
	}
}
