﻿using System;

namespace Heijden.DNS
{
	// Token: 0x0200004C RID: 76
	public class RecordRT : Record
	{
		// Token: 0x06000130 RID: 304 RVA: 0x00005170 File Offset: 0x00003370
		public RecordRT(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.PREFERENCE = rr.method_0();
			this.INTERMEDIATEHOST = rr.ReadDomainName();
		}

		// Token: 0x06000131 RID: 305 RVA: 0x0000A168 File Offset: 0x00008368
		public override string ToString()
		{
			return string.Format("{0} {1}", this.PREFERENCE, this.INTERMEDIATEHOST);
		}

		// Token: 0x0400008B RID: 139
		public ushort PREFERENCE;

		// Token: 0x0400008C RID: 140
		public string INTERMEDIATEHOST;
	}
}
