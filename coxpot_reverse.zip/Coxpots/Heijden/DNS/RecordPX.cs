﻿using System;

namespace Heijden.DNS
{
	// Token: 0x0200004A RID: 74
	public class RecordPX : Record
	{
		// Token: 0x0600012C RID: 300 RVA: 0x0000511A File Offset: 0x0000331A
		public RecordPX(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.PREFERENCE = rr.method_0();
			this.MAP822 = rr.ReadDomainName();
			this.MAPX400 = rr.ReadDomainName();
		}

		// Token: 0x0600012D RID: 301 RVA: 0x0000A110 File Offset: 0x00008310
		public override string ToString()
		{
			return string.Format("{0} {1} {2}", this.PREFERENCE, this.MAP822, this.MAPX400);
		}

		// Token: 0x04000086 RID: 134
		public ushort PREFERENCE;

		// Token: 0x04000087 RID: 135
		public string MAP822;

		// Token: 0x04000088 RID: 136
		public string MAPX400;
	}
}
