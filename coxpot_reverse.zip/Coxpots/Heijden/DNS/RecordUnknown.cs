﻿using System;

namespace Heijden.DNS
{
	// Token: 0x0200002D RID: 45
	public class RecordUnknown : Record
	{
		// Token: 0x060000EC RID: 236 RVA: 0x000094C0 File Offset: 0x000076C0
		public RecordUnknown(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			ushort intLength = rr.method_1(-2);
			this.RDATA = rr.ReadBytes((int)intLength);
		}

		// Token: 0x0400004E RID: 78
		public byte[] RDATA;
	}
}
