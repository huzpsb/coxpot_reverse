﻿using System;

namespace Heijden.DNS
{
	// Token: 0x0200001D RID: 29
	public class RecordDNSKEY : Record
	{
		// Token: 0x060000CC RID: 204 RVA: 0x000091C0 File Offset: 0x000073C0
		public RecordDNSKEY(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			ushort intLength = rr.method_1(-2);
			this.RDATA = rr.ReadBytes((int)intLength);
		}

		// Token: 0x060000CD RID: 205 RVA: 0x000090E0 File Offset: 0x000072E0
		public override string ToString()
		{
			return string.Format("not-used", new object[0]);
		}

		// Token: 0x0400003E RID: 62
		public byte[] RDATA;
	}
}
