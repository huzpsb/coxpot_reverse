﻿using System;

namespace Heijden.DNS
{
	// Token: 0x0200006B RID: 107
	public enum TransportType
	{
		// Token: 0x0400018E RID: 398
		Udp,
		// Token: 0x0400018F RID: 399
		Tcp
	}
}
