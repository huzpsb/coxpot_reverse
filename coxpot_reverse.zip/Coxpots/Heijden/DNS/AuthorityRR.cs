﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000063 RID: 99
	public class AuthorityRR : RR
	{
		// Token: 0x060001A6 RID: 422 RVA: 0x000053C5 File Offset: 0x000035C5
		public AuthorityRR(RecordReader br)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor(br);
		}
	}
}
