﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000031 RID: 49
	public class RecordMF : Record
	{
		// Token: 0x060000F3 RID: 243 RVA: 0x00004EF3 File Offset: 0x000030F3
		public RecordMF(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.MADNAME = rr.ReadDomainName();
		}

		// Token: 0x060000F4 RID: 244 RVA: 0x00009564 File Offset: 0x00007764
		public override string ToString()
		{
			return this.MADNAME;
		}

		// Token: 0x04000054 RID: 84
		public string MADNAME;
	}
}
