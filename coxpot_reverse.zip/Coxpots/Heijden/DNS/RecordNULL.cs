﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000048 RID: 72
	public class RecordNULL : Record
	{
		// Token: 0x06000128 RID: 296 RVA: 0x0000A088 File Offset: 0x00008288
		public RecordNULL(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			rr.Position -= 2;
			ushort num = rr.method_0();
			this.ANYTHING = new byte[(int)num];
			this.ANYTHING = rr.ReadBytes((int)num);
		}

		// Token: 0x06000129 RID: 297 RVA: 0x0000A0D0 File Offset: 0x000082D0
		public override string ToString()
		{
			return string.Format("...binary data... ({0}) bytes", this.ANYTHING.Length);
		}

		// Token: 0x04000084 RID: 132
		public byte[] ANYTHING;
	}
}
