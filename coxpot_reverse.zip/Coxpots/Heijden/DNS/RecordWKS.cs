﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000053 RID: 83
	public class RecordWKS : Record
	{
		// Token: 0x0600013E RID: 318 RVA: 0x0000A61C File Offset: 0x0000881C
		public RecordWKS(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			ushort num = rr.method_1(-2);
			this.ADDRESS = string.Format("{0}.{1}.{2}.{3}", new object[]
			{
				rr.ReadByte(),
				rr.ReadByte(),
				rr.ReadByte(),
				rr.ReadByte()
			});
			this.PROTOCOL = (int)rr.ReadByte();
			num -= 5;
			this.BITMAP = new byte[(int)num];
			this.BITMAP = rr.ReadBytes((int)num);
		}

		// Token: 0x0600013F RID: 319 RVA: 0x0000A6B8 File Offset: 0x000088B8
		public override string ToString()
		{
			return string.Format("{0} {1}", this.ADDRESS, this.PROTOCOL);
		}

		// Token: 0x040000B4 RID: 180
		public string ADDRESS;

		// Token: 0x040000B5 RID: 181
		public int PROTOCOL;

		// Token: 0x040000B6 RID: 182
		public byte[] BITMAP;
	}
}
