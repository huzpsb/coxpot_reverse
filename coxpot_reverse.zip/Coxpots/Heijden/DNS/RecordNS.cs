﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000046 RID: 70
	public class RecordNS : Record
	{
		// Token: 0x06000123 RID: 291 RVA: 0x000050BD File Offset: 0x000032BD
		public RecordNS(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.NSDNAME = rr.ReadDomainName();
		}

		// Token: 0x06000124 RID: 292 RVA: 0x00009ED0 File Offset: 0x000080D0
		public override string ToString()
		{
			return this.NSDNAME;
		}

		// Token: 0x04000081 RID: 129
		public string NSDNAME;
	}
}
