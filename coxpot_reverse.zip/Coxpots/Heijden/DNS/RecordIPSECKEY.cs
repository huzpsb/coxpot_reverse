﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000021 RID: 33
	public class RecordIPSECKEY : Record
	{
		// Token: 0x060000D4 RID: 212 RVA: 0x00009280 File Offset: 0x00007480
		public RecordIPSECKEY(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			ushort intLength = rr.method_1(-2);
			this.RDATA = rr.ReadBytes((int)intLength);
		}

		// Token: 0x060000D5 RID: 213 RVA: 0x000090E0 File Offset: 0x000072E0
		public override string ToString()
		{
			return string.Format("not-used", new object[0]);
		}

		// Token: 0x04000042 RID: 66
		public byte[] RDATA;
	}
}
