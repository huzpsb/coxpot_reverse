﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000043 RID: 67
	public class RecordMR : Record
	{
		// Token: 0x0600011C RID: 284 RVA: 0x0000507F File Offset: 0x0000327F
		public RecordMR(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.NEWNAME = rr.ReadDomainName();
		}

		// Token: 0x0600011D RID: 285 RVA: 0x00009D70 File Offset: 0x00007F70
		public override string ToString()
		{
			return this.NEWNAME;
		}

		// Token: 0x04000078 RID: 120
		public string NEWNAME;
	}
}
