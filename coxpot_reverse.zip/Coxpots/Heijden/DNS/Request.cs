﻿using System;
using System.Collections.Generic;

namespace Heijden.DNS
{
	// Token: 0x02000055 RID: 85
	public class Request
	{
		// Token: 0x06000142 RID: 322 RVA: 0x00005204 File Offset: 0x00003404
		public Request()
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.header = new Header();
			this.header.OPCODE = OPCode.Query;
			this.header.QDCOUNT = 0;
			this.list_0 = new List<Question>();
		}

		// Token: 0x06000143 RID: 323 RVA: 0x0000523F File Offset: 0x0000343F
		public void AddQuestion(Question question)
		{
			this.list_0.Add(question);
		}

		// Token: 0x17000028 RID: 40
		// (get) Token: 0x06000144 RID: 324 RVA: 0x0000A704 File Offset: 0x00008904
		public byte[] Data
		{
			get
			{
				List<byte> list = new List<byte>();
				this.header.QDCOUNT = (ushort)this.list_0.Count;
				list.AddRange(this.header.Data);
				foreach (Question question in this.list_0)
				{
					list.AddRange(question.Data);
				}
				return list.ToArray();
			}
		}

		// Token: 0x040000B8 RID: 184
		public Header header;

		// Token: 0x040000B9 RID: 185
		private List<Question> list_0;
	}
}
