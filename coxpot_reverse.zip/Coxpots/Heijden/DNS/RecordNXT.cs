﻿using System;
using System.Text;

namespace Heijden.DNS
{
	// Token: 0x02000033 RID: 51
	public class RecordNXT : Record
	{
		// Token: 0x060000F7 RID: 247 RVA: 0x0000959C File Offset: 0x0000779C
		public RecordNXT(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			ushort num = rr.method_1(-2);
			this.NEXTDOMAINNAME = rr.ReadDomainName();
			num -= (ushort)rr.Position;
			this.BITMAP = new byte[(int)num];
			this.BITMAP = rr.ReadBytes((int)num);
		}

		// Token: 0x060000F8 RID: 248 RVA: 0x000095F0 File Offset: 0x000077F0
		private bool method_0(int int_0)
		{
			int num = int_0 / 8;
			int num2 = int_0 % 8;
			byte b = this.BITMAP[num];
			int num3 = 1 << num2;
			return ((int)b & num3) != 0;
		}

		// Token: 0x060000F9 RID: 249 RVA: 0x00009628 File Offset: 0x00007828
		public override string ToString()
		{
			StringBuilder stringBuilder = new StringBuilder();
			for (int i = 1; i < this.BITMAP.Length * 8; i++)
			{
				if (this.method_0(i))
				{
					stringBuilder.Append(" " + ((Type)i).ToString());
				}
			}
			return string.Format("{0}{1}", this.NEXTDOMAINNAME, stringBuilder.ToString());
		}

		// Token: 0x04000056 RID: 86
		public string NEXTDOMAINNAME;

		// Token: 0x04000057 RID: 87
		public byte[] BITMAP;
	}
}
