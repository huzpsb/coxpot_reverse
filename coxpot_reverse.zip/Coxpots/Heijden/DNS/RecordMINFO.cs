﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000042 RID: 66
	public class RecordMINFO : Record
	{
		// Token: 0x0600011A RID: 282 RVA: 0x0000505A File Offset: 0x0000325A
		public RecordMINFO(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.RMAILBX = rr.ReadDomainName();
			this.EMAILBX = rr.ReadDomainName();
		}

		// Token: 0x0600011B RID: 283 RVA: 0x00009D48 File Offset: 0x00007F48
		public override string ToString()
		{
			return string.Format("{0} {1}", this.RMAILBX, this.EMAILBX);
		}

		// Token: 0x04000076 RID: 118
		public string RMAILBX;

		// Token: 0x04000077 RID: 119
		public string EMAILBX;
	}
}
