﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000023 RID: 35
	public class RecordNSEC : Record
	{
		// Token: 0x060000D8 RID: 216 RVA: 0x000092E0 File Offset: 0x000074E0
		public RecordNSEC(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			ushort intLength = rr.method_1(-2);
			this.RDATA = rr.ReadBytes((int)intLength);
		}

		// Token: 0x060000D9 RID: 217 RVA: 0x000090E0 File Offset: 0x000072E0
		public override string ToString()
		{
			return string.Format("not-used", new object[0]);
		}

		// Token: 0x04000044 RID: 68
		public byte[] RDATA;
	}
}
