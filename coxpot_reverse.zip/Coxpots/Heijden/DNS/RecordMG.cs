﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000041 RID: 65
	public class RecordMG : Record
	{
		// Token: 0x06000118 RID: 280 RVA: 0x00005041 File Offset: 0x00003241
		public RecordMG(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.MGMNAME = rr.ReadDomainName();
		}

		// Token: 0x06000119 RID: 281 RVA: 0x00009D30 File Offset: 0x00007F30
		public override string ToString()
		{
			return this.MGMNAME;
		}

		// Token: 0x04000075 RID: 117
		public string MGMNAME;
	}
}
