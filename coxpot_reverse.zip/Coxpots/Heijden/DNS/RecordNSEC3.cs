﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000024 RID: 36
	public class RecordNSEC3 : Record
	{
		// Token: 0x060000DA RID: 218 RVA: 0x00009310 File Offset: 0x00007510
		public RecordNSEC3(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			ushort intLength = rr.method_1(-2);
			this.RDATA = rr.ReadBytes((int)intLength);
		}

		// Token: 0x060000DB RID: 219 RVA: 0x000090E0 File Offset: 0x000072E0
		public override string ToString()
		{
			return string.Format("not-used", new object[0]);
		}

		// Token: 0x04000045 RID: 69
		public byte[] RDATA;
	}
}
