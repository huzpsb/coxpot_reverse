﻿using System;

namespace Heijden.DNS
{
	// Token: 0x0200001B RID: 27
	public class RecordCERT : Record
	{
		// Token: 0x060000C8 RID: 200 RVA: 0x00009160 File Offset: 0x00007360
		public RecordCERT(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			ushort intLength = rr.method_1(-2);
			this.RDATA = rr.ReadBytes((int)intLength);
		}

		// Token: 0x060000C9 RID: 201 RVA: 0x000090E0 File Offset: 0x000072E0
		public override string ToString()
		{
			return string.Format("not-used", new object[0]);
		}

		// Token: 0x0400003C RID: 60
		public byte[] RDATA;
	}
}
