﻿using System;

namespace Heijden.DNS
{
	// Token: 0x0200001C RID: 28
	public class RecordDHCID : Record
	{
		// Token: 0x060000CA RID: 202 RVA: 0x00009190 File Offset: 0x00007390
		public RecordDHCID(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			ushort intLength = rr.method_1(-2);
			this.RDATA = rr.ReadBytes((int)intLength);
		}

		// Token: 0x060000CB RID: 203 RVA: 0x000090E0 File Offset: 0x000072E0
		public override string ToString()
		{
			return string.Format("not-used", new object[0]);
		}

		// Token: 0x0400003D RID: 61
		public byte[] RDATA;
	}
}
