﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000037 RID: 55
	public class RecordAFSDB : Record
	{
		// Token: 0x060000FF RID: 255 RVA: 0x00004F25 File Offset: 0x00003125
		public RecordAFSDB(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.SUBTYPE = rr.method_0();
			this.HOSTNAME = rr.ReadDomainName();
		}

		// Token: 0x06000100 RID: 256 RVA: 0x000097DC File Offset: 0x000079DC
		public override string ToString()
		{
			return string.Format("{0} {1}", this.SUBTYPE, this.HOSTNAME);
		}

		// Token: 0x0400005B RID: 91
		public ushort SUBTYPE;

		// Token: 0x0400005C RID: 92
		public string HOSTNAME;
	}
}
