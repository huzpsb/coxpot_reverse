﻿using System;

namespace Heijden.DNS
{
	// Token: 0x0200002B RID: 43
	public class RecordUID : Record
	{
		// Token: 0x060000E8 RID: 232 RVA: 0x00009460 File Offset: 0x00007660
		public RecordUID(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			ushort intLength = rr.method_1(-2);
			this.RDATA = rr.ReadBytes((int)intLength);
		}

		// Token: 0x060000E9 RID: 233 RVA: 0x000090E0 File Offset: 0x000072E0
		public override string ToString()
		{
			return string.Format("not-used", new object[0]);
		}

		// Token: 0x0400004C RID: 76
		public byte[] RDATA;
	}
}
