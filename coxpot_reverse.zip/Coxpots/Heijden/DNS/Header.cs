﻿using System;
using System.Collections.Generic;
using System.Net;

namespace Heijden.DNS
{
	// Token: 0x02000015 RID: 21
	public class Header
	{
		// Token: 0x06000096 RID: 150 RVA: 0x0000480C File Offset: 0x00002A0C
		public Header()
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
		}

		// Token: 0x06000097 RID: 151 RVA: 0x000086F0 File Offset: 0x000068F0
		public Header(RecordReader rr)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.ID = rr.method_0();
			this.ushort_0 = rr.method_0();
			this.QDCOUNT = rr.method_0();
			this.ANCOUNT = rr.method_0();
			this.NSCOUNT = rr.method_0();
			this.ARCOUNT = rr.method_0();
		}

		// Token: 0x06000098 RID: 152 RVA: 0x00008750 File Offset: 0x00006950
		private ushort method_0(ushort ushort_1, int int_0, int int_1, bool bool_0)
		{
			return this.method_1(ushort_1, int_0, int_1, bool_0 ? 1 : 0);
		}

		// Token: 0x06000099 RID: 153 RVA: 0x00008770 File Offset: 0x00006970
		private ushort method_1(ushort ushort_1, int int_0, int int_1, ushort ushort_2)
		{
			ushort result;
			if (int_1 <= 0 || int_0 >= 16)
			{
				result = ushort_1;
			}
			else
			{
				int num = (2 << int_1 - 1) - 1;
				ushort_1 &= (ushort)(~(ushort)(num << int_0));
				ushort_1 |= (ushort)(((int)ushort_2 & num) << int_0);
				result = ushort_1;
			}
			return result;
		}

		// Token: 0x0600009A RID: 154 RVA: 0x000087BC File Offset: 0x000069BC
		private ushort method_2(ushort ushort_1, int int_0, int int_1)
		{
			ushort result;
			if (int_1 <= 0 || int_0 >= 16)
			{
				result = 0;
			}
			else
			{
				int num = (2 << int_1 - 1) - 1;
				result = (ushort)(ushort_1 >> int_0 & num);
			}
			return result;
		}

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x0600009B RID: 155 RVA: 0x000087F4 File Offset: 0x000069F4
		public byte[] Data
		{
			get
			{
				List<byte> list = new List<byte>();
				list.AddRange(this.method_3(this.ID));
				list.AddRange(this.method_3(this.ushort_0));
				list.AddRange(this.method_3(this.QDCOUNT));
				list.AddRange(this.method_3(this.ANCOUNT));
				list.AddRange(this.method_3(this.NSCOUNT));
				list.AddRange(this.method_3(this.ARCOUNT));
				return list.ToArray();
			}
		}

		// Token: 0x0600009C RID: 156 RVA: 0x0000887C File Offset: 0x00006A7C
		private byte[] method_3(ushort ushort_1)
		{
			return BitConverter.GetBytes(IPAddress.HostToNetworkOrder((short)ushort_1));
		}

		// Token: 0x1700001D RID: 29
		// (get) Token: 0x0600009D RID: 157 RVA: 0x00004CC3 File Offset: 0x00002EC3
		// (set) Token: 0x0600009E RID: 158 RVA: 0x00004CD7 File Offset: 0x00002ED7
		public bool QR
		{
			get
			{
				return this.method_2(this.ushort_0, 15, 1) == 1;
			}
			set
			{
				this.ushort_0 = this.method_0(this.ushort_0, 15, 1, value);
			}
		}

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x0600009F RID: 159 RVA: 0x00008898 File Offset: 0x00006A98
		// (set) Token: 0x060000A0 RID: 160 RVA: 0x00004CEF File Offset: 0x00002EEF
		public OPCode OPCODE
		{
			get
			{
				return (OPCode)this.method_2(this.ushort_0, 11, 4);
			}
			set
			{
				this.ushort_0 = this.method_1(this.ushort_0, 11, 4, (ushort)value);
			}
		}

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x060000A1 RID: 161 RVA: 0x00004D08 File Offset: 0x00002F08
		// (set) Token: 0x060000A2 RID: 162 RVA: 0x00004D1C File Offset: 0x00002F1C
		public bool AA
		{
			get
			{
				return this.method_2(this.ushort_0, 10, 1) == 1;
			}
			set
			{
				this.ushort_0 = this.method_0(this.ushort_0, 10, 1, value);
			}
		}

		// Token: 0x17000020 RID: 32
		// (get) Token: 0x060000A3 RID: 163 RVA: 0x00004D34 File Offset: 0x00002F34
		// (set) Token: 0x060000A4 RID: 164 RVA: 0x00004D48 File Offset: 0x00002F48
		public bool TC
		{
			get
			{
				return this.method_2(this.ushort_0, 9, 1) == 1;
			}
			set
			{
				this.ushort_0 = this.method_0(this.ushort_0, 9, 1, value);
			}
		}

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x060000A5 RID: 165 RVA: 0x00004D60 File Offset: 0x00002F60
		// (set) Token: 0x060000A6 RID: 166 RVA: 0x00004D73 File Offset: 0x00002F73
		public bool RD
		{
			get
			{
				return this.method_2(this.ushort_0, 8, 1) == 1;
			}
			set
			{
				this.ushort_0 = this.method_0(this.ushort_0, 8, 1, value);
			}
		}

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x060000A7 RID: 167 RVA: 0x00004D8A File Offset: 0x00002F8A
		// (set) Token: 0x060000A8 RID: 168 RVA: 0x00004D9D File Offset: 0x00002F9D
		public bool RA
		{
			get
			{
				return this.method_2(this.ushort_0, 7, 1) == 1;
			}
			set
			{
				this.ushort_0 = this.method_0(this.ushort_0, 7, 1, value);
			}
		}

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x060000A9 RID: 169 RVA: 0x000088B8 File Offset: 0x00006AB8
		// (set) Token: 0x060000AA RID: 170 RVA: 0x00004DB4 File Offset: 0x00002FB4
		public ushort Z
		{
			get
			{
				return this.method_2(this.ushort_0, 4, 3);
			}
			set
			{
				this.ushort_0 = this.method_1(this.ushort_0, 4, 3, value);
			}
		}

		// Token: 0x17000024 RID: 36
		// (get) Token: 0x060000AB RID: 171 RVA: 0x000088D8 File Offset: 0x00006AD8
		// (set) Token: 0x060000AC RID: 172 RVA: 0x00004DCB File Offset: 0x00002FCB
		public RCode RCODE
		{
			get
			{
				return (RCode)this.method_2(this.ushort_0, 0, 4);
			}
			set
			{
				this.ushort_0 = this.method_1(this.ushort_0, 0, 4, (ushort)value);
			}
		}

		// Token: 0x0400002E RID: 46
		public ushort ID;

		// Token: 0x0400002F RID: 47
		private ushort ushort_0;

		// Token: 0x04000030 RID: 48
		public ushort QDCOUNT;

		// Token: 0x04000031 RID: 49
		public ushort ANCOUNT;

		// Token: 0x04000032 RID: 50
		public ushort NSCOUNT;

		// Token: 0x04000033 RID: 51
		public ushort ARCOUNT;
	}
}
