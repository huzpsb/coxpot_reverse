﻿using System;

namespace Heijden.DNS
{
	// Token: 0x02000069 RID: 105
	public enum RCode
	{
		// Token: 0x04000165 RID: 357
		NoError,
		// Token: 0x04000166 RID: 358
		FormErr,
		// Token: 0x04000167 RID: 359
		ServFail,
		// Token: 0x04000168 RID: 360
		NXDomain,
		// Token: 0x04000169 RID: 361
		NotImp,
		// Token: 0x0400016A RID: 362
		Refused,
		// Token: 0x0400016B RID: 363
		YXDomain,
		// Token: 0x0400016C RID: 364
		YXRRSet,
		// Token: 0x0400016D RID: 365
		NXRRSet,
		// Token: 0x0400016E RID: 366
		NotAuth,
		// Token: 0x0400016F RID: 367
		NotZone,
		// Token: 0x04000170 RID: 368
		const_11,
		// Token: 0x04000171 RID: 369
		const_12,
		// Token: 0x04000172 RID: 370
		const_13,
		// Token: 0x04000173 RID: 371
		const_14,
		// Token: 0x04000174 RID: 372
		const_15,
		// Token: 0x04000175 RID: 373
		BADVERSSIG,
		// Token: 0x04000176 RID: 374
		BADKEY,
		// Token: 0x04000177 RID: 375
		BADTIME,
		// Token: 0x04000178 RID: 376
		BADMODE,
		// Token: 0x04000179 RID: 377
		BADNAME,
		// Token: 0x0400017A RID: 378
		BADALG,
		// Token: 0x0400017B RID: 379
		BADTRUNC
	}
}
