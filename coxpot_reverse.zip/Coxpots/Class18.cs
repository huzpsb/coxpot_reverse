﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using Coxpots;
using Coxpots.Protocol.Server;

// Token: 0x02000090 RID: 144
internal class Class18
{
	// Token: 0x060002B1 RID: 689 RVA: 0x00005BB5 File Offset: 0x00003DB5
	public static void smethod_0()
	{
		Console.WriteLine("欢迎使用黑河代理程序");
		Class16.smethod_1();
		Class18.smethod_1();
	}

	// Token: 0x060002B2 RID: 690 RVA: 0x0001534C File Offset: 0x0001354C
	public static void smethod_1()
	{
		try
		{
			Class18.smethod_3(null);
			Console.WriteLine("1:(代理)并发模式.");
			Console.WriteLine("2:(代理)循环模式.[效率低]");
			int num = int.Parse(Console.ReadLine());
			List<string> list = new List<string>();
			ArrayList arrayList_ = new ArrayList();
			ServerInfo serverInfo = new ServerInfo(Class18.string_0, Class18.int_0);
			if (serverInfo.method_0())
			{
				int protocolVersion = serverInfo.ProtocolVersion;
				Class18.smethod_2(serverInfo, ref protocolVersion);
				Class19.smethod_2(serverInfo.ServerIP, serverInfo.ServerPort, serverInfo.GameVersion, Setting.threads);
				int num2 = num;
				int num3 = num2;
				if (num3 != 1)
				{
					if (num3 != 2)
					{
						Console.WriteLine("请重新选择");
						Class18.smethod_1();
					}
					else
					{
						list.AddRange(File.ReadAllText(Setting.chatlist, Encoding.UTF8).Split(new char[]
						{
							'\n'
						}));
						Class30 @class;
						if (Setting.protocol == 0)
						{
							@class = new Class30(serverInfo, Setting.name, Setting.threads, arrayList_, protocolVersion);
						}
						else
						{
							@class = new Class30(serverInfo, Setting.name, Setting.threads, arrayList_, Setting.protocol);
						}
						@class.method_0(Setting.cooldown);
					}
				}
				else
				{
					list.AddRange(File.ReadAllText(Setting.chatlist, Encoding.UTF8).Split(new char[]
					{
						'\n'
					}));
					Class28 class2;
					if (Setting.protocol == 0)
					{
						class2 = new Class28(serverInfo, Setting.name, Setting.threads, list, protocolVersion);
					}
					else
					{
						class2 = new Class28(serverInfo, Setting.name, Setting.threads, list, Setting.protocol);
					}
					class2.method_0(Setting.cooldown);
				}
			}
			else
			{
				Console.WriteLine("请重试..");
				Class20.smethod_3();
			}
		}
		catch (Exception ex)
		{
			Console.WriteLine(ex.Message);
		}
	}

	// Token: 0x060002B3 RID: 691 RVA: 0x00015510 File Offset: 0x00013710
	internal static void smethod_2(ServerInfo serverInfo_0, ref int int_1)
	{
		Class16.smethod_0("IP:端口:" + serverInfo_0.ServerIP + ":" + serverInfo_0.ServerPort.ToString(), "Conins");
		Class16.smethod_0("信息:" + serverInfo_0.MOTD, null);
		Class16.smethod_0("版本:" + serverInfo_0.GameVersion + " Protocol:" + serverInfo_0.ProtocolVersion.ToString(), "Conins");
		Class16.smethod_0("在线:" + serverInfo_0.CurrentPlayerCount.ToString() + "/" + serverInfo_0.MaxPlayerCount.ToString(), "Conins");
		Class16.smethod_0("当前延迟:" + serverInfo_0.Ping.ToString(), "Conins");
		string gameVersion = ProtocolHandler.getGameVersion(int_1);
		if (gameVersion == "")
		{
			Class16.smethod_0("unkoo", "Conins");
			Class16.smethod_0("请输入1.7-1.13.1", null);
			int_1 = ProtocolHandler.MCVer2ProtocolVersion(Console.ReadLine());
		}
		else
		{
			Class16.smethod_0("版本:" + gameVersion, "Thos");
		}
		Console.WriteLine("正在启动线程.");
	}

	// Token: 0x060002B4 RID: 692 RVA: 0x00015640 File Offset: 0x00013840
	public static bool smethod_3(string string_1 = null)
	{
		string text = string.Empty;
		if (string_1 == null)
		{
			Console.Write("Ip: ");
			text = Console.ReadLine();
		}
		else
		{
			text = string_1;
		}
		text = text.ToLower();
		string[] array = text.Split(new char[]
		{
			':'
		});
		string text2 = array[0];
		ushort num = 25565;
		if (array.Length > 1)
		{
			try
			{
				Class18.string_0 = Class18.smethod_4(text2);
				Class18.int_0 = (int)Convert.ToUInt16(array[1]);
				return true;
			}
			catch (FormatException ex)
			{
				Console.WriteLine(ex.Message);
			}
		}
		bool result;
		if ((text2 == "localhost" || text2.Contains('.')) && (array.Length == 1 && text2.Contains('.')))
		{
			if (ProtocolHandler.MinecraftServiceLookup(ref text2, ref num))
			{
				Class18.string_0 = Class18.smethod_4(text2);
				Class18.int_0 = (int)num;
			}
			else
			{
				Class18.string_0 = Class18.smethod_4(text2);
				Console.Write("端口: ");
				Class18.int_0 = int.Parse(Console.ReadLine());
			}
			result = true;
		}
		else
		{
			result = false;
		}
		return result;
	}

	// Token: 0x060002B5 RID: 693 RVA: 0x00006B48 File Offset: 0x00004D48
	private static string smethod_4(string string_1)
	{
		IPHostEntry hostEntry = Dns.GetHostEntry(string_1);
		IPEndPoint ipendPoint = new IPEndPoint(hostEntry.AddressList[0], 0);
		return ipendPoint.Address.ToString();
	}

	// Token: 0x060002B6 RID: 694 RVA: 0x0000480C File Offset: 0x00002A0C
	public Class18()
	{
		Class35.NkAVmDjz8ZWXG();
		base..ctor();
	}

	// Token: 0x040002A3 RID: 675
	public static string string_0;

	// Token: 0x040002A4 RID: 676
	public static int int_0;
}
