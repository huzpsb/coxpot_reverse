﻿using System;
using System.IO;
using System.Text;

// Token: 0x0200007F RID: 127
internal class Class10
{
	// Token: 0x06000222 RID: 546 RVA: 0x00012B80 File Offset: 0x00010D80
	public static int smethod_0(int int_0, int int_1)
	{
		return (int)((uint)int_0 >> int_1);
	}

	// Token: 0x06000223 RID: 547 RVA: 0x00012B98 File Offset: 0x00010D98
	public static int smethod_1(TextReader textReader_0, byte[] byte_0, int int_0, int int_1)
	{
		int result;
		if (byte_0.Length == 0)
		{
			result = 0;
		}
		else
		{
			char[] array = new char[byte_0.Length];
			int num = textReader_0.Read(array, int_0, int_1);
			if (num == 0)
			{
				result = -1;
			}
			else
			{
				for (int i = int_0; i < int_0 + num; i++)
				{
					byte_0[i] = (byte)array[i];
				}
				result = num;
			}
		}
		return result;
	}

	// Token: 0x06000224 RID: 548 RVA: 0x00012BE8 File Offset: 0x00010DE8
	internal static byte[] smethod_2(string string_0)
	{
		return Encoding.UTF8.GetBytes(string_0);
	}

	// Token: 0x06000225 RID: 549 RVA: 0x00012C04 File Offset: 0x00010E04
	internal static char[] smethod_3(byte[] byte_0)
	{
		return Encoding.UTF8.GetChars(byte_0);
	}

	// Token: 0x06000226 RID: 550 RVA: 0x0000480C File Offset: 0x00002A0C
	public Class10()
	{
		Class35.NkAVmDjz8ZWXG();
		base..ctor();
	}
}
