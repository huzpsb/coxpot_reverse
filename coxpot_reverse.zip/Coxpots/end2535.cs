﻿using System;
using System.Net;
using System.Windows.Forms;

// Token: 0x02000004 RID: 4
public class end2535
{
	// Token: 0x06000005 RID: 5 RVA: 0x000061B8 File Offset: 0x000043B8
	public static void End253()
	{
		Console.WriteLine("压测选择下载程序");
		Console.WriteLine("");
		Console.WriteLine("提示:[下载链接并非个人,如果失效请联系QQ1612275520修复]");
		Console.WriteLine("");
		Console.WriteLine("###################################");
		Console.WriteLine("[1]:EndMinecraftPlus [1.1] [下载约半分钟]");
		Console.WriteLine("###################################");
		Console.WriteLine("[2]:475代理集群 [1.2] [下载约2秒]");
		Console.WriteLine("###################################");
		Console.WriteLine("[3]:压测4.6.3 [1.3]  [下载约2秒]");
		Console.WriteLine("###################################");
		Console.WriteLine("[4]:服务器信息获取 [1.4] [下载约4秒]");
		Console.WriteLine("###################################");
		Console.WriteLine("[5]:Cmd模式集群 [1.5] [下载约4秒]");
		Console.WriteLine("###################################");
		Console.WriteLine("[6]:易语音测压模块 [1.6] [下载约3秒]");
		Console.WriteLine("###################################");
		Console.WriteLine("[7]:（原创）辅助盒子[内含多种软件 内置上百可用QQ] [下载约11秒]");
		Console.WriteLine("###################################");
		Console.WriteLine("[8]:压测3.1 & 3.2 & 3.4 [下载约2秒]");
		Console.WriteLine("###################################");
		Console.WriteLine("请输入要下载的编号:");
		switch (int.Parse(Console.ReadLine()))
		{
		case 1:
			Console.WriteLine("请等待弹窗出现即可下载完成");
			end2535.smethod_0();
			break;
		case 2:
			Console.WriteLine("请等待弹窗出现即可下载完成");
			end2535.smethod_6();
			break;
		case 3:
			Console.WriteLine("请等待弹窗出现即可下载完成");
			end2535.smethod_5();
			break;
		case 4:
			Console.WriteLine("请等待弹窗出现即可下载完成");
			end2535.smethod_4();
			break;
		case 5:
			Console.WriteLine("请等待弹窗出现即可下载完成");
			end2535.smethod_3();
			break;
		case 6:
			Console.WriteLine("请等待弹窗出现即可下载完成");
			end2535.smethod_2();
			break;
		case 7:
			Console.WriteLine("请等待弹窗出现即可下载完成");
			end2535.smethod_1();
			break;
		case 8:
			Console.WriteLine("请等待弹窗出现即可下载完成");
			end2535.BaotpdOsN();
			break;
		default:
			Console.WriteLine("请重试");
			break;
		}
		Console.ReadLine();
	}

	// Token: 0x06000006 RID: 6 RVA: 0x00006374 File Offset: 0x00004574
	private static void smethod_0()
	{
		using (WebClient webClient = new WebClient())
		{
			webClient.DownloadFile("http://lksf.13x.top/a/1578236209.zip", "C:\\Users\\Administrator\\Desktop\\End集群.zip");
			MessageBox.Show("文件保存目录为:桌面\\End集群.zip", "客户端提示");
		}
	}

	// Token: 0x06000007 RID: 7 RVA: 0x000063C4 File Offset: 0x000045C4
	private static void BaotpdOsN()
	{
		using (WebClient webClient = new WebClient())
		{
			webClient.DownloadFile("http://lksf.13x.top/a/1578317883.zip", "C:\\Users\\Administrator\\Desktop\\压测.zip");
			MessageBox.Show("文件保存目录为:桌面\\压测.zip", "客户端提示");
		}
	}

	// Token: 0x06000008 RID: 8 RVA: 0x00006414 File Offset: 0x00004614
	private static void smethod_1()
	{
		using (WebClient webClient = new WebClient())
		{
			webClient.DownloadFile("http://lksf.13x.top/a/1578313693.zip", "C:\\Users\\Administrator\\Desktop\\辅助盒子.zip");
			MessageBox.Show("文件保存目录为:桌面\\辅助盒子.zip", "客户端提示");
		}
	}

	// Token: 0x06000009 RID: 9 RVA: 0x00006464 File Offset: 0x00004664
	private static void smethod_2()
	{
		using (WebClient webClient = new WebClient())
		{
			webClient.DownloadFile("http://lksf.13x.top/a/1578232846.zip", "C:\\Users\\Administrator\\Desktop\\测压模块.zip");
			MessageBox.Show("文件保存目录为:桌面\\测压模块.zip", "客户端提示");
		}
	}

	// Token: 0x0600000A RID: 10 RVA: 0x000064B4 File Offset: 0x000046B4
	private static void smethod_3()
	{
		using (WebClient webClient = new WebClient())
		{
			webClient.DownloadFile("http://lksf.13x.top/a/1578274902.zip", "C:\\Users\\Administrator\\Desktop\\Cmd集群.zip");
			MessageBox.Show("文件保存目录为:桌面\\Cmd集群.zip", "客户端提示");
		}
	}

	// Token: 0x0600000B RID: 11 RVA: 0x00006504 File Offset: 0x00004704
	private static void smethod_4()
	{
		using (WebClient webClient = new WebClient())
		{
			webClient.DownloadFile("http://lksf.13x.top/a/1578240820.zip ", "C:\\Users\\Administrator\\Desktop\\服务器信息.zip");
			MessageBox.Show("文件保存目录为:桌面\\服务器信息.zip", "客户端提示");
		}
	}

	// Token: 0x0600000C RID: 12 RVA: 0x00006554 File Offset: 0x00004754
	private static void smethod_5()
	{
		using (WebClient webClient = new WebClient())
		{
			webClient.DownloadFile("http://lksf.13x.top/a/1578254549.zip", "C:\\Users\\Administrator\\Desktop\\集群4.6.3.zip");
			MessageBox.Show("文件保存目录为:桌面\\集群4.6.3.zip", "客户端提示");
		}
	}

	// Token: 0x0600000D RID: 13 RVA: 0x000065A4 File Offset: 0x000047A4
	private static void smethod_6()
	{
		using (WebClient webClient = new WebClient())
		{
			webClient.DownloadFile("http://lksf.13x.top/a/1578318696.zip", "C:\\Users\\Administrator\\Desktop\\475.zip");
			MessageBox.Show("文件保存目录为:桌面\\475.zip", "客户端提示");
		}
	}

	// Token: 0x0600000E RID: 14 RVA: 0x0000480C File Offset: 0x00002A0C
	public end2535()
	{
		Class35.NkAVmDjz8ZWXG();
		base..ctor();
	}
}
