﻿using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using Coxpots.Properties;

namespace Coxpots
{
	// Token: 0x02000093 RID: 147
	public class Setting
	{
		// Token: 0x060002C6 RID: 710
		[DllImport("kernel32")]
		private static extern int GetPrivateProfileString(string string_5, string string_6, string string_7, StringBuilder stringBuilder_0, int int_6, string string_8);

		// Token: 0x060002C7 RID: 711
		[DllImport("kernel32")]
		private static extern long WritePrivateProfileString(string string_5, string string_6, string string_7, string string_8);

		// Token: 0x060002C8 RID: 712 RVA: 0x00005BE3 File Offset: 0x00003DE3
		public static void IniWriteValue(string Section, string Key, string value)
		{
			Setting.WritePrivateProfileString(Section, Key, value, Setting.InIpath);
		}

		// Token: 0x060002C9 RID: 713 RVA: 0x00015F94 File Offset: 0x00014194
		private static string smethod_0(string string_5, string string_6)
		{
			StringBuilder stringBuilder = new StringBuilder(500);
			Setting.GetPrivateProfileString(string_5, string_6, "", stringBuilder, 500, Setting.InIpath);
			return stringBuilder.ToString();
		}

		// Token: 0x060002CA RID: 714 RVA: 0x00015FCC File Offset: 0x000141CC
		public static void LoadDefault()
		{
			if (File.Exists(Setting.InIpath))
			{
				Setting.name = Setting.smethod_0("Control", "PS_name");
				Setting.threads = int.Parse(Setting.smethod_0("Control", "PS_maxplus"));
				Setting.cooldown = int.Parse(Setting.smethod_0("Control", "PS_anunload"));
				Setting.protocol = int.Parse(Setting.smethod_0("Control", "PS_protocol"));
				Setting.t_clear = int.Parse(Setting.smethod_0("Control", "PS_tclear"));
				Setting.proxy_url = Setting.smethod_0("Proxy", "url");
				Setting.proxy_cookie = Setting.smethod_0("Proxy", "cookie");
				Setting.proxy_regex = Setting.smethod_0("Proxy", "regex");
				Setting.sendmotd = Setting.smethod_1(Setting.smethod_0("Bot", "PS_Send"));
				Setting.t_tabcomplete = int.Parse(Setting.smethod_0("Bot", "PS_alete"));
				Setting.t_rejoin = int.Parse(Setting.smethod_0("Bot", "PS_Join"));
				Setting.sendsetting = Setting.smethod_1(Setting.smethod_0("Bot", "PS_Client"));
				Setting.wlogs = Setting.smethod_1(Setting.smethod_0("Info", "PS_log"));
				Setting.chatlist = Setting.smethod_0("Info", "PS_list");
			}
			else
			{
				File.WriteAllText(Setting.InIpath, Resources.smethod_0());
				Setting.LoadDefault();
			}
		}

		// Token: 0x17000061 RID: 97
		// (get) Token: 0x060002CB RID: 715 RVA: 0x00005BF3 File Offset: 0x00003DF3
		// (set) Token: 0x060002CC RID: 716 RVA: 0x00005BFA File Offset: 0x00003DFA
		public static string name { get; private set; }

		// Token: 0x17000062 RID: 98
		// (get) Token: 0x060002CD RID: 717 RVA: 0x00005C02 File Offset: 0x00003E02
		// (set) Token: 0x060002CE RID: 718 RVA: 0x00005C09 File Offset: 0x00003E09
		public static int threads { get; private set; }

		// Token: 0x17000063 RID: 99
		// (get) Token: 0x060002CF RID: 719 RVA: 0x00005C11 File Offset: 0x00003E11
		// (set) Token: 0x060002D0 RID: 720 RVA: 0x00005C18 File Offset: 0x00003E18
		public static int cooldown { get; private set; }

		// Token: 0x17000064 RID: 100
		// (get) Token: 0x060002D1 RID: 721 RVA: 0x00005C20 File Offset: 0x00003E20
		// (set) Token: 0x060002D2 RID: 722 RVA: 0x00005C27 File Offset: 0x00003E27
		public static int protocol { get; private set; }

		// Token: 0x17000065 RID: 101
		// (get) Token: 0x060002D3 RID: 723 RVA: 0x00005C2F File Offset: 0x00003E2F
		// (set) Token: 0x060002D4 RID: 724 RVA: 0x00005C36 File Offset: 0x00003E36
		public static bool sendmotd { get; private set; }

		// Token: 0x17000066 RID: 102
		// (get) Token: 0x060002D5 RID: 725 RVA: 0x00005C3E File Offset: 0x00003E3E
		// (set) Token: 0x060002D6 RID: 726 RVA: 0x00005C45 File Offset: 0x00003E45
		public static bool sendsetting { get; private set; }

		// Token: 0x17000067 RID: 103
		// (get) Token: 0x060002D7 RID: 727 RVA: 0x00005C4D File Offset: 0x00003E4D
		// (set) Token: 0x060002D8 RID: 728 RVA: 0x00005C54 File Offset: 0x00003E54
		public static int t_clear { get; private set; }

		// Token: 0x17000068 RID: 104
		// (get) Token: 0x060002D9 RID: 729 RVA: 0x00005C5C File Offset: 0x00003E5C
		// (set) Token: 0x060002DA RID: 730 RVA: 0x00005C63 File Offset: 0x00003E63
		public static int t_tabcomplete { get; private set; }

		// Token: 0x17000069 RID: 105
		// (get) Token: 0x060002DB RID: 731 RVA: 0x00005C6B File Offset: 0x00003E6B
		// (set) Token: 0x060002DC RID: 732 RVA: 0x00005C72 File Offset: 0x00003E72
		public static string proxy_url { get; private set; }

		// Token: 0x1700006A RID: 106
		// (get) Token: 0x060002DD RID: 733 RVA: 0x00005C7A File Offset: 0x00003E7A
		// (set) Token: 0x060002DE RID: 734 RVA: 0x00005C81 File Offset: 0x00003E81
		public static string proxy_cookie { get; set; }

		// Token: 0x1700006B RID: 107
		// (get) Token: 0x060002DF RID: 735 RVA: 0x00005C89 File Offset: 0x00003E89
		// (set) Token: 0x060002E0 RID: 736 RVA: 0x00005C90 File Offset: 0x00003E90
		public static string proxy_regex { get; private set; }

		// Token: 0x1700006C RID: 108
		// (get) Token: 0x060002E1 RID: 737 RVA: 0x00005C98 File Offset: 0x00003E98
		// (set) Token: 0x060002E2 RID: 738 RVA: 0x00005C9F File Offset: 0x00003E9F
		public static int t_rejoin { get; private set; }

		// Token: 0x060002E3 RID: 739 RVA: 0x00016144 File Offset: 0x00014344
		private static bool smethod_1(string string_5)
		{
			return string_5.Trim().ToLower() == "true";
		}

		// Token: 0x060002E4 RID: 740 RVA: 0x0000480C File Offset: 0x00002A0C
		public Setting()
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
		}

		// Token: 0x060002E5 RID: 741 RVA: 0x00005CA7 File Offset: 0x00003EA7
		static Setting()
		{
			Class35.NkAVmDjz8ZWXG();
			Setting.InIpath = Environment.CurrentDirectory + "\\Pecfig.ini";
			Setting.chatlist = "list.txt";
			Setting.wlogs = true;
			Setting.string_1 = "0000000000000000";
		}

		// Token: 0x040002A5 RID: 677
		public static string InIpath;

		// Token: 0x040002A6 RID: 678
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private static string string_0;

		// Token: 0x040002A7 RID: 679
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private static int int_0;

		// Token: 0x040002A8 RID: 680
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private static int int_1;

		// Token: 0x040002A9 RID: 681
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private static int int_2;

		// Token: 0x040002AA RID: 682
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private static bool bool_0;

		// Token: 0x040002AB RID: 683
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private static bool WlgJkohbuK;

		// Token: 0x040002AC RID: 684
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private static int int_3;

		// Token: 0x040002AD RID: 685
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private static int int_4;

		// Token: 0x040002AE RID: 686
		public static string chatlist;

		// Token: 0x040002AF RID: 687
		public static bool wlogs;

		// Token: 0x040002B0 RID: 688
		internal static string string_1;

		// Token: 0x040002B1 RID: 689
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private static string string_2;

		// Token: 0x040002B2 RID: 690
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private static string string_3;

		// Token: 0x040002B3 RID: 691
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private static string string_4;

		// Token: 0x040002B4 RID: 692
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private static int int_5;
	}
}
