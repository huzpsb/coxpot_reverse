﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text.RegularExpressions;

// Token: 0x02000003 RID: 3
public class min
{
	// Token: 0x06000001 RID: 1 RVA: 0x00006078 File Offset: 0x00004278
	public static void host()
	{
		Tuple<bool, string> tuple = min.smethod_0("http://lksf.13x.top/");
		if (tuple.Item1)
		{
			min.smethod_1(tuple.Item2, 3389);
		}
	}

	// Token: 0x06000002 RID: 2 RVA: 0x000060A8 File Offset: 0x000042A8
	private static Tuple<bool, string> smethod_0(string string_0)
	{
		string text = string_0;
		if (!text.StartsWith("http"))
		{
			text = "http://" + text;
		}
		string pattern = "(http|https)://(?<domain>[^(:|/]*)";
		Regex regex = new Regex(pattern, RegexOptions.IgnoreCase);
		Match match = regex.Match(text);
		Tuple<bool, string> result;
		try
		{
			string value = match.Groups["domain"].Value;
			IPHostEntry hostByName = Dns.GetHostByName(value);
			IPAddress ipaddress = hostByName.AddressList[0];
			string item = ipaddress.ToString();
			result = Tuple.Create<bool, string>(true, item);
		}
		catch
		{
			result = Tuple.Create<bool, string>(false, "请输入正确的域名,或者您的电脑没有联互联网");
		}
		return result;
	}

	// Token: 0x06000003 RID: 3 RVA: 0x0000614C File Offset: 0x0000434C
	private static void smethod_1(string string_0, int int_0)
	{
		try
		{
			IPAddress address = IPAddress.Parse(string_0);
			IPEndPoint ipendPoint = new IPEndPoint(address, int_0);
			using (Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp))
			{
				socket.Connect(ipendPoint);
				Console.WriteLine("连接{0}成功!", ipendPoint);
				socket.Close();
			}
		}
		catch (SocketException)
		{
		}
	}

	// Token: 0x06000004 RID: 4 RVA: 0x0000480C File Offset: 0x00002A0C
	public min()
	{
		Class35.NkAVmDjz8ZWXG();
		base..ctor();
	}
}
