﻿using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Runtime.CompilerServices;
using System.Threading;

// Token: 0x02000005 RID: 5
public class DownloadHelper
{
	// Token: 0x14000001 RID: 1
	// (add) Token: 0x0600000F RID: 15 RVA: 0x000065F4 File Offset: 0x000047F4
	// (remove) Token: 0x06000010 RID: 16 RVA: 0x0000662C File Offset: 0x0000482C
	public event Action<int> ShowDownloadPercent
	{
		[CompilerGenerated]
		add
		{
			Action<int> action = this.action_0;
			Action<int> action2;
			do
			{
				action2 = action;
				Action<int> value2 = (Action<int>)Delegate.Combine(action2, value);
				action = Interlocked.CompareExchange<Action<int>>(ref this.action_0, value2, action2);
			}
			while (action != action2);
		}
		[CompilerGenerated]
		remove
		{
			Action<int> action = this.action_0;
			Action<int> action2;
			do
			{
				action2 = action;
				Action<int> value2 = (Action<int>)Delegate.Remove(action2, value);
				action = Interlocked.CompareExchange<Action<int>>(ref this.action_0, value2, action2);
			}
			while (action != action2);
		}
	}

	// Token: 0x06000011 RID: 17 RVA: 0x00006664 File Offset: 0x00004864
	public int DownloadFile(string url, string localfile)
	{
		int num = 0;
		string text = localfile + ".downloading";
		try
		{
			long num2 = 0L;
			FileStream fileStream = null;
			if (string.IsNullOrEmpty(url) || string.IsNullOrEmpty(localfile))
			{
				return 1;
			}
			long num3 = this.method_1(url);
			if (num3 == 0L)
			{
				return 2;
			}
			if (File.Exists(localfile))
			{
				return 0;
			}
			if (File.Exists(text))
			{
				fileStream = File.OpenWrite(text);
				num2 = fileStream.Length;
				if (num2 > num3)
				{
					fileStream.Close();
					File.Delete(text);
					fileStream = new FileStream(text, FileMode.Create);
				}
				else
				{
					if (num2 == num3)
					{
						this.method_0(localfile, text);
						fileStream.Close();
						return 0;
					}
					fileStream.Seek(num2, SeekOrigin.Begin);
				}
			}
			else
			{
				fileStream = new FileStream(text, FileMode.Create);
			}
			HttpWebRequest httpWebRequest = null;
			HttpWebResponse httpWebResponse = null;
			try
			{
				httpWebRequest = (HttpWebRequest)WebRequest.Create(url);
				if (num2 > 0L)
				{
					httpWebRequest.AddRange((int)num2);
				}
				httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
				using (Stream responseStream = httpWebResponse.GetResponseStream())
				{
					byte[] array = new byte[this.int_0];
					long num4 = num2;
					int num5;
					while ((num5 = responseStream.Read(array, 0, array.Length)) > 0)
					{
						fileStream.Write(array, 0, num5);
						num4 += (long)num5;
						if (this.action_0 != null)
						{
							this.action_0((int)(num4 * 100L / num3));
						}
					}
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("获取远程文件失败！exception：\n" + ex.ToString());
				num = 3;
			}
			finally
			{
				if (fileStream != null)
				{
					fileStream.Close();
				}
				if (httpWebResponse != null)
				{
					httpWebResponse.Close();
				}
				if (httpWebRequest != null)
				{
					httpWebRequest.Abort();
				}
				if (num == 0)
				{
					this.method_0(localfile, text);
				}
			}
		}
		catch (Exception ex2)
		{
			Console.WriteLine("获取远程文件失败！exception：\n" + ex2.ToString());
			num = 4;
		}
		return num;
	}

	// Token: 0x06000012 RID: 18 RVA: 0x000068D8 File Offset: 0x00004AD8
	private void method_0(string string_0, string string_1)
	{
		try
		{
			FileInfo fileInfo = new FileInfo(string_1);
			fileInfo.MoveTo(string_0);
		}
		catch (Exception ex)
		{
			Console.WriteLine(ex.ToString());
		}
		finally
		{
			if (this.action_0 != null)
			{
				this.action_0(100);
			}
		}
	}

	// Token: 0x06000013 RID: 19 RVA: 0x0000693C File Offset: 0x00004B3C
	private long method_1(string string_0)
	{
		long result = 0L;
		HttpWebRequest httpWebRequest = null;
		HttpWebResponse httpWebResponse = null;
		try
		{
			httpWebRequest = (HttpWebRequest)WebRequest.Create(string_0);
			httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
			if (httpWebResponse.StatusCode == HttpStatusCode.OK)
			{
				result = httpWebResponse.ContentLength;
			}
		}
		catch (Exception ex)
		{
			Console.WriteLine("获取远程文件大小失败！exception：\n" + ex.ToString());
		}
		finally
		{
			if (httpWebResponse != null)
			{
				httpWebResponse.Close();
			}
			if (httpWebRequest != null)
			{
				httpWebRequest.Abort();
			}
		}
		return result;
	}

	// Token: 0x06000014 RID: 20 RVA: 0x00004819 File Offset: 0x00002A19
	public DownloadHelper()
	{
		Class35.NkAVmDjz8ZWXG();
		this.int_0 = 1024;
		base..ctor();
	}

	// Token: 0x04000001 RID: 1
	private int int_0;

	// Token: 0x04000002 RID: 2
	[DebuggerBrowsable(DebuggerBrowsableState.Never)]
	[CompilerGenerated]
	private Action<int> action_0;
}
