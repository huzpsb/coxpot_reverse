﻿using System;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using Coxpots;
using Coxpots.Protocol.Client;
using Coxpots.Protocol.Client.Handler;
using Coxpots.Protocol.Server;
using Coxpots.Protocol.Server.Forge;
using Starksoft.Net.Proxy;

// Token: 0x020000AA RID: 170
internal class Class28
{
	// Token: 0x06000372 RID: 882 RVA: 0x0001A71C File Offset: 0x0001891C
	public Class28(ServerInfo serverInfo_1, string string_1, int int_2, List<string> list_3, int int_3 = 0)
	{
		Class35.NkAVmDjz8ZWXG();
		this.list_0 = new List<Class28.Class29>();
		this.list_2 = new List<string>();
		this.bool_0 = true;
		base..ctor();
		this.list_1 = list_3;
		this.string_0 = string_1;
		Class28.serverInfo_0 = serverInfo_1;
		this.int_0 = int_2;
		if (int_3 == 0)
		{
			Class28.int_1 = Class28.serverInfo_0.ProtocolVersion;
		}
		else
		{
			Class28.int_1 = int_3;
		}
	}

	// Token: 0x06000373 RID: 883 RVA: 0x0001A78C File Offset: 0x0001898C
	internal void method_0(int int_2 = 0)
	{
		try
		{
			while (this.bool_0)
			{
				if (this.list_0.Count < this.int_0)
				{
					if (this.list_2.Count <= 0)
					{
						Class16.smethod_0("获取代理中....", "CooKie");
						Class26.smethod_0(this.list_2);
					}
					new Class28.Class29(Class28.serverInfo_0.ServerIP, Class28.serverInfo_0.ServerPort, this.string_0, Class28.int_1, Class28.serverInfo_0.ForgeInfo, this)
					{
						list_0 = this.list_1
					}.method_0();
					Thread.Sleep(int_2);
				}
				else
				{
					this.method_2();
				}
			}
		}
		catch (Exception ex)
		{
			Class16.smethod_0(ex.Message, "错误");
		}
	}

	// Token: 0x06000374 RID: 884 RVA: 0x0001A864 File Offset: 0x00018A64
	internal string method_1()
	{
		string result = this.list_2[0];
		this.list_2.RemoveAt(0);
		return result;
	}

	// Token: 0x06000375 RID: 885 RVA: 0x0001A890 File Offset: 0x00018A90
	private void method_2()
	{
		Thread.Sleep(Setting.t_clear);
		int num = 0;
		Class16.smethod_0("运行线程:" + this.list_0.Count.ToString(), "Souiny");
		Class16.smethod_0("清理残留:" + num.ToString(), "Souiny");
		Class16.smethod_0("提取代理数量:" + this.list_2.Count.ToString(), "Souiny");
		GC.Collect();
	}

	// Token: 0x040002EA RID: 746
	private int int_0;

	// Token: 0x040002EB RID: 747
	public List<Class28.Class29> list_0;

	// Token: 0x040002EC RID: 748
	private List<string> list_1;

	// Token: 0x040002ED RID: 749
	private List<string> list_2;

	// Token: 0x040002EE RID: 750
	private string string_0;

	// Token: 0x040002EF RID: 751
	public bool bool_0;

	// Token: 0x040002F0 RID: 752
	public static ServerInfo serverInfo_0;

	// Token: 0x040002F1 RID: 753
	public static int int_1;

	// Token: 0x020000AB RID: 171
	public class Class29 : IDisposable, IMinecraftCom
	{
		// Token: 0x06000376 RID: 886 RVA: 0x0001A918 File Offset: 0x00018B18
		internal Class29(string string_4, int int_3, string string_5, int int_4, ForgeInfo forgeInfo_1, Class28 class28_1)
		{
			Class35.NkAVmDjz8ZWXG();
			this.dateTime_0 = DateTime.Now;
			this.int_0 = 0;
			this.string_2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_";
			base..ctor();
			this.int_1 = int_4;
			this.string_1 = string_4;
			this.int_2 = int_3;
			this.forgeInfo_0 = forgeInfo_1;
			this.class28_0 = class28_1;
			if (string_5 != null)
			{
				this.string_3 = string_5.Replace("%RANDOM%", this.method_5());
			}
		}

		// Token: 0x06000377 RID: 887 RVA: 0x00005F08 File Offset: 0x00004108
		internal void method_0()
		{
			this.thread_0 = new Thread(new ThreadStart(this.method_6));
			this.thread_0.Start();
		}

		// Token: 0x06000378 RID: 888 RVA: 0x00005F2C File Offset: 0x0000412C
		public void OnGameJoin()
		{
			if (Setting.sendsetting)
			{
				this.class25_0.method_29("en_US", 9, 0, 0, false, 65, 0);
			}
			this.dateTime_0 = DateTime.Now;
		}

		// Token: 0x06000379 RID: 889 RVA: 0x0001A990 File Offset: 0x00018B90
		public void OnKeepAlive()
		{
			foreach (string text in this.list_0)
			{
				this.class25_0.method_27(text);
			}
		}

		// Token: 0x0600037A RID: 890 RVA: 0x00005F59 File Offset: 0x00004159
		public void OnChat()
		{
			this.dateTime_0 = DateTime.Now;
		}

		// Token: 0x0600037B RID: 891 RVA: 0x0001A9EC File Offset: 0x00018BEC
		public void OnConnectionLost(BotUtils.DisconnectReason type, string msg)
		{
			if (type == BotUtils.DisconnectReason.InGameKick)
			{
				Class16.smethod_0(string.Format("{0}连接丢失:{1}", this.string_3, Class19.smethod_0(msg, null)), "Conss");
				if (Setting.t_rejoin > 0)
				{
					this.method_1();
				}
				else
				{
					this.Dispose();
				}
			}
			else if (type == BotUtils.DisconnectReason.LoginRejected)
			{
				Class16.smethod_0(string.Format("{0}拒绝连接:{1}", this.string_3, Class19.smethod_0(msg, null)), "Conss");
				if (Setting.t_rejoin > 0)
				{
					this.method_1();
				}
				else
				{
					this.Dispose();
				}
			}
			else if (type == BotUtils.DisconnectReason.ConnectionLost)
			{
				this.Dispose();
			}
		}

		// Token: 0x0600037C RID: 892 RVA: 0x0001AA88 File Offset: 0x00018C88
		private void method_1()
		{
			if (Setting.t_rejoin < 1000)
			{
				Thread.Sleep(Setting.t_rejoin);
				this.dateTime_0 = DateTime.Now;
			}
			else
			{
				int num = Setting.t_rejoin / 1000;
				for (int i = 0; i < num; i++)
				{
					Thread.Sleep(1000);
					this.dateTime_0 = DateTime.Now;
				}
			}
			this.method_0();
		}

		// Token: 0x0600037D RID: 893 RVA: 0x0001AAF0 File Offset: 0x00018CF0
		public void method_2(TcpClient tcpClient_1)
		{
			byte[] varInt = ProtocolHandler.getVarInt(0);
			byte[] varInt2 = ProtocolHandler.getVarInt(-1);
			byte[] bytes = Encoding.UTF8.GetBytes(this.string_1);
			byte[] varInt3 = ProtocolHandler.getVarInt(bytes.Length);
			byte[] bytes2 = BitConverter.GetBytes((ushort)this.int_2);
			Array.Reverse(bytes2);
			byte[] varInt4 = ProtocolHandler.getVarInt(1);
			byte[] array = ProtocolHandler.concatBytes(new byte[][]
			{
				varInt,
				varInt2,
				varInt3,
				bytes,
				bytes2,
				varInt4
			});
			byte[] buffer = ProtocolHandler.concatBytes(new byte[][]
			{
				ProtocolHandler.getVarInt(array.Length),
				array
			});
			tcpClient_1.Client.Send(buffer, SocketFlags.None);
			byte[] varInt5 = ProtocolHandler.getVarInt(0);
			byte[] buffer2 = ProtocolHandler.concatBytes(new byte[][]
			{
				ProtocolHandler.getVarInt(varInt5.Length),
				varInt5
			});
			tcpClient_1.Client.Send(buffer2, SocketFlags.None);
			ProtocolHandler protocolHandler = new ProtocolHandler(tcpClient_1);
			protocolHandler.readNextVarIntRAW();
		}

		// Token: 0x0600037E RID: 894 RVA: 0x0001ABDC File Offset: 0x00018DDC
		private TcpClient method_3()
		{
			if (this.int_0 == 0)
			{
				string[] array = this.class28_0.method_1().Split(new char[]
				{
					':'
				});
				if (array.Length == 2)
				{
					this.string_0 = array[0];
					this.int_0 = int.Parse(array[1]);
				}
				else
				{
					this.string_0 = array[0];
					this.int_0 = 8080;
				}
			}
			ProxyClientFactory proxyClientFactory = new ProxyClientFactory();
			IProxyClient proxyClient = proxyClientFactory.CreateProxyClient(ProxyType.Http, this.string_0, this.int_0);
			return proxyClient.CreateConnection(this.string_1, this.int_2);
		}

		// Token: 0x0600037F RID: 895 RVA: 0x00005F66 File Offset: 0x00004166
		private void method_4()
		{
			this.thread_1 = new Thread(new ThreadStart(this.method_7));
			this.thread_1.IsBackground = true;
			this.thread_1.Start();
		}

		// Token: 0x06000380 RID: 896 RVA: 0x0001AC74 File Offset: 0x00018E74
		private string method_5()
		{
			Random random = new Random();
			int num = random.Next(5, 15);
			string text = "";
			for (int i = 0; i < num; i++)
			{
				text += this.string_2[random.Next(0, this.string_2.Length - 1)].ToString();
			}
			return text;
		}

		// Token: 0x06000381 RID: 897 RVA: 0x0001ACDC File Offset: 0x00018EDC
		public void Dispose()
		{
			this.thread_0.Abort();
			if (this.class25_0 != null)
			{
				this.class25_0.method_32();
			}
			else if (this.tcpClient_0 != null)
			{
				this.tcpClient_0.Close();
			}
			this.tcpClient_0 = null;
			if (this.thread_1 != null)
			{
				this.thread_1.Abort();
			}
			this.class28_0.list_0.Remove(this);
		}

		// Token: 0x06000382 RID: 898 RVA: 0x0001AD54 File Offset: 0x00018F54
		[CompilerGenerated]
		private void method_6()
		{
			try
			{
				this.class28_0.list_0.Add(this);
				if (Setting.sendmotd)
				{
					this.tcpClient_0 = this.method_3();
					this.method_2(this.tcpClient_0);
					Thread.Sleep(300);
				}
				this.tcpClient_0 = this.method_3();
				this.tcpClient_0.ReceiveTimeout = 10000;
				this.tcpClient_0.SendTimeout = 10000;
				this.class25_0 = new Class25(this.tcpClient_0, this.int_1, this, this.forgeInfo_0);
				if (this.class25_0.method_23(this.string_1, this.int_2, this.string_3))
				{
					if (Setting.t_tabcomplete > 0)
					{
						this.method_4();
					}
					Class16.smethod_0(this.string_3 + " 加入成功", "玩家系统");
					this.class25_0.method_22(false);
				}
			}
			catch
			{
				this.Dispose();
			}
		}

		// Token: 0x06000383 RID: 899 RVA: 0x00005F96 File Offset: 0x00004196
		[CompilerGenerated]
		private void method_7()
		{
			while (this.tcpClient_0 != null && this.tcpClient_0.Connected)
			{
				Thread.Sleep(Setting.t_tabcomplete);
				this.class25_0.method_31("/");
			}
		}

		// Token: 0x040002F2 RID: 754
		private TcpClient tcpClient_0;

		// Token: 0x040002F3 RID: 755
		public DateTime dateTime_0;

		// Token: 0x040002F4 RID: 756
		private string string_0;

		// Token: 0x040002F5 RID: 757
		private int int_0;

		// Token: 0x040002F6 RID: 758
		private int int_1;

		// Token: 0x040002F7 RID: 759
		private string string_1;

		// Token: 0x040002F8 RID: 760
		private int int_2;

		// Token: 0x040002F9 RID: 761
		private string string_2;

		// Token: 0x040002FA RID: 762
		private string string_3;

		// Token: 0x040002FB RID: 763
		private ForgeInfo forgeInfo_0;

		// Token: 0x040002FC RID: 764
		private Class25 class25_0;

		// Token: 0x040002FD RID: 765
		public List<string> list_0;

		// Token: 0x040002FE RID: 766
		private Class28 class28_0;

		// Token: 0x040002FF RID: 767
		private Thread thread_0;

		// Token: 0x04000300 RID: 768
		private Thread thread_1;
	}
}
