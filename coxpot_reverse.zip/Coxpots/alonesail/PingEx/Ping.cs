﻿using System;

namespace alonesail.PingEx
{
	// Token: 0x02000008 RID: 8
	public static class Ping
	{
	}
}
