﻿using System;
using System.Runtime.Serialization;

namespace Starksoft.Net.Proxy
{
	// Token: 0x0200000A RID: 10
	[Serializable]
	public class ProxyException : Exception
	{
		// Token: 0x0600001B RID: 27 RVA: 0x00004848 File Offset: 0x00002A48
		public ProxyException()
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
		}

		// Token: 0x0600001C RID: 28 RVA: 0x00004855 File Offset: 0x00002A55
		public ProxyException(string message)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor(message);
		}

		// Token: 0x0600001D RID: 29 RVA: 0x00004863 File Offset: 0x00002A63
		public ProxyException(string message, Exception innerException)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor(message, innerException);
		}

		// Token: 0x0600001E RID: 30 RVA: 0x00004872 File Offset: 0x00002A72
		protected ProxyException(SerializationInfo info, StreamingContext context)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor(info, context);
		}
	}
}
