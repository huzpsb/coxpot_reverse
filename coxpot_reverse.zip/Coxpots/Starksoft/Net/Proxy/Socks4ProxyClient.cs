﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;

namespace Starksoft.Net.Proxy
{
	// Token: 0x02000011 RID: 17
	public class Socks4ProxyClient : IProxyClient
	{
		// Token: 0x06000054 RID: 84 RVA: 0x0000480C File Offset: 0x00002A0C
		public Socks4ProxyClient()
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
		}

		// Token: 0x06000055 RID: 85 RVA: 0x00004A10 File Offset: 0x00002C10
		public Socks4ProxyClient(TcpClient tcpClient)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			if (tcpClient == null)
			{
				throw new ArgumentNullException("tcpClient");
			}
			this.tcpClient_1 = tcpClient;
		}

		// Token: 0x06000056 RID: 86 RVA: 0x000075C0 File Offset: 0x000057C0
		public Socks4ProxyClient(string proxyHost, string proxyUserId)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			if (string.IsNullOrEmpty(proxyHost))
			{
				throw new ArgumentNullException("proxyHost");
			}
			if (proxyUserId == null)
			{
				throw new ArgumentNullException("proxyUserId");
			}
			this.rOrajPpHu = proxyHost;
			this.int_0 = 1080;
			this.string_0 = proxyUserId;
		}

		// Token: 0x06000057 RID: 87 RVA: 0x00007618 File Offset: 0x00005818
		public Socks4ProxyClient(string proxyHost, int proxyPort, string proxyUserId)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			if (string.IsNullOrEmpty(proxyHost))
			{
				throw new ArgumentNullException("proxyHost");
			}
			if (proxyPort <= 0 || proxyPort > 65535)
			{
				throw new ArgumentOutOfRangeException("proxyPort", "port must be greater than zero and less than 65535");
			}
			if (proxyUserId == null)
			{
				throw new ArgumentNullException("proxyUserId");
			}
			this.rOrajPpHu = proxyHost;
			this.int_0 = proxyPort;
			this.string_0 = proxyUserId;
		}

		// Token: 0x06000058 RID: 88 RVA: 0x00004A35 File Offset: 0x00002C35
		public Socks4ProxyClient(string proxyHost)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			if (string.IsNullOrEmpty(proxyHost))
			{
				throw new ArgumentNullException("proxyHost");
			}
			this.rOrajPpHu = proxyHost;
			this.int_0 = 1080;
		}

		// Token: 0x06000059 RID: 89 RVA: 0x0000768C File Offset: 0x0000588C
		public Socks4ProxyClient(string proxyHost, int proxyPort)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			if (string.IsNullOrEmpty(proxyHost))
			{
				throw new ArgumentNullException("proxyHost");
			}
			if (proxyPort <= 0 || proxyPort > 65535)
			{
				throw new ArgumentOutOfRangeException("proxyPort", "port must be greater than zero and less than 65535");
			}
			this.rOrajPpHu = proxyHost;
			this.int_0 = proxyPort;
		}

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x0600005A RID: 90 RVA: 0x000076E8 File Offset: 0x000058E8
		// (set) Token: 0x0600005B RID: 91 RVA: 0x00004A67 File Offset: 0x00002C67
		public string ProxyHost
		{
			get
			{
				return this.rOrajPpHu;
			}
			set
			{
				this.rOrajPpHu = value;
			}
		}

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x0600005C RID: 92 RVA: 0x00007700 File Offset: 0x00005900
		// (set) Token: 0x0600005D RID: 93 RVA: 0x00004A70 File Offset: 0x00002C70
		public int ProxyPort
		{
			get
			{
				return this.int_0;
			}
			set
			{
				this.int_0 = value;
			}
		}

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x0600005E RID: 94 RVA: 0x00007718 File Offset: 0x00005918
		public virtual string ProxyName
		{
			get
			{
				return "SOCKS4";
			}
		}

		// Token: 0x17000010 RID: 16
		// (get) Token: 0x0600005F RID: 95 RVA: 0x0000772C File Offset: 0x0000592C
		// (set) Token: 0x06000060 RID: 96 RVA: 0x00004A79 File Offset: 0x00002C79
		public string ProxyUserId
		{
			get
			{
				return this.string_0;
			}
			set
			{
				this.string_0 = value;
			}
		}

		// Token: 0x17000011 RID: 17
		// (get) Token: 0x06000061 RID: 97 RVA: 0x00007744 File Offset: 0x00005944
		// (set) Token: 0x06000062 RID: 98 RVA: 0x00004A82 File Offset: 0x00002C82
		public TcpClient TcpClient
		{
			get
			{
				return this.tcpClient_1;
			}
			set
			{
				this.tcpClient_1 = value;
			}
		}

		// Token: 0x06000063 RID: 99 RVA: 0x0000775C File Offset: 0x0000595C
		public TcpClient CreateConnection(string destinationHost, int destinationPort)
		{
			if (string.IsNullOrEmpty(destinationHost))
			{
				throw new ArgumentNullException("destinationHost");
			}
			if (destinationPort <= 0 || destinationPort > 65535)
			{
				throw new ArgumentOutOfRangeException("destinationPort", "port must be greater than zero and less than 65535");
			}
			TcpClient result;
			try
			{
				if (this.tcpClient_1 == null)
				{
					if (string.IsNullOrEmpty(this.rOrajPpHu))
					{
						throw new ProxyException("ProxyHost property must contain a value.");
					}
					if (this.int_0 <= 0 || this.int_0 > 65535)
					{
						throw new ProxyException("ProxyPort value must be greater than zero and less than 65535");
					}
					this.tcpClient_0 = new TcpClient();
					this.tcpClient_0.Connect(this.rOrajPpHu, this.int_0);
				}
				else
				{
					this.tcpClient_0 = this.tcpClient_1;
				}
				this.vmethod_0(this.tcpClient_0.GetStream(), 1, destinationHost, destinationPort, this.string_0);
				TcpClient tcpClient = this.tcpClient_0;
				this.tcpClient_0 = null;
				result = tcpClient;
			}
			catch (Exception innerException)
			{
				throw new ProxyException(string.Format(CultureInfo.InvariantCulture, "Connection to proxy host {0} on port {1} failed.", new object[]
				{
					Class1.smethod_0(this.tcpClient_0),
					Class1.smethod_1(this.tcpClient_0)
				}), innerException);
			}
			return result;
		}

		// Token: 0x06000064 RID: 100 RVA: 0x00007890 File Offset: 0x00005A90
		internal virtual void vmethod_0(NetworkStream proxy, byte command, string destinationHost, int destinationPort, string userId)
		{
			if (userId == null)
			{
				userId = "";
			}
			byte[] array = this.iaNltLrkj(destinationHost);
			byte[] array2 = this.method_0(destinationPort);
			byte[] bytes = Encoding.ASCII.GetBytes(userId);
			byte[] array3 = new byte[9 + bytes.Length];
			array3[0] = 4;
			array3[1] = command;
			array2.CopyTo(array3, 2);
			array.CopyTo(array3, 4);
			bytes.CopyTo(array3, 8);
			array3[8 + bytes.Length] = 0;
			proxy.Write(array3, 0, array3.Length);
			this.method_2(proxy);
			byte[] array4 = new byte[8];
			proxy.Read(array4, 0, 8);
			if (array4[1] != 90)
			{
				this.method_1(array4, destinationHost, destinationPort);
			}
		}

		// Token: 0x06000065 RID: 101 RVA: 0x0000793C File Offset: 0x00005B3C
		internal byte[] iaNltLrkj(string string_1)
		{
			IPAddress ipaddress = null;
			if (!IPAddress.TryParse(string_1, out ipaddress))
			{
				try
				{
					ipaddress = Dns.GetHostEntry(string_1).AddressList[0];
				}
				catch (Exception innerException)
				{
					throw new ProxyException(string.Format(CultureInfo.InvariantCulture, "A error occurred while attempting to DNS resolve the host name {0}.", new object[]
					{
						string_1
					}), innerException);
				}
			}
			return ipaddress.GetAddressBytes();
		}

		// Token: 0x06000066 RID: 102 RVA: 0x000079A4 File Offset: 0x00005BA4
		internal byte[] method_0(int int_1)
		{
			return new byte[]
			{
				Convert.ToByte(int_1 / 256),
				Convert.ToByte(int_1 % 256)
			};
		}

		// Token: 0x06000067 RID: 103 RVA: 0x000079DC File Offset: 0x00005BDC
		internal void method_1(byte[] byte_0, string string_1, int int_1)
		{
			if (byte_0 == null)
			{
				throw new ArgumentNullException("response");
			}
			byte b = byte_0[1];
			byte[] array = new byte[4];
			for (int i = 0; i < 4; i++)
			{
				array[i] = byte_0[i + 4];
			}
			IPAddress ipaddress = new IPAddress(array);
			short num = BitConverter.ToInt16(new byte[]
			{
				byte_0[3],
				byte_0[2]
			}, 0);
			string text;
			switch (b)
			{
			case 91:
				text = "connection request was rejected or failed";
				break;
			case 92:
				text = "connection request was rejected because SOCKS destination cannot connect to identd on the client";
				break;
			case 93:
				text = "connection request rejected because the client program and identd report different user-ids";
				break;
			default:
				text = string.Format(CultureInfo.InvariantCulture, "proxy client received an unknown reply with the code value '{0}' from the proxy destination", new object[]
				{
					b.ToString(CultureInfo.InvariantCulture)
				});
				break;
			}
			string message = string.Format(CultureInfo.InvariantCulture, "The {0} concerning destination host {1} port number {2}.  The destination reported the host as {3} port {4}.", new object[]
			{
				text,
				string_1,
				int_1,
				ipaddress.ToString(),
				num.ToString(CultureInfo.InvariantCulture)
			});
			throw new ProxyException(message);
		}

		// Token: 0x06000068 RID: 104 RVA: 0x00007AEC File Offset: 0x00005CEC
		internal void method_2(NetworkStream networkStream_0)
		{
			int num = 0;
			while (!networkStream_0.DataAvailable)
			{
				Thread.Sleep(50);
				num += 50;
				if (num > 15000)
				{
					throw new ProxyException("A timeout while waiting for the proxy destination to respond.");
				}
			}
		}

		// Token: 0x17000012 RID: 18
		// (get) Token: 0x06000069 RID: 105 RVA: 0x00004A8B File Offset: 0x00002C8B
		public bool IsBusy
		{
			get
			{
				return this.backgroundWorker_0 != null && this.backgroundWorker_0.IsBusy;
			}
		}

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x0600006A RID: 106 RVA: 0x00004AA3 File Offset: 0x00002CA3
		public bool IsAsyncCancelled
		{
			get
			{
				return this.imaerMaAm;
			}
		}

		// Token: 0x0600006B RID: 107 RVA: 0x00004AAB File Offset: 0x00002CAB
		public void CancelAsync()
		{
			if (this.backgroundWorker_0 != null && !this.backgroundWorker_0.CancellationPending && this.backgroundWorker_0.IsBusy)
			{
				this.imaerMaAm = true;
				this.backgroundWorker_0.CancelAsync();
			}
		}

		// Token: 0x0600006C RID: 108 RVA: 0x00004AE4 File Offset: 0x00002CE4
		private void method_3()
		{
			if (this.backgroundWorker_0 != null)
			{
				this.backgroundWorker_0.Dispose();
			}
			this.exception_0 = null;
			this.backgroundWorker_0 = null;
			this.imaerMaAm = false;
			this.backgroundWorker_0 = new BackgroundWorker();
		}

		// Token: 0x14000004 RID: 4
		// (add) Token: 0x0600006D RID: 109 RVA: 0x00007B2C File Offset: 0x00005D2C
		// (remove) Token: 0x0600006E RID: 110 RVA: 0x00007B64 File Offset: 0x00005D64
		public event EventHandler<CreateConnectionAsyncCompletedEventArgs> CreateConnectionAsyncCompleted
		{
			[CompilerGenerated]
			add
			{
				EventHandler<CreateConnectionAsyncCompletedEventArgs> eventHandler = this.eventHandler_0;
				EventHandler<CreateConnectionAsyncCompletedEventArgs> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<CreateConnectionAsyncCompletedEventArgs> value2 = (EventHandler<CreateConnectionAsyncCompletedEventArgs>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<CreateConnectionAsyncCompletedEventArgs>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			[CompilerGenerated]
			remove
			{
				EventHandler<CreateConnectionAsyncCompletedEventArgs> eventHandler = this.eventHandler_0;
				EventHandler<CreateConnectionAsyncCompletedEventArgs> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<CreateConnectionAsyncCompletedEventArgs> value2 = (EventHandler<CreateConnectionAsyncCompletedEventArgs>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<CreateConnectionAsyncCompletedEventArgs>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x0600006F RID: 111 RVA: 0x00007B9C File Offset: 0x00005D9C
		public void CreateConnectionAsync(string destinationHost, int destinationPort)
		{
			if (this.backgroundWorker_0 != null && this.backgroundWorker_0.IsBusy)
			{
				throw new InvalidOperationException("The Socks4/4a object is already busy executing another asynchronous operation.  You can only execute one asychronous method at a time.");
			}
			this.method_3();
			this.backgroundWorker_0.WorkerSupportsCancellation = true;
			this.backgroundWorker_0.DoWork += this.backgroundWorker_0_DoWork;
			this.backgroundWorker_0.RunWorkerCompleted += this.backgroundWorker_0_RunWorkerCompleted;
			object[] argument = new object[]
			{
				destinationHost,
				destinationPort
			};
			this.backgroundWorker_0.RunWorkerAsync(argument);
		}

		// Token: 0x06000070 RID: 112 RVA: 0x00007C2C File Offset: 0x00005E2C
		private void backgroundWorker_0_DoWork(object sender, DoWorkEventArgs e)
		{
			try
			{
				object[] array = (object[])e.Argument;
				e.Result = this.CreateConnection((string)array[0], (int)array[1]);
			}
			catch (Exception ex)
			{
				this.exception_0 = ex;
			}
		}

		// Token: 0x06000071 RID: 113 RVA: 0x00004B1C File Offset: 0x00002D1C
		private void backgroundWorker_0_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			if (this.eventHandler_0 != null)
			{
				this.eventHandler_0(this, new CreateConnectionAsyncCompletedEventArgs(this.exception_0, this.imaerMaAm, (TcpClient)e.Result));
			}
		}

		// Token: 0x04000019 RID: 25
		private TcpClient tcpClient_0;

		// Token: 0x0400001A RID: 26
		private TcpClient tcpClient_1;

		// Token: 0x0400001B RID: 27
		private string rOrajPpHu;

		// Token: 0x0400001C RID: 28
		private int int_0;

		// Token: 0x0400001D RID: 29
		private string string_0;

		// Token: 0x0400001E RID: 30
		private BackgroundWorker backgroundWorker_0;

		// Token: 0x0400001F RID: 31
		private Exception exception_0;

		// Token: 0x04000020 RID: 32
		private bool imaerMaAm;

		// Token: 0x04000021 RID: 33
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private EventHandler<CreateConnectionAsyncCompletedEventArgs> eventHandler_0;
	}
}
