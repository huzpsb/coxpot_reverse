﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;

namespace Starksoft.Net.Proxy
{
	// Token: 0x02000012 RID: 18
	public class Socks5ProxyClient : IProxyClient
	{
		// Token: 0x06000072 RID: 114 RVA: 0x0000480C File Offset: 0x00002A0C
		public Socks5ProxyClient()
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
		}

		// Token: 0x06000073 RID: 115 RVA: 0x00004B51 File Offset: 0x00002D51
		public Socks5ProxyClient(TcpClient tcpClient)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			if (tcpClient == null)
			{
				throw new ArgumentNullException("tcpClient");
			}
			this.tcpClient_1 = tcpClient;
		}

		// Token: 0x06000074 RID: 116 RVA: 0x00004B76 File Offset: 0x00002D76
		public Socks5ProxyClient(string proxyHost)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			if (string.IsNullOrEmpty(proxyHost))
			{
				throw new ArgumentNullException("proxyHost");
			}
			this.string_0 = proxyHost;
			this.int_0 = 1080;
		}

		// Token: 0x06000075 RID: 117 RVA: 0x00007C80 File Offset: 0x00005E80
		public Socks5ProxyClient(string proxyHost, int proxyPort)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			if (string.IsNullOrEmpty(proxyHost))
			{
				throw new ArgumentNullException("proxyHost");
			}
			if (proxyPort <= 0 || proxyPort > 65535)
			{
				throw new ArgumentOutOfRangeException("proxyPort", "port must be greater than zero and less than 65535");
			}
			this.string_0 = proxyHost;
			this.int_0 = proxyPort;
		}

		// Token: 0x06000076 RID: 118 RVA: 0x00007CDC File Offset: 0x00005EDC
		public Socks5ProxyClient(string proxyHost, string proxyUserName, string proxyPassword)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			if (string.IsNullOrEmpty(proxyHost))
			{
				throw new ArgumentNullException("proxyHost");
			}
			if (proxyUserName == null)
			{
				throw new ArgumentNullException("proxyUserName");
			}
			if (proxyPassword == null)
			{
				throw new ArgumentNullException("proxyPassword");
			}
			this.string_0 = proxyHost;
			this.int_0 = 1080;
			this.string_1 = proxyUserName;
			this.string_2 = proxyPassword;
		}

		// Token: 0x06000077 RID: 119 RVA: 0x00007D4C File Offset: 0x00005F4C
		public Socks5ProxyClient(string proxyHost, int proxyPort, string proxyUserName, string proxyPassword)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			if (string.IsNullOrEmpty(proxyHost))
			{
				throw new ArgumentNullException("proxyHost");
			}
			if (proxyPort <= 0 || proxyPort > 65535)
			{
				throw new ArgumentOutOfRangeException("proxyPort", "port must be greater than zero and less than 65535");
			}
			if (proxyUserName == null)
			{
				throw new ArgumentNullException("proxyUserName");
			}
			if (proxyPassword == null)
			{
				throw new ArgumentNullException("proxyPassword");
			}
			this.string_0 = proxyHost;
			this.int_0 = proxyPort;
			this.string_1 = proxyUserName;
			this.string_2 = proxyPassword;
		}

		// Token: 0x17000014 RID: 20
		// (get) Token: 0x06000078 RID: 120 RVA: 0x00007DD8 File Offset: 0x00005FD8
		// (set) Token: 0x06000079 RID: 121 RVA: 0x00004BA8 File Offset: 0x00002DA8
		public string ProxyHost
		{
			get
			{
				return this.string_0;
			}
			set
			{
				this.string_0 = value;
			}
		}

		// Token: 0x17000015 RID: 21
		// (get) Token: 0x0600007A RID: 122 RVA: 0x00007DF0 File Offset: 0x00005FF0
		// (set) Token: 0x0600007B RID: 123 RVA: 0x00004BB1 File Offset: 0x00002DB1
		public int ProxyPort
		{
			get
			{
				return this.int_0;
			}
			set
			{
				this.int_0 = value;
			}
		}

		// Token: 0x17000016 RID: 22
		// (get) Token: 0x0600007C RID: 124 RVA: 0x00007E08 File Offset: 0x00006008
		public string ProxyName
		{
			get
			{
				return "SOCKS5";
			}
		}

		// Token: 0x17000017 RID: 23
		// (get) Token: 0x0600007D RID: 125 RVA: 0x00007E1C File Offset: 0x0000601C
		// (set) Token: 0x0600007E RID: 126 RVA: 0x00004BBA File Offset: 0x00002DBA
		public string ProxyUserName
		{
			get
			{
				return this.string_1;
			}
			set
			{
				this.string_1 = value;
			}
		}

		// Token: 0x17000018 RID: 24
		// (get) Token: 0x0600007F RID: 127 RVA: 0x00007E34 File Offset: 0x00006034
		// (set) Token: 0x06000080 RID: 128 RVA: 0x00004BC3 File Offset: 0x00002DC3
		public string ProxyPassword
		{
			get
			{
				return this.string_2;
			}
			set
			{
				this.string_2 = value;
			}
		}

		// Token: 0x17000019 RID: 25
		// (get) Token: 0x06000081 RID: 129 RVA: 0x00007E4C File Offset: 0x0000604C
		// (set) Token: 0x06000082 RID: 130 RVA: 0x00004BCC File Offset: 0x00002DCC
		public TcpClient TcpClient
		{
			get
			{
				return this.tcpClient_1;
			}
			set
			{
				this.tcpClient_1 = value;
			}
		}

		// Token: 0x06000083 RID: 131 RVA: 0x00007E64 File Offset: 0x00006064
		public TcpClient CreateConnection(string destinationHost, int destinationPort)
		{
			if (string.IsNullOrEmpty(destinationHost))
			{
				throw new ArgumentNullException("destinationHost");
			}
			if (destinationPort <= 0 || destinationPort > 65535)
			{
				throw new ArgumentOutOfRangeException("destinationPort", "port must be greater than zero and less than 65535");
			}
			TcpClient result;
			try
			{
				if (this.tcpClient_1 == null)
				{
					if (string.IsNullOrEmpty(this.string_0))
					{
						throw new ProxyException("ProxyHost property must contain a value.");
					}
					if (this.int_0 <= 0 || this.int_0 > 65535)
					{
						throw new ProxyException("ProxyPort value must be greater than zero and less than 65535");
					}
					this.tcpClient_0 = new TcpClient();
					this.tcpClient_0.Connect(this.string_0, this.int_0);
				}
				else
				{
					this.tcpClient_0 = this.tcpClient_1;
				}
				this.method_0();
				this.method_1();
				this.method_5(1, destinationHost, destinationPort);
				TcpClient tcpClient = this.tcpClient_0;
				this.tcpClient_0 = null;
				result = tcpClient;
			}
			catch (Exception innerException)
			{
				throw new ProxyException(string.Format(CultureInfo.InvariantCulture, "Connection to proxy host {0} on port {1} failed.", new object[]
				{
					Class1.smethod_0(this.tcpClient_0),
					Class1.smethod_1(this.tcpClient_0)
				}), innerException);
			}
			return result;
		}

		// Token: 0x06000084 RID: 132 RVA: 0x00004BD5 File Offset: 0x00002DD5
		private void method_0()
		{
			if (this.string_1 != null && this.string_2 != null)
			{
				this.enum1_0 = (Socks5ProxyClient.Enum1)1;
			}
			else
			{
				this.enum1_0 = (Socks5ProxyClient.Enum1)0;
			}
		}

		// Token: 0x06000085 RID: 133 RVA: 0x00007F90 File Offset: 0x00006190
		private void method_1()
		{
			NetworkStream stream = this.tcpClient_0.GetStream();
			byte[] array = new byte[]
			{
				5,
				2,
				0,
				2
			};
			stream.Write(array, 0, array.Length);
			byte[] array2 = new byte[2];
			stream.Read(array2, 0, array2.Length);
			byte b = array2[1];
			if (b == 255)
			{
				this.tcpClient_0.Close();
				throw new ProxyException("The proxy destination does not accept the supported proxy client authentication methods.");
			}
			if (b == 2 && this.enum1_0 == (Socks5ProxyClient.Enum1)0)
			{
				this.tcpClient_0.Close();
				throw new ProxyException("The proxy destination requires a username and password for authentication.");
			}
			if (b == 2)
			{
				byte[] array3 = new byte[this.string_1.Length + this.string_2.Length + 3];
				array3[0] = 1;
				array3[1] = (byte)this.string_1.Length;
				Array.Copy(Encoding.ASCII.GetBytes(this.string_1), 0, array3, 2, this.string_1.Length);
				array3[this.string_1.Length + 2] = (byte)this.string_2.Length;
				Array.Copy(Encoding.ASCII.GetBytes(this.string_2), 0, array3, this.string_1.Length + 3, this.string_2.Length);
				stream.Write(array3, 0, array3.Length);
				byte[] array4 = new byte[2];
				stream.Read(array4, 0, array4.Length);
				if (array4[1] > 0)
				{
					this.tcpClient_0.Close();
					throw new ProxyException("Proxy authentification failure!  The proxy server has reported that the userid and/or password is not valid.");
				}
			}
		}

		// Token: 0x06000086 RID: 134 RVA: 0x0000811C File Offset: 0x0000631C
		private byte method_2(string string_3)
		{
			IPAddress ipaddress = null;
			byte result;
			if (!IPAddress.TryParse(string_3, out ipaddress))
			{
				result = 3;
			}
			else
			{
				AddressFamily addressFamily = ipaddress.AddressFamily;
				AddressFamily addressFamily2 = addressFamily;
				if (addressFamily2 != AddressFamily.InterNetwork)
				{
					if (addressFamily2 != AddressFamily.InterNetworkV6)
					{
						throw new ProxyException(string.Format(CultureInfo.InvariantCulture, "The host addess {0} of type '{1}' is not a supported address type.  The supported types are InterNetwork and InterNetworkV6.", new object[]
						{
							string_3,
							Enum.GetName(typeof(AddressFamily), ipaddress.AddressFamily)
						}));
					}
					result = 4;
				}
				else
				{
					result = 1;
				}
			}
			return result;
		}

		// Token: 0x06000087 RID: 135 RVA: 0x00008194 File Offset: 0x00006394
		private byte[] method_3(byte byte_0, string string_3)
		{
			byte[] result;
			switch (byte_0)
			{
			case 1:
			case 4:
				result = IPAddress.Parse(string_3).GetAddressBytes();
				break;
			default:
				result = null;
				break;
			case 3:
			{
				byte[] array = new byte[string_3.Length + 1];
				array[0] = Convert.ToByte(string_3.Length);
				Encoding.ASCII.GetBytes(string_3).CopyTo(array, 1);
				result = array;
				break;
			}
			}
			return result;
		}

		// Token: 0x06000088 RID: 136 RVA: 0x000079A4 File Offset: 0x00005BA4
		private byte[] method_4(int int_1)
		{
			return new byte[]
			{
				Convert.ToByte(int_1 / 256),
				Convert.ToByte(int_1 % 256)
			};
		}

		// Token: 0x06000089 RID: 137 RVA: 0x00008200 File Offset: 0x00006400
		private void method_5(byte byte_0, string string_3, int int_1)
		{
			NetworkStream stream = this.tcpClient_0.GetStream();
			byte b = this.method_2(string_3);
			byte[] array = this.method_3(b, string_3);
			byte[] array2 = this.method_4(int_1);
			byte[] array3 = new byte[4 + array.Length + 2];
			array3[0] = 5;
			array3[1] = byte_0;
			array3[2] = 0;
			array3[3] = b;
			array.CopyTo(array3, 4);
			array2.CopyTo(array3, 4 + array.Length);
			stream.Write(array3, 0, array3.Length);
			byte[] array4 = new byte[255];
			stream.Read(array4, 0, array4.Length);
			byte b2 = array4[1];
			if (b2 > 0)
			{
				this.method_6(array4, string_3, int_1);
			}
		}

		// Token: 0x0600008A RID: 138 RVA: 0x000082A8 File Offset: 0x000064A8
		private void method_6(byte[] byte_0, string string_3, int int_1)
		{
			byte b = byte_0[1];
			byte b2 = byte_0[3];
			string text = "";
			short num = 0;
			switch (b2)
			{
			case 1:
			{
				byte[] array = new byte[4];
				for (int i = 0; i < 4; i++)
				{
					array[i] = byte_0[i + 4];
				}
				IPAddress ipaddress = new IPAddress(array);
				text = ipaddress.ToString();
				num = BitConverter.ToInt16(new byte[]
				{
					byte_0[9],
					byte_0[8]
				}, 0);
				break;
			}
			case 3:
			{
				int num2 = Convert.ToInt32(byte_0[4]);
				byte[] array2 = new byte[num2];
				for (int j = 0; j < num2; j++)
				{
					array2[j] = byte_0[j + 5];
				}
				text = Encoding.ASCII.GetString(array2);
				num = BitConverter.ToInt16(new byte[]
				{
					byte_0[6 + num2],
					byte_0[5 + num2]
				}, 0);
				break;
			}
			case 4:
			{
				byte[] array3 = new byte[16];
				for (int k = 0; k < 16; k++)
				{
					array3[k] = byte_0[k + 4];
				}
				IPAddress ipaddress2 = new IPAddress(array3);
				text = ipaddress2.ToString();
				num = BitConverter.ToInt16(new byte[]
				{
					byte_0[21],
					byte_0[20]
				}, 0);
				break;
			}
			}
			string text2;
			switch (b)
			{
			case 1:
				text2 = "a general socks destination failure occurred";
				break;
			case 2:
				text2 = "the connection is not allowed by proxy destination rule set";
				break;
			case 3:
				text2 = "the network was unreachable";
				break;
			case 4:
				text2 = "the host was unreachable";
				break;
			case 5:
				text2 = "the connection was refused by the remote network";
				break;
			case 6:
				text2 = "the time to live (TTL) has expired";
				break;
			case 7:
				text2 = "the command issued by the proxy client is not supported by the proxy destination";
				break;
			case 8:
				text2 = "the address type specified is not supported";
				break;
			default:
				text2 = string.Format(CultureInfo.InvariantCulture, "that an unknown reply with the code value '{0}' was received by the destination", new object[]
				{
					b.ToString(CultureInfo.InvariantCulture)
				});
				break;
			}
			string message = string.Format(CultureInfo.InvariantCulture, "The {0} concerning destination host {1} port number {2}.  The destination reported the host as {3} port {4}.", new object[]
			{
				text2,
				string_3,
				int_1,
				text,
				num.ToString(CultureInfo.InvariantCulture)
			});
			throw new ProxyException(message);
		}

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x0600008B RID: 139 RVA: 0x00004BFD File Offset: 0x00002DFD
		public bool IsBusy
		{
			get
			{
				return this.backgroundWorker_0 != null && this.backgroundWorker_0.IsBusy;
			}
		}

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x0600008C RID: 140 RVA: 0x00004C15 File Offset: 0x00002E15
		public bool IsAsyncCancelled
		{
			get
			{
				return this.bool_0;
			}
		}

		// Token: 0x0600008D RID: 141 RVA: 0x00004C1D File Offset: 0x00002E1D
		public void CancelAsync()
		{
			if (this.backgroundWorker_0 != null && !this.backgroundWorker_0.CancellationPending && this.backgroundWorker_0.IsBusy)
			{
				this.bool_0 = true;
				this.backgroundWorker_0.CancelAsync();
			}
		}

		// Token: 0x0600008E RID: 142 RVA: 0x00004C56 File Offset: 0x00002E56
		private void method_7()
		{
			if (this.backgroundWorker_0 != null)
			{
				this.backgroundWorker_0.Dispose();
			}
			this.exception_0 = null;
			this.backgroundWorker_0 = null;
			this.bool_0 = false;
			this.backgroundWorker_0 = new BackgroundWorker();
		}

		// Token: 0x14000005 RID: 5
		// (add) Token: 0x0600008F RID: 143 RVA: 0x000084E4 File Offset: 0x000066E4
		// (remove) Token: 0x06000090 RID: 144 RVA: 0x0000851C File Offset: 0x0000671C
		public event EventHandler<CreateConnectionAsyncCompletedEventArgs> CreateConnectionAsyncCompleted
		{
			[CompilerGenerated]
			add
			{
				EventHandler<CreateConnectionAsyncCompletedEventArgs> eventHandler = this.eventHandler_0;
				EventHandler<CreateConnectionAsyncCompletedEventArgs> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<CreateConnectionAsyncCompletedEventArgs> value2 = (EventHandler<CreateConnectionAsyncCompletedEventArgs>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<CreateConnectionAsyncCompletedEventArgs>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			[CompilerGenerated]
			remove
			{
				EventHandler<CreateConnectionAsyncCompletedEventArgs> eventHandler = this.eventHandler_0;
				EventHandler<CreateConnectionAsyncCompletedEventArgs> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<CreateConnectionAsyncCompletedEventArgs> value2 = (EventHandler<CreateConnectionAsyncCompletedEventArgs>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<CreateConnectionAsyncCompletedEventArgs>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000091 RID: 145 RVA: 0x00008554 File Offset: 0x00006754
		public void CreateConnectionAsync(string destinationHost, int destinationPort)
		{
			if (this.backgroundWorker_0 != null && this.backgroundWorker_0.IsBusy)
			{
				throw new InvalidOperationException("The Socks4 object is already busy executing another asynchronous operation.  You can only execute one asychronous method at a time.");
			}
			this.method_7();
			this.backgroundWorker_0.WorkerSupportsCancellation = true;
			this.backgroundWorker_0.DoWork += this.backgroundWorker_0_DoWork;
			this.backgroundWorker_0.RunWorkerCompleted += this.backgroundWorker_0_RunWorkerCompleted;
			object[] argument = new object[]
			{
				destinationHost,
				destinationPort
			};
			this.backgroundWorker_0.RunWorkerAsync(argument);
		}

		// Token: 0x06000092 RID: 146 RVA: 0x000085E4 File Offset: 0x000067E4
		private void backgroundWorker_0_DoWork(object sender, DoWorkEventArgs e)
		{
			try
			{
				object[] array = (object[])e.Argument;
				e.Result = this.CreateConnection((string)array[0], (int)array[1]);
			}
			catch (Exception ex)
			{
				this.exception_0 = ex;
			}
		}

		// Token: 0x06000093 RID: 147 RVA: 0x00004C8E File Offset: 0x00002E8E
		private void backgroundWorker_0_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			if (this.eventHandler_0 != null)
			{
				this.eventHandler_0(this, new CreateConnectionAsyncCompletedEventArgs(this.exception_0, this.bool_0, (TcpClient)e.Result));
			}
		}

		// Token: 0x04000022 RID: 34
		private string string_0;

		// Token: 0x04000023 RID: 35
		private int int_0;

		// Token: 0x04000024 RID: 36
		private string string_1;

		// Token: 0x04000025 RID: 37
		private string string_2;

		// Token: 0x04000026 RID: 38
		private Socks5ProxyClient.Enum1 enum1_0;

		// Token: 0x04000027 RID: 39
		private TcpClient tcpClient_0;

		// Token: 0x04000028 RID: 40
		private TcpClient tcpClient_1;

		// Token: 0x04000029 RID: 41
		private BackgroundWorker backgroundWorker_0;

		// Token: 0x0400002A RID: 42
		private Exception exception_0;

		// Token: 0x0400002B RID: 43
		private bool bool_0;

		// Token: 0x0400002C RID: 44
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private EventHandler<CreateConnectionAsyncCompletedEventArgs> eventHandler_0;

		// Token: 0x02000013 RID: 19
		private enum Enum1
		{

		}
	}
}
