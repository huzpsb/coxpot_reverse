﻿using System;
using System.Net.Sockets;

namespace Starksoft.Net.Proxy
{
	// Token: 0x0200000F RID: 15
	public class ProxyClientFactory
	{
		// Token: 0x06000046 RID: 70 RVA: 0x000072A0 File Offset: 0x000054A0
		public IProxyClient CreateProxyClient(ProxyType type)
		{
			if (type == ProxyType.None)
			{
				throw new ArgumentOutOfRangeException("type");
			}
			IProxyClient result;
			switch (type)
			{
			case ProxyType.Http:
				result = new HttpProxyClient();
				break;
			case ProxyType.Socks4:
				result = new Socks4ProxyClient();
				break;
			case ProxyType.Socks4a:
				result = new GClass0();
				break;
			case ProxyType.Socks5:
				result = new Socks5ProxyClient();
				break;
			default:
				throw new ProxyException(string.Format("Unknown proxy type {0}.", type.ToString()));
			}
			return result;
		}

		// Token: 0x06000047 RID: 71 RVA: 0x00007318 File Offset: 0x00005518
		public IProxyClient CreateProxyClient(ProxyType type, TcpClient tcpClient)
		{
			if (type == ProxyType.None)
			{
				throw new ArgumentOutOfRangeException("type");
			}
			IProxyClient result;
			switch (type)
			{
			case ProxyType.Http:
				result = new HttpProxyClient(tcpClient);
				break;
			case ProxyType.Socks4:
				result = new Socks4ProxyClient(tcpClient);
				break;
			case ProxyType.Socks4a:
				result = new GClass0(tcpClient);
				break;
			case ProxyType.Socks5:
				result = new Socks5ProxyClient(tcpClient);
				break;
			default:
				throw new ProxyException(string.Format("Unknown proxy type {0}.", type.ToString()));
			}
			return result;
		}

		// Token: 0x06000048 RID: 72 RVA: 0x00007394 File Offset: 0x00005594
		public IProxyClient CreateProxyClient(ProxyType type, string proxyHost, int proxyPort)
		{
			if (type == ProxyType.None)
			{
				throw new ArgumentOutOfRangeException("type");
			}
			IProxyClient result;
			switch (type)
			{
			case ProxyType.Http:
				result = new HttpProxyClient(proxyHost, proxyPort);
				break;
			case ProxyType.Socks4:
				result = new Socks4ProxyClient(proxyHost, proxyPort);
				break;
			case ProxyType.Socks4a:
				result = new GClass0(proxyHost, proxyPort);
				break;
			case ProxyType.Socks5:
				result = new Socks5ProxyClient(proxyHost, proxyPort);
				break;
			default:
				throw new ProxyException(string.Format("Unknown proxy type {0}.", type.ToString()));
			}
			return result;
		}

		// Token: 0x06000049 RID: 73 RVA: 0x00007414 File Offset: 0x00005614
		public IProxyClient CreateProxyClient(ProxyType type, string proxyHost, int proxyPort, string proxyUsername, string proxyPassword)
		{
			if (type == ProxyType.None)
			{
				throw new ArgumentOutOfRangeException("type");
			}
			IProxyClient result;
			switch (type)
			{
			case ProxyType.Http:
				result = new HttpProxyClient(proxyHost, proxyPort, proxyUsername, proxyPassword);
				break;
			case ProxyType.Socks4:
				result = new Socks4ProxyClient(proxyHost, proxyPort, proxyUsername);
				break;
			case ProxyType.Socks4a:
				result = new GClass0(proxyHost, proxyPort, proxyUsername);
				break;
			case ProxyType.Socks5:
				result = new Socks5ProxyClient(proxyHost, proxyPort, proxyUsername, proxyPassword);
				break;
			default:
				throw new ProxyException(string.Format("Unknown proxy type {0}.", type.ToString()));
			}
			return result;
		}

		// Token: 0x0600004A RID: 74 RVA: 0x000074A0 File Offset: 0x000056A0
		public IProxyClient CreateProxyClient(ProxyType type, TcpClient tcpClient, string proxyHost, int proxyPort, string proxyUsername, string proxyPassword)
		{
			IProxyClient proxyClient = this.CreateProxyClient(type, proxyHost, proxyPort, proxyUsername, proxyPassword);
			proxyClient.TcpClient = tcpClient;
			return proxyClient;
		}

		// Token: 0x0600004B RID: 75 RVA: 0x0000480C File Offset: 0x00002A0C
		public ProxyClientFactory()
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
		}
	}
}
