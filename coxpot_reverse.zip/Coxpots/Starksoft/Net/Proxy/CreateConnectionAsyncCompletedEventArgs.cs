﻿using System;
using System.ComponentModel;
using System.Net.Sockets;

namespace Starksoft.Net.Proxy
{
	// Token: 0x02000009 RID: 9
	public class CreateConnectionAsyncCompletedEventArgs : AsyncCompletedEventArgs
	{
		// Token: 0x06000019 RID: 25 RVA: 0x00004831 File Offset: 0x00002A31
		public CreateConnectionAsyncCompletedEventArgs(Exception error, bool cancelled, TcpClient proxyConnection)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor(error, cancelled, null);
			this.tcpClient_0 = proxyConnection;
		}

		// Token: 0x17000001 RID: 1
		// (get) Token: 0x0600001A RID: 26 RVA: 0x00006B78 File Offset: 0x00004D78
		public TcpClient ProxyConnection
		{
			get
			{
				return this.tcpClient_0;
			}
		}

		// Token: 0x04000005 RID: 5
		private TcpClient tcpClient_0;
	}
}
