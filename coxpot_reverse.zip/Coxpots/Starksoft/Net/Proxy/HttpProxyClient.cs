﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;

namespace Starksoft.Net.Proxy
{
	// Token: 0x0200000B RID: 11
	public class HttpProxyClient : IProxyClient
	{
		// Token: 0x0600001F RID: 31 RVA: 0x0000480C File Offset: 0x00002A0C
		public HttpProxyClient()
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
		}

		// Token: 0x06000020 RID: 32 RVA: 0x00004881 File Offset: 0x00002A81
		public HttpProxyClient(TcpClient tcpClient)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			if (tcpClient == null)
			{
				throw new ArgumentNullException("tcpClient");
			}
			this.tcpClient_1 = tcpClient;
		}

		// Token: 0x06000021 RID: 33 RVA: 0x000048A6 File Offset: 0x00002AA6
		public HttpProxyClient(string proxyHost)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			if (string.IsNullOrEmpty(proxyHost))
			{
				throw new ArgumentNullException("proxyHost");
			}
			this.string_0 = proxyHost;
			this.int_0 = 8080;
		}

		// Token: 0x06000022 RID: 34 RVA: 0x00006B90 File Offset: 0x00004D90
		public HttpProxyClient(string proxyHost, int proxyPort, string proxyUsername, string proxyPassword)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			if (string.IsNullOrEmpty(proxyHost))
			{
				throw new ArgumentNullException("proxyHost");
			}
			if (string.IsNullOrEmpty(proxyUsername))
			{
				throw new ArgumentNullException("proxyUsername");
			}
			if (proxyPassword == null)
			{
				throw new ArgumentNullException("proxyPassword");
			}
			if (proxyPort <= 0 || proxyPort > 65535)
			{
				throw new ArgumentOutOfRangeException("proxyPort", "port must be greater than zero and less than 65535");
			}
			this.string_0 = proxyHost;
			this.int_0 = proxyPort;
			this.string_1 = proxyUsername;
			this.string_2 = proxyPassword;
		}

		// Token: 0x06000023 RID: 35 RVA: 0x00006C20 File Offset: 0x00004E20
		public HttpProxyClient(string proxyHost, int proxyPort)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			if (string.IsNullOrEmpty(proxyHost))
			{
				throw new ArgumentNullException("proxyHost");
			}
			if (proxyPort <= 0 || proxyPort > 65535)
			{
				throw new ArgumentOutOfRangeException("proxyPort", "port must be greater than zero and less than 65535");
			}
			this.string_0 = proxyHost;
			this.int_0 = proxyPort;
		}

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x06000024 RID: 36 RVA: 0x00006C7C File Offset: 0x00004E7C
		// (set) Token: 0x06000025 RID: 37 RVA: 0x000048D8 File Offset: 0x00002AD8
		public string ProxyHost
		{
			get
			{
				return this.string_0;
			}
			set
			{
				this.string_0 = value;
			}
		}

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x06000026 RID: 38 RVA: 0x00006C94 File Offset: 0x00004E94
		// (set) Token: 0x06000027 RID: 39 RVA: 0x000048E1 File Offset: 0x00002AE1
		public int ProxyPort
		{
			get
			{
				return this.int_0;
			}
			set
			{
				this.int_0 = value;
			}
		}

		// Token: 0x17000004 RID: 4
		// (get) Token: 0x06000028 RID: 40 RVA: 0x00006CAC File Offset: 0x00004EAC
		public string ProxyName
		{
			get
			{
				return "HTTP";
			}
		}

		// Token: 0x17000005 RID: 5
		// (get) Token: 0x06000029 RID: 41 RVA: 0x00006CC0 File Offset: 0x00004EC0
		// (set) Token: 0x0600002A RID: 42 RVA: 0x000048EA File Offset: 0x00002AEA
		public TcpClient TcpClient
		{
			get
			{
				return this.tcpClient_1;
			}
			set
			{
				this.tcpClient_1 = value;
			}
		}

		// Token: 0x0600002B RID: 43 RVA: 0x00006CD8 File Offset: 0x00004ED8
		public TcpClient CreateConnection(string destinationHost, int destinationPort)
		{
			TcpClient result;
			try
			{
				if (this.tcpClient_1 == null)
				{
					if (string.IsNullOrEmpty(this.string_0))
					{
						throw new ProxyException("ProxyHost property must contain a value.");
					}
					if (this.int_0 <= 0 || this.int_0 > 65535)
					{
						throw new ProxyException("ProxyPort value must be greater than zero and less than 65535");
					}
					this.tcpClient_0 = new TcpClient();
					this.tcpClient_0.Connect(this.string_0, this.int_0);
				}
				else
				{
					this.tcpClient_0 = this.tcpClient_1;
				}
				this.method_0(destinationHost, destinationPort);
				TcpClient tcpClient = this.tcpClient_0;
				this.tcpClient_0 = null;
				result = tcpClient;
			}
			catch (SocketException innerException)
			{
				throw new ProxyException(string.Format(CultureInfo.InvariantCulture, "Connection to proxy host {0} on port {1} failed.", new object[]
				{
					Class1.smethod_0(this.tcpClient_0),
					Class1.smethod_1(this.tcpClient_0)
				}), innerException);
			}
			return result;
		}

		// Token: 0x0600002C RID: 44 RVA: 0x00006DC4 File Offset: 0x00004FC4
		private void method_0(string string_4, int int_1)
		{
			NetworkStream stream = this.tcpClient_0.GetStream();
			string s = this.method_1(string_4, int_1);
			byte[] bytes = Encoding.ASCII.GetBytes(s);
			stream.Write(bytes, 0, bytes.Length);
			this.method_3(stream);
			byte[] array = new byte[this.tcpClient_0.ReceiveBufferSize];
			StringBuilder stringBuilder = new StringBuilder();
			long num = 0L;
			do
			{
				int num2 = stream.Read(array, 0, this.tcpClient_0.ReceiveBufferSize);
				num += (long)num2;
				stringBuilder.Append(Encoding.UTF8.GetString(array, 0, num2));
			}
			while (stream.DataAvailable);
			this.method_4(stringBuilder.ToString());
			if (this.enum0_0 != (HttpProxyClient.Enum0)200)
			{
				this.method_2(string_4, int_1);
			}
		}

		// Token: 0x0600002D RID: 45 RVA: 0x00006E8C File Offset: 0x0000508C
		private string method_1(string string_4, int int_1)
		{
			string result;
			if (!string.IsNullOrEmpty(this.string_1))
			{
				string text = Convert.ToBase64String(Encoding.ASCII.GetBytes(string.Format("{0}:{1}", this.string_1, this.string_2)));
				result = string.Format(CultureInfo.InvariantCulture, "CONNECT {0}:{1} HTTP/1.0\r\nHOST {0}:{1}\r\nProxy-Authorization: Basic {2}\r\n\r\n", new object[]
				{
					string_4,
					int_1.ToString(CultureInfo.InvariantCulture),
					text
				});
			}
			else
			{
				result = string.Format(CultureInfo.InvariantCulture, "CONNECT {0}:{1} HTTP/1.0\r\nHOST {0}:{1}\r\n\r\n\r\n", new object[]
				{
					string_4,
					int_1.ToString(CultureInfo.InvariantCulture)
				});
			}
			return result;
		}

		// Token: 0x0600002E RID: 46 RVA: 0x00006F2C File Offset: 0x0000512C
		private void method_2(string string_4, int int_1)
		{
			HttpProxyClient.Enum0 @enum = this.enum0_0;
			HttpProxyClient.Enum0 enum2 = @enum;
			string message;
			if (enum2 != (HttpProxyClient.Enum0)0)
			{
				if (enum2 != (HttpProxyClient.Enum0)502)
				{
					IFormatProvider invariantCulture = CultureInfo.InvariantCulture;
					string format = "Proxy destination {0} on port {1} responded with a {2} code - {3}";
					object[] array = new object[4];
					array[0] = Class1.smethod_0(this.tcpClient_0);
					array[1] = Class1.smethod_1(this.tcpClient_0);
					int num = 2;
					int num2 = (int)this.enum0_0;
					array[num] = num2.ToString(CultureInfo.InvariantCulture);
					array[3] = this.string_3;
					message = string.Format(invariantCulture, format, array);
				}
				else
				{
					message = string.Format(CultureInfo.InvariantCulture, "Proxy destination {0} on port {1} responded with a 502 code - Bad Gateway.  If you are connecting to a Microsoft ISA destination please refer to knowledge based article Q283284 for more information.  Server response: {2}", new object[]
					{
						Class1.smethod_0(this.tcpClient_0),
						Class1.smethod_1(this.tcpClient_0),
						this.string_3
					});
				}
			}
			else
			{
				message = string.Format(CultureInfo.InvariantCulture, "Proxy destination {0} on port {1} failed to return a recognized HTTP response code.  Server response: {2}", new object[]
				{
					Class1.smethod_0(this.tcpClient_0),
					Class1.smethod_1(this.tcpClient_0),
					this.string_3
				});
			}
			throw new ProxyException(message);
		}

		// Token: 0x0600002F RID: 47 RVA: 0x00007024 File Offset: 0x00005224
		private void method_3(NetworkStream networkStream_0)
		{
			int num = 0;
			while (!networkStream_0.DataAvailable)
			{
				Thread.Sleep(50);
				num += 50;
				if (num > 15000)
				{
					throw new ProxyException(string.Format("A timeout while waiting for the proxy server at {0} on port {1} to respond.", Class1.smethod_0(this.tcpClient_0), Class1.smethod_1(this.tcpClient_0)));
				}
			}
		}

		// Token: 0x06000030 RID: 48 RVA: 0x00007080 File Offset: 0x00005280
		private void method_4(string string_4)
		{
			string[] array = string_4.Replace('\n', ' ').Split(new char[]
			{
				'\r'
			});
			this.method_5(array[0]);
		}

		// Token: 0x06000031 RID: 49 RVA: 0x000070B4 File Offset: 0x000052B4
		private void method_5(string string_4)
		{
			if (string_4.IndexOf("HTTP") == -1)
			{
				throw new ProxyException(string.Format("No HTTP response received from proxy destination.  Server response: {0}.", string_4));
			}
			int num = string_4.IndexOf(" ") + 1;
			int num2 = string_4.IndexOf(" ", num);
			string s = string_4.Substring(num, num2 - num);
			int num3 = 0;
			if (!int.TryParse(s, out num3))
			{
				throw new ProxyException(string.Format("An invalid response code was received from proxy destination.  Server response: {0}.", string_4));
			}
			this.enum0_0 = (HttpProxyClient.Enum0)num3;
			this.string_3 = string_4.Substring(num2 + 1).Trim();
		}

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x06000032 RID: 50 RVA: 0x000048F3 File Offset: 0x00002AF3
		public bool IsBusy
		{
			get
			{
				return this.backgroundWorker_0 != null && this.backgroundWorker_0.IsBusy;
			}
		}

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x06000033 RID: 51 RVA: 0x0000490B File Offset: 0x00002B0B
		public bool IsAsyncCancelled
		{
			get
			{
				return this.bool_0;
			}
		}

		// Token: 0x06000034 RID: 52 RVA: 0x00004913 File Offset: 0x00002B13
		public void CancelAsync()
		{
			if (this.backgroundWorker_0 != null && !this.backgroundWorker_0.CancellationPending && this.backgroundWorker_0.IsBusy)
			{
				this.bool_0 = true;
				this.backgroundWorker_0.CancelAsync();
			}
		}

		// Token: 0x06000035 RID: 53 RVA: 0x0000494C File Offset: 0x00002B4C
		private void method_6()
		{
			if (this.backgroundWorker_0 != null)
			{
				this.backgroundWorker_0.Dispose();
			}
			this.exception_0 = null;
			this.backgroundWorker_0 = null;
			this.bool_0 = false;
			this.backgroundWorker_0 = new BackgroundWorker();
		}

		// Token: 0x14000002 RID: 2
		// (add) Token: 0x06000036 RID: 54 RVA: 0x0000714C File Offset: 0x0000534C
		// (remove) Token: 0x06000037 RID: 55 RVA: 0x00007184 File Offset: 0x00005384
		public event EventHandler<CreateConnectionAsyncCompletedEventArgs> CreateConnectionAsyncCompleted
		{
			[CompilerGenerated]
			add
			{
				EventHandler<CreateConnectionAsyncCompletedEventArgs> eventHandler = this.eventHandler_0;
				EventHandler<CreateConnectionAsyncCompletedEventArgs> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<CreateConnectionAsyncCompletedEventArgs> value2 = (EventHandler<CreateConnectionAsyncCompletedEventArgs>)Delegate.Combine(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<CreateConnectionAsyncCompletedEventArgs>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
			[CompilerGenerated]
			remove
			{
				EventHandler<CreateConnectionAsyncCompletedEventArgs> eventHandler = this.eventHandler_0;
				EventHandler<CreateConnectionAsyncCompletedEventArgs> eventHandler2;
				do
				{
					eventHandler2 = eventHandler;
					EventHandler<CreateConnectionAsyncCompletedEventArgs> value2 = (EventHandler<CreateConnectionAsyncCompletedEventArgs>)Delegate.Remove(eventHandler2, value);
					eventHandler = Interlocked.CompareExchange<EventHandler<CreateConnectionAsyncCompletedEventArgs>>(ref this.eventHandler_0, value2, eventHandler2);
				}
				while (eventHandler != eventHandler2);
			}
		}

		// Token: 0x06000038 RID: 56 RVA: 0x000071BC File Offset: 0x000053BC
		public void CreateConnectionAsync(string destinationHost, int destinationPort)
		{
			if (this.backgroundWorker_0 != null && this.backgroundWorker_0.IsBusy)
			{
				throw new InvalidOperationException("The HttpProxy object is already busy executing another asynchronous operation.  You can only execute one asychronous method at a time.");
			}
			this.method_6();
			this.backgroundWorker_0.WorkerSupportsCancellation = true;
			this.backgroundWorker_0.DoWork += this.backgroundWorker_0_DoWork;
			this.backgroundWorker_0.RunWorkerCompleted += this.backgroundWorker_0_RunWorkerCompleted;
			object[] argument = new object[]
			{
				destinationHost,
				destinationPort
			};
			this.backgroundWorker_0.RunWorkerAsync(argument);
		}

		// Token: 0x06000039 RID: 57 RVA: 0x0000724C File Offset: 0x0000544C
		private void backgroundWorker_0_DoWork(object sender, DoWorkEventArgs e)
		{
			try
			{
				object[] array = (object[])e.Argument;
				e.Result = this.CreateConnection((string)array[0], (int)array[1]);
			}
			catch (Exception ex)
			{
				this.exception_0 = ex;
			}
		}

		// Token: 0x0600003A RID: 58 RVA: 0x00004984 File Offset: 0x00002B84
		private void backgroundWorker_0_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
		{
			if (this.eventHandler_0 != null)
			{
				this.eventHandler_0(this, new CreateConnectionAsyncCompletedEventArgs(this.exception_0, this.bool_0, (TcpClient)e.Result));
			}
		}

		// Token: 0x04000006 RID: 6
		private string string_0;

		// Token: 0x04000007 RID: 7
		private int int_0;

		// Token: 0x04000008 RID: 8
		private string string_1;

		// Token: 0x04000009 RID: 9
		private string string_2;

		// Token: 0x0400000A RID: 10
		private HttpProxyClient.Enum0 enum0_0;

		// Token: 0x0400000B RID: 11
		private string string_3;

		// Token: 0x0400000C RID: 12
		private TcpClient tcpClient_0;

		// Token: 0x0400000D RID: 13
		private TcpClient tcpClient_1;

		// Token: 0x0400000E RID: 14
		private BackgroundWorker backgroundWorker_0;

		// Token: 0x0400000F RID: 15
		private Exception exception_0;

		// Token: 0x04000010 RID: 16
		private bool bool_0;

		// Token: 0x04000011 RID: 17
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private EventHandler<CreateConnectionAsyncCompletedEventArgs> eventHandler_0;

		// Token: 0x0200000C RID: 12
		private enum Enum0
		{

		}
	}
}
