﻿using System;
using System.Net.Sockets;
using System.Text;

namespace Starksoft.Net.Proxy
{
	// Token: 0x02000010 RID: 16
	public class GClass0 : Socks4ProxyClient
	{
		// Token: 0x0600004C RID: 76 RVA: 0x000049B9 File Offset: 0x00002BB9
		public GClass0()
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
		}

		// Token: 0x0600004D RID: 77 RVA: 0x000049C6 File Offset: 0x00002BC6
		public GClass0(TcpClient tcpClient)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor(tcpClient);
		}

		// Token: 0x0600004E RID: 78 RVA: 0x000049D4 File Offset: 0x00002BD4
		public GClass0(string proxyHost, string proxyUserId)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor(proxyHost, proxyUserId);
		}

		// Token: 0x0600004F RID: 79 RVA: 0x000049E3 File Offset: 0x00002BE3
		public GClass0(string proxyHost, int proxyPort, string proxyUserId)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor(proxyHost, proxyPort, proxyUserId);
		}

		// Token: 0x06000050 RID: 80 RVA: 0x000049F3 File Offset: 0x00002BF3
		public GClass0(string proxyHost)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor(proxyHost);
		}

		// Token: 0x06000051 RID: 81 RVA: 0x00004A01 File Offset: 0x00002C01
		public GClass0(string proxyHost, int proxyPort)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor(proxyHost, proxyPort);
		}

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x06000052 RID: 82 RVA: 0x000074C8 File Offset: 0x000056C8
		public override string ProxyName
		{
			get
			{
				return "SOCKS4a";
			}
		}

		// Token: 0x06000053 RID: 83 RVA: 0x000074DC File Offset: 0x000056DC
		internal override void vmethod_0(NetworkStream proxy, byte command, string destinationHost, int destinationPort, string userId)
		{
			if (userId == null)
			{
				userId = "";
			}
			byte[] array = new byte[]
			{
				0,
				0,
				0,
				1
			};
			byte[] array2 = base.method_0(destinationPort);
			byte[] bytes = Encoding.ASCII.GetBytes(userId);
			byte[] bytes2 = Encoding.ASCII.GetBytes(destinationHost);
			byte[] array3 = new byte[10 + bytes.Length + bytes2.Length];
			array3[0] = 4;
			array3[1] = command;
			array2.CopyTo(array3, 2);
			array.CopyTo(array3, 4);
			bytes.CopyTo(array3, 8);
			array3[8 + bytes.Length] = 0;
			bytes2.CopyTo(array3, 9 + bytes.Length);
			array3[9 + bytes.Length + bytes2.Length] = 0;
			proxy.Write(array3, 0, array3.Length);
			base.method_2(proxy);
			byte[] array4 = new byte[8];
			proxy.Read(array4, 0, 8);
			if (array4[1] != 90)
			{
				base.method_1(array4, destinationHost, destinationPort);
			}
		}
	}
}
