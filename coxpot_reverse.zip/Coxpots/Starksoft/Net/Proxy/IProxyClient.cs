﻿using System;
using System.Net.Sockets;

namespace Starksoft.Net.Proxy
{
	// Token: 0x0200000D RID: 13
	public interface IProxyClient
	{
		// Token: 0x14000003 RID: 3
		// (add) Token: 0x0600003B RID: 59
		// (remove) Token: 0x0600003C RID: 60
		event EventHandler<CreateConnectionAsyncCompletedEventArgs> CreateConnectionAsyncCompleted;

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x0600003D RID: 61
		// (set) Token: 0x0600003E RID: 62
		string ProxyHost { get; set; }

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x0600003F RID: 63
		// (set) Token: 0x06000040 RID: 64
		int ProxyPort { get; set; }

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x06000041 RID: 65
		string ProxyName { get; }

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x06000042 RID: 66
		// (set) Token: 0x06000043 RID: 67
		TcpClient TcpClient { get; set; }

		// Token: 0x06000044 RID: 68
		TcpClient CreateConnection(string destinationHost, int destinationPort);

		// Token: 0x06000045 RID: 69
		void CreateConnectionAsync(string destinationHost, int destinationPort);
	}
}
