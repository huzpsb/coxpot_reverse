﻿using System;

namespace Starksoft.Net.Proxy
{
	// Token: 0x0200000E RID: 14
	public enum ProxyType
	{
		// Token: 0x04000014 RID: 20
		None,
		// Token: 0x04000015 RID: 21
		Http,
		// Token: 0x04000016 RID: 22
		Socks4,
		// Token: 0x04000017 RID: 23
		Socks4a,
		// Token: 0x04000018 RID: 24
		Socks5
	}
}
