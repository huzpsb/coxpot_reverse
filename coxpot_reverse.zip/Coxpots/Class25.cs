﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using Coxpots.Protocol.Client;
using Coxpots.Protocol.Client.Handler;
using Coxpots.Protocol.Server.Forge;

// Token: 0x020000A3 RID: 163
internal class Class25
{
	// Token: 0x06000340 RID: 832 RVA: 0x000185E4 File Offset: 0x000167E4
	public Class25(TcpClient tcpClient_1, int int_4, IMinecraftCom iminecraftCom_1, ForgeInfo forgeInfo_1)
	{
		Class35.NkAVmDjz8ZWXG();
		this.enum10_0 = (Enum10)0;
		this.int_0 = 0;
		this.bool_0 = true;
		this.bool_1 = true;
		this.int_2 = -1;
		this.int_3 = 0;
		base..ctor();
		this.tcpClient_0 = tcpClient_1;
		this.int_1 = int_4;
		this.forgeInfo_0 = forgeInfo_1;
		this.iminecraftCom_0 = iminecraftCom_1;
	}

	// Token: 0x06000341 RID: 833 RVA: 0x00018644 File Offset: 0x00016844
	private void method_0(byte[] byte_0, int int_4, int int_5, SocketFlags socketFlags_0)
	{
		for (int i = 0; i < int_5; i += this.tcpClient_0.Client.Receive(byte_0, int_4 + i, int_5 - i, socketFlags_0))
		{
		}
	}

	// Token: 0x06000342 RID: 834 RVA: 0x00018678 File Offset: 0x00016878
	private bool method_1()
	{
		int num = -1;
		List<byte> list_ = new List<byte>();
		while (this.enum10_0 != (Enum10)6)
		{
			this.method_5(ref num, list_);
			if (num == 64)
			{
				Class16.smethod_0("[FML] Connection Lost.", null);
				return false;
			}
			this.method_2(num, list_);
		}
		return true;
	}

	// Token: 0x06000343 RID: 835 RVA: 0x000186C8 File Offset: 0x000168C8
	private bool method_2(int int_4, List<byte> list_0)
	{
		if (this.bool_0)
		{
			if (int_4 != 3)
			{
				return false;
			}
			if (this.int_1 >= 47)
			{
				this.int_0 = this.method_11(list_0);
			}
		}
		switch (this.method_3(int_4))
		{
		case (Class25.Enum13)0:
			this.method_24((Class25.Enum12)0, list_0);
			this.iminecraftCom_0.OnKeepAlive();
			goto IL_59F;
		case (Class25.Enum13)1:
			this.iminecraftCom_0.OnGameJoin();
			this.method_15(list_0);
			this.method_12(list_0);
			if (this.int_1 >= 108)
			{
				this.int_2 = this.method_15(list_0);
			}
			else
			{
				this.int_2 = (int)((sbyte)this.method_12(list_0));
			}
			this.method_12(list_0);
			this.method_12(list_0);
			this.method_13(list_0);
			if (this.int_1 >= 47)
			{
				this.method_19(list_0);
				goto IL_59F;
			}
			goto IL_59F;
		case (Class25.Enum13)2:
			goto IL_59F;
		case (Class25.Enum13)3:
			this.int_2 = this.method_15(list_0);
			this.method_12(list_0);
			this.method_12(list_0);
			this.method_13(list_0);
			goto IL_59F;
		case (Class25.Enum13)4:
			if (this.int_1 >= 107)
			{
				int int_5 = this.method_11(list_0);
				this.method_24((Class25.Enum12)9, this.method_9(int_5));
				goto IL_59F;
			}
			goto IL_59F;
		case (Class25.Enum13)11:
			if (this.int_1 >= 393)
			{
				this.int_3 = this.method_11(list_0);
				this.method_11(list_0);
				this.method_11(list_0);
			}
			this.method_11(list_0);
			goto IL_59F;
		case (Class25.Enum13)12:
		{
			string a = this.method_13(list_0);
			if (this.int_1 < 47)
			{
				if (this.forgeInfo_0 == null)
				{
					this.method_18(list_0);
				}
				else
				{
					this.method_16(list_0);
				}
			}
			if (this.forgeInfo_0 != null && this.enum10_0 != (Enum10)6 && a == "FML|HS")
			{
				Enum11 @enum = (Enum11)this.method_12(list_0);
				if (@enum == (Enum11)254)
				{
					this.enum10_0 = (Enum10)0;
					return true;
				}
				switch (this.enum10_0)
				{
				case (Enum10)0:
				{
					if (@enum > (Enum11)0)
					{
						return false;
					}
					string[] value = new string[]
					{
						"FML|HS",
						"FML",
						"FML|MP",
						"FML",
						"FORGE"
					};
					this.method_30("REGISTER", Encoding.UTF8.GetBytes(string.Join("\0", value)));
					byte b = this.method_12(list_0);
					if (b >= 1)
					{
						this.int_2 = this.method_15(list_0);
					}
					this.method_26((Enum11)1, new byte[]
					{
						b
					});
					byte[][] array = new byte[this.forgeInfo_0.Mods.Count][];
					for (int i = 0; i < this.forgeInfo_0.Mods.Count; i++)
					{
						ForgeInfo.ForgeMod forgeMod = this.forgeInfo_0.Mods[i];
						array[i] = this.method_8(new byte[][]
						{
							this.method_10(forgeMod.ModID),
							this.method_10(forgeMod.Version)
						});
					}
					this.method_26((Enum11)2, this.method_8(new byte[][]
					{
						this.method_9(this.forgeInfo_0.Mods.Count),
						this.method_8(array)
					}));
					this.enum10_0 = (Enum10)2;
					return true;
				}
				case (Enum10)2:
					if (@enum != (Enum11)2)
					{
						return false;
					}
					Thread.Sleep(2000);
					this.method_26((Enum11)255, new byte[]
					{
						2
					});
					this.enum10_0 = (Enum10)3;
					return false;
				case (Enum10)3:
					if (@enum != (Enum11)3)
					{
						return false;
					}
					if (this.int_1 < 47)
					{
						this.method_11(list_0);
						this.enum10_0 = (Enum10)4;
					}
					else
					{
						bool flag = this.method_19(list_0);
						this.method_13(list_0);
						this.method_11(list_0);
						if (!flag)
						{
							this.enum10_0 = (Enum10)4;
						}
					}
					return false;
				case (Enum10)4:
					if (@enum != (Enum11)255)
					{
						return false;
					}
					this.method_26((Enum11)255, new byte[]
					{
						4
					});
					this.enum10_0 = (Enum10)5;
					return true;
				case (Enum10)5:
					this.method_26((Enum11)255, new byte[]
					{
						5
					});
					this.enum10_0 = (Enum10)6;
					return true;
				}
			}
			return false;
		}
		case (Class25.Enum13)13:
			this.iminecraftCom_0.OnConnectionLost(BotUtils.DisconnectReason.InGameKick, this.method_13(list_0));
			return false;
		case (Class25.Enum13)14:
			if (this.int_1 >= 47 && this.int_1 < 107)
			{
				this.int_0 = this.method_11(list_0);
				goto IL_59F;
			}
			goto IL_59F;
		case (Class25.Enum13)15:
		{
			this.method_13(list_0);
			string text = this.method_13(list_0);
			byte[] array2 = new byte[0];
			if (this.int_1 < 210)
			{
				array2 = this.method_8(new byte[][]
				{
					this.method_9(text.Length),
					Encoding.UTF8.GetBytes(text)
				});
			}
			this.method_24((Class25.Enum12)1, this.method_8(new byte[][]
			{
				array2,
				this.method_9(3)
			}));
			this.method_24((Class25.Enum12)1, this.method_8(new byte[][]
			{
				array2,
				this.method_9(0)
			}));
			goto IL_59F;
		}
		}
		return false;
		IL_59F:
		return true;
	}

	// Token: 0x06000344 RID: 836 RVA: 0x00018C78 File Offset: 0x00016E78
	private Class25.Enum13 method_3(int int_4)
	{
		Class25.Enum13 result;
		if (this.int_1 <= 47)
		{
			if (int_4 <= 58)
			{
				if (int_4 <= 38)
				{
					switch (int_4)
					{
					case 0:
						return (Class25.Enum13)0;
					case 1:
						return (Class25.Enum13)1;
					case 2:
						return (Class25.Enum13)2;
					case 3:
					case 4:
					case 5:
					case 6:
						break;
					case 7:
						return (Class25.Enum13)3;
					case 8:
						return (Class25.Enum13)4;
					default:
						switch (int_4)
						{
						case 33:
							return (Class25.Enum13)5;
						case 34:
							return (Class25.Enum13)6;
						case 35:
							return (Class25.Enum13)7;
						case 38:
							return (Class25.Enum13)8;
						}
						break;
					}
				}
				else
				{
					if (int_4 == 56)
					{
						return (Class25.Enum13)10;
					}
					if (int_4 == 58)
					{
						return (Class25.Enum13)11;
					}
				}
			}
			else if (int_4 <= 64)
			{
				if (int_4 == 63)
				{
					return (Class25.Enum13)12;
				}
				if (int_4 == 64)
				{
					return (Class25.Enum13)13;
				}
			}
			else
			{
				if (int_4 == 70)
				{
					return (Class25.Enum13)14;
				}
				if (int_4 == 72)
				{
					return (Class25.Enum13)15;
				}
			}
			result = (Class25.Enum13)16;
		}
		else if (this.int_1 <= 316)
		{
			if (int_4 <= 32)
			{
				switch (int_4)
				{
				case 11:
					return (Class25.Enum13)7;
				case 12:
				case 13:
					break;
				case 14:
					return (Class25.Enum13)11;
				case 15:
					return (Class25.Enum13)2;
				case 16:
					return (Class25.Enum13)6;
				default:
					switch (int_4)
					{
					case 24:
						return (Class25.Enum13)12;
					case 26:
						return (Class25.Enum13)13;
					case 29:
						return (Class25.Enum13)9;
					case 31:
						return (Class25.Enum13)0;
					case 32:
						return (Class25.Enum13)5;
					}
					break;
				}
			}
			else
			{
				if (int_4 == 35)
				{
					return (Class25.Enum13)1;
				}
				switch (int_4)
				{
				case 45:
					return (Class25.Enum13)10;
				case 46:
					return (Class25.Enum13)4;
				case 50:
					return (Class25.Enum13)15;
				case 51:
					return (Class25.Enum13)3;
				}
			}
			result = (Class25.Enum13)16;
		}
		else if (this.int_1 <= 335)
		{
			if (int_4 <= 35)
			{
				switch (int_4)
				{
				case 11:
					return (Class25.Enum13)7;
				case 12:
				case 13:
					break;
				case 14:
					return (Class25.Enum13)11;
				case 15:
					return (Class25.Enum13)2;
				case 16:
					return (Class25.Enum13)6;
				default:
					switch (int_4)
					{
					case 24:
						return (Class25.Enum13)12;
					case 25:
					case 27:
					case 28:
					case 30:
						break;
					case 26:
						return (Class25.Enum13)13;
					case 29:
						return (Class25.Enum13)9;
					case 31:
						return (Class25.Enum13)0;
					case 32:
						return (Class25.Enum13)5;
					default:
						if (int_4 == 35)
						{
							return (Class25.Enum13)1;
						}
						break;
					}
					break;
				}
			}
			else if (int_4 <= 46)
			{
				if (int_4 == 45)
				{
					return (Class25.Enum13)10;
				}
				if (int_4 == 46)
				{
					return (Class25.Enum13)4;
				}
			}
			else
			{
				if (int_4 == 51)
				{
					return (Class25.Enum13)15;
				}
				if (int_4 == 52)
				{
					return (Class25.Enum13)3;
				}
			}
			result = (Class25.Enum13)16;
		}
		else if (this.int_1 <= 340)
		{
			if (int_4 <= 35)
			{
				switch (int_4)
				{
				case 11:
					return (Class25.Enum13)7;
				case 12:
				case 13:
					break;
				case 14:
					return (Class25.Enum13)11;
				case 15:
					return (Class25.Enum13)2;
				case 16:
					return (Class25.Enum13)6;
				default:
					switch (int_4)
					{
					case 24:
						return (Class25.Enum13)12;
					case 25:
					case 27:
					case 28:
					case 30:
						break;
					case 26:
						return (Class25.Enum13)13;
					case 29:
						return (Class25.Enum13)9;
					case 31:
						return (Class25.Enum13)0;
					case 32:
						return (Class25.Enum13)5;
					default:
						if (int_4 == 35)
						{
							return (Class25.Enum13)1;
						}
						break;
					}
					break;
				}
			}
			else if (int_4 <= 47)
			{
				if (int_4 == 46)
				{
					return (Class25.Enum13)10;
				}
				if (int_4 == 47)
				{
					return (Class25.Enum13)4;
				}
			}
			else
			{
				if (int_4 == 52)
				{
					return (Class25.Enum13)15;
				}
				if (int_4 == 53)
				{
					return (Class25.Enum13)3;
				}
			}
			result = (Class25.Enum13)16;
		}
		else if (this.int_1 < 477)
		{
			if (int_4 <= 37)
			{
				if (int_4 <= 25)
				{
					switch (int_4)
					{
					case 11:
						return (Class25.Enum13)7;
					case 12:
					case 13:
						break;
					case 14:
						return (Class25.Enum13)2;
					case 15:
						return (Class25.Enum13)6;
					case 16:
						return (Class25.Enum13)11;
					default:
						if (int_4 == 25)
						{
							return (Class25.Enum13)12;
						}
						break;
					}
				}
				else
				{
					if (int_4 == 27)
					{
						return (Class25.Enum13)13;
					}
					switch (int_4)
					{
					case 31:
						return (Class25.Enum13)9;
					case 33:
						return (Class25.Enum13)0;
					case 34:
						return (Class25.Enum13)5;
					case 37:
						return (Class25.Enum13)1;
					}
				}
			}
			else if (int_4 <= 50)
			{
				if (int_4 == 48)
				{
					return (Class25.Enum13)10;
				}
				if (int_4 == 50)
				{
					return (Class25.Enum13)4;
				}
			}
			else
			{
				if (int_4 == 55)
				{
					return (Class25.Enum13)15;
				}
				if (int_4 == 56)
				{
					return (Class25.Enum13)3;
				}
			}
			result = (Class25.Enum13)16;
		}
		else
		{
			if (int_4 <= 33)
			{
				if (int_4 <= 24)
				{
					switch (int_4)
					{
					case 11:
						return (Class25.Enum13)7;
					case 12:
					case 13:
						break;
					case 14:
						return (Class25.Enum13)2;
					case 15:
						return (Class25.Enum13)6;
					case 16:
						return (Class25.Enum13)11;
					default:
						if (int_4 == 24)
						{
							return (Class25.Enum13)12;
						}
						break;
					}
				}
				else
				{
					if (int_4 == 26)
					{
						return (Class25.Enum13)13;
					}
					switch (int_4)
					{
					case 29:
						return (Class25.Enum13)9;
					case 32:
						return (Class25.Enum13)0;
					case 33:
						return (Class25.Enum13)5;
					}
				}
			}
			else if (int_4 <= 51)
			{
				if (int_4 == 37)
				{
					return (Class25.Enum13)1;
				}
				if (int_4 == 51)
				{
					return (Class25.Enum13)10;
				}
			}
			else
			{
				if (int_4 == 53)
				{
					return (Class25.Enum13)4;
				}
				if (int_4 == 57)
				{
					return (Class25.Enum13)15;
				}
				if (int_4 == 58)
				{
					return (Class25.Enum13)3;
				}
			}
			result = (Class25.Enum13)16;
		}
		return result;
	}

	// Token: 0x06000345 RID: 837 RVA: 0x000192A8 File Offset: 0x000174A8
	private int method_4(Class25.Enum12 enum12_0)
	{
		if (this.int_1 <= 47)
		{
			switch (enum12_0)
			{
			case (Class25.Enum12)0:
				return 0;
			case (Class25.Enum12)1:
				return 25;
			case (Class25.Enum12)2:
				return 1;
			case (Class25.Enum12)3:
				return 22;
			case (Class25.Enum12)4:
				return 21;
			case (Class25.Enum12)5:
				return 23;
			case (Class25.Enum12)6:
				return 20;
			case (Class25.Enum12)7:
				return 4;
			case (Class25.Enum12)8:
				return 6;
			case (Class25.Enum12)9:
				throw new InvalidOperationException("Teleport confirm is not supported in protocol " + this.int_1.ToString());
			}
		}
		else if (this.int_1 <= 316)
		{
			switch (enum12_0)
			{
			case (Class25.Enum12)0:
				return 11;
			case (Class25.Enum12)1:
				return 22;
			case (Class25.Enum12)2:
				return 2;
			case (Class25.Enum12)3:
				return 3;
			case (Class25.Enum12)4:
				return 4;
			case (Class25.Enum12)5:
				return 9;
			case (Class25.Enum12)6:
				return 1;
			case (Class25.Enum12)7:
				return 12;
			case (Class25.Enum12)8:
				return 13;
			case (Class25.Enum12)9:
				return 0;
			}
		}
		else if (this.int_1 <= 335)
		{
			switch (enum12_0)
			{
			case (Class25.Enum12)0:
				return 12;
			case (Class25.Enum12)1:
				return 24;
			case (Class25.Enum12)2:
				return 3;
			case (Class25.Enum12)3:
				return 4;
			case (Class25.Enum12)4:
				return 5;
			case (Class25.Enum12)5:
				return 10;
			case (Class25.Enum12)6:
				return 2;
			case (Class25.Enum12)7:
				return 14;
			case (Class25.Enum12)8:
				return 15;
			case (Class25.Enum12)9:
				return 0;
			}
		}
		else if (this.int_1 <= 340)
		{
			switch (enum12_0)
			{
			case (Class25.Enum12)0:
				return 11;
			case (Class25.Enum12)1:
				return 24;
			case (Class25.Enum12)2:
				return 2;
			case (Class25.Enum12)3:
				return 3;
			case (Class25.Enum12)4:
				return 4;
			case (Class25.Enum12)5:
				return 9;
			case (Class25.Enum12)6:
				return 1;
			case (Class25.Enum12)7:
				return 13;
			case (Class25.Enum12)8:
				return 14;
			case (Class25.Enum12)9:
				return 0;
			}
		}
		else if (this.int_1 < 477)
		{
			switch (enum12_0)
			{
			case (Class25.Enum12)0:
				return 14;
			case (Class25.Enum12)1:
				return 29;
			case (Class25.Enum12)2:
				return 2;
			case (Class25.Enum12)3:
				return 3;
			case (Class25.Enum12)4:
				return 4;
			case (Class25.Enum12)5:
				return 10;
			case (Class25.Enum12)6:
				return 5;
			case (Class25.Enum12)7:
				return 16;
			case (Class25.Enum12)8:
				return 17;
			case (Class25.Enum12)9:
				return 0;
			}
		}
		else
		{
			switch (enum12_0)
			{
			case (Class25.Enum12)0:
				return 15;
			case (Class25.Enum12)1:
				return 31;
			case (Class25.Enum12)2:
				return 3;
			case (Class25.Enum12)3:
				return 4;
			case (Class25.Enum12)4:
				return 5;
			case (Class25.Enum12)5:
				return 11;
			case (Class25.Enum12)6:
				return 6;
			case (Class25.Enum12)7:
				return 17;
			case (Class25.Enum12)8:
				return 18;
			case (Class25.Enum12)9:
				return 0;
			}
		}
		throw new InvalidEnumArgumentException("Unknown PacketOutgoingType (protocol=" + this.int_1.ToString() + ")", (int)enum12_0, typeof(Class25.Enum12));
	}

	// Token: 0x06000346 RID: 838 RVA: 0x00019654 File Offset: 0x00017854
	private void method_5(ref int int_4, List<byte> list_0)
	{
		list_0.Clear();
		int int_5 = this.method_6();
		list_0.AddRange(this.method_7(int_5));
		if (this.int_1 >= 47 && this.int_0 > 0)
		{
			int num = this.method_11(list_0);
			if (num != 0)
			{
				byte[] to_decompress = list_0.ToArray();
				byte[] collection = ZlibUtils.Decompress(to_decompress, num);
				list_0.Clear();
				list_0.AddRange(collection);
			}
		}
		int_4 = this.method_11(list_0);
	}

	// Token: 0x06000347 RID: 839 RVA: 0x000196C8 File Offset: 0x000178C8
	public int method_6()
	{
		int num = 0;
		int num2 = 0;
		byte[] array = new byte[1];
		for (;;)
		{
			this.method_0(array, 0, 1, SocketFlags.None);
			int num3 = (int)array[0];
			num |= (num3 & 127) << num2++ * 7;
			if (num2 > 5)
			{
				break;
			}
			if ((num3 & 128) != 128)
			{
				return num;
			}
		}
		throw new OverflowException("VarInt too big");
	}

	// Token: 0x06000348 RID: 840 RVA: 0x00019730 File Offset: 0x00017930
	public byte[] method_7(int int_4)
	{
		byte[] result;
		if (int_4 > 0)
		{
			byte[] array = new byte[int_4];
			this.method_0(array, 0, int_4, SocketFlags.None);
			result = array;
		}
		else
		{
			result = new byte[0];
		}
		return result;
	}

	// Token: 0x06000349 RID: 841 RVA: 0x00019760 File Offset: 0x00017960
	public byte[] method_8(params byte[][] bytes)
	{
		List<byte> list = new List<byte>();
		foreach (byte collection in bytes)
		{
			list.AddRange(collection);
		}
		return list.ToArray();
	}

	// Token: 0x0600034A RID: 842 RVA: 0x00019798 File Offset: 0x00017998
	public byte[] method_9(int int_4)
	{
		List<byte> list = new List<byte>();
		while ((int_4 & -128) != 0)
		{
			list.Add((byte)((int_4 & 127) | 128));
			int_4 = (int)((uint)int_4 >> 7);
		}
		list.Add((byte)int_4);
		return list.ToArray();
	}

	// Token: 0x0600034B RID: 843 RVA: 0x000197DC File Offset: 0x000179DC
	public byte[] method_10(string string_0)
	{
		byte[] bytes = Encoding.UTF8.GetBytes(string_0);
		return this.method_8(new byte[][]
		{
			this.method_9(bytes.Length),
			bytes
		});
	}

	// Token: 0x0600034C RID: 844 RVA: 0x00019814 File Offset: 0x00017A14
	private int method_11(List<byte> list_0)
	{
		int num = 0;
		int num2 = 0;
		for (;;)
		{
			int num3 = (int)this.method_12(list_0);
			num |= (num3 & 127) << num2++ * 7;
			if (num2 > 5)
			{
				break;
			}
			if ((num3 & 128) != 128)
			{
				return num;
			}
		}
		throw new OverflowException("VarInt too big");
	}

	// Token: 0x0600034D RID: 845 RVA: 0x0001986C File Offset: 0x00017A6C
	private byte method_12(List<byte> list_0)
	{
		byte result = list_0[0];
		list_0.RemoveAt(0);
		return result;
	}

	// Token: 0x0600034E RID: 846 RVA: 0x0001988C File Offset: 0x00017A8C
	public string method_13(List<byte> list_0)
	{
		int num = this.method_11(list_0);
		string result;
		if (num > 0)
		{
			result = Encoding.UTF8.GetString(this.method_14(num, list_0));
		}
		else
		{
			result = "";
		}
		return result;
	}

	// Token: 0x0600034F RID: 847 RVA: 0x000198C4 File Offset: 0x00017AC4
	private byte[] method_14(int int_4, List<byte> list_0)
	{
		byte[] result = list_0.Take(int_4).ToArray<byte>();
		list_0.RemoveRange(0, int_4);
		return result;
	}

	// Token: 0x06000350 RID: 848 RVA: 0x000198EC File Offset: 0x00017AEC
	private int method_15(List<byte> list_0)
	{
		byte[] array = this.method_14(4, list_0);
		Array.Reverse(array);
		return BitConverter.ToInt32(array, 0);
	}

	// Token: 0x06000351 RID: 849 RVA: 0x00019914 File Offset: 0x00017B14
	private int method_16(List<byte> list_0)
	{
		ushort num = this.method_17(list_0);
		byte b = 0;
		if ((num & 32768) > 0)
		{
			num &= 32767;
			b = this.method_12(list_0);
		}
		return (int)(b & byte.MaxValue) << 15 | (int)num;
	}

	// Token: 0x06000352 RID: 850 RVA: 0x00019958 File Offset: 0x00017B58
	private ushort method_17(List<byte> list_0)
	{
		byte[] array = this.method_14(2, list_0);
		Array.Reverse(array);
		return BitConverter.ToUInt16(array, 0);
	}

	// Token: 0x06000353 RID: 851 RVA: 0x00019980 File Offset: 0x00017B80
	private short method_18(List<byte> list_0)
	{
		byte[] array = this.method_14(2, list_0);
		Array.Reverse(array);
		return BitConverter.ToInt16(array, 0);
	}

	// Token: 0x06000354 RID: 852 RVA: 0x00005EA5 File Offset: 0x000040A5
	private bool method_19(List<byte> list_0)
	{
		return this.method_12(list_0) > 0;
	}

	// Token: 0x06000355 RID: 853 RVA: 0x000199A8 File Offset: 0x00017BA8
	public bool method_20()
	{
		bool result;
		if (this.tcpClient_0.Client == null || !this.tcpClient_0.Connected)
		{
			result = false;
		}
		else
		{
			try
			{
				while (this.tcpClient_0.Client.Available > 0)
				{
					int int_ = 0;
					List<byte> list = new List<byte>();
					this.method_5(ref int_, list);
					this.method_2(int_, new List<byte>(list));
				}
			}
			catch (SocketException)
			{
				return false;
			}
			catch (NullReferenceException)
			{
				return false;
			}
			result = true;
		}
		return result;
	}

	// Token: 0x06000356 RID: 854 RVA: 0x00019A3C File Offset: 0x00017C3C
	private void method_21()
	{
		try
		{
			do
			{
				Thread.Sleep(500);
			}
			while (this.bool_1 && this.method_20());
		}
		catch (IOException)
		{
		}
		catch (SocketException)
		{
		}
		catch (ObjectDisposedException)
		{
		}
		this.iminecraftCom_0.OnConnectionLost(BotUtils.DisconnectReason.ConnectionLost, "Connection Close.");
	}

	// Token: 0x06000357 RID: 855 RVA: 0x00005EB1 File Offset: 0x000040B1
	public void method_22(bool bool_2)
	{
		if (bool_2)
		{
			this.thread_0 = new Thread(new ThreadStart(this.method_21));
			this.thread_0.Name = "ProtocolPacketHandler";
			this.thread_0.Start();
		}
		else
		{
			this.method_21();
		}
	}

	// Token: 0x06000358 RID: 856 RVA: 0x00019AB4 File Offset: 0x00017CB4
	public bool method_23(string string_0, int int_4, string string_1)
	{
		byte[] array = this.method_9(this.int_1);
		byte[] bytes = Encoding.UTF8.GetBytes(string_0 + ((this.forgeInfo_0 != null) ? "\0FML\0" : ""));
		byte[] array2 = this.method_9(bytes.Length);
		byte[] bytes2 = BitConverter.GetBytes((ushort)int_4);
		Array.Reverse(bytes2);
		byte[] array3 = this.method_9(2);
		byte[] ienumerable_ = this.method_8(new byte[][]
		{
			array,
			array2,
			bytes,
			bytes2,
			array3
		});
		this.method_25(0, ienumerable_);
		byte[] bytes3 = Encoding.UTF8.GetBytes(string_1);
		byte[] array4 = this.method_9(bytes3.Length);
		byte[] ienumerable_2 = this.method_8(new byte[][]
		{
			array4,
			bytes3
		});
		this.method_25(0, ienumerable_2);
		int num = -1;
		List<byte> list_ = new List<byte>();
		for (;;)
		{
			this.method_5(ref num, list_);
			if (num == 0)
			{
				break;
			}
			if (num == 1)
			{
				goto IL_106;
			}
			if (num == 2)
			{
				goto IL_11F;
			}
			this.method_2(num, list_);
		}
		this.iminecraftCom_0.OnConnectionLost(BotUtils.DisconnectReason.LoginRejected, this.method_13(list_));
		return false;
		IL_106:
		Class16.smethod_0(string_1 + "This Server is in online mode.", "Connection");
		return false;
		IL_11F:
		this.bool_0 = false;
		return this.forgeInfo_0 == null || this.method_1();
	}

	// Token: 0x06000359 RID: 857 RVA: 0x00005EF0 File Offset: 0x000040F0
	private void method_24(Class25.Enum12 enum12_0, IEnumerable<byte> ienumerable_0)
	{
		this.method_25(this.method_4(enum12_0), ienumerable_0);
	}

	// Token: 0x0600035A RID: 858 RVA: 0x00019C04 File Offset: 0x00017E04
	private void method_25(int int_4, IEnumerable<byte> ienumerable_0)
	{
		byte[] array = this.method_8(new byte[][]
		{
			this.method_9(int_4),
			ienumerable_0.ToArray<byte>()
		});
		if (this.int_0 > 0)
		{
			if (array.Length >= this.int_0)
			{
				byte[] array2 = ZlibUtils.Compress(array);
				array = this.method_8(new byte[][]
				{
					this.method_9(array.Length),
					array2
				});
			}
			else
			{
				byte[] array3 = this.method_9(0);
				array = this.method_8(new byte[][]
				{
					array3,
					array
				});
			}
		}
		this.tcpClient_0.Client.Send(this.method_8(new byte[][]
		{
			this.method_9(array.Length),
			array
		}));
	}

	// Token: 0x0600035B RID: 859 RVA: 0x00019CBC File Offset: 0x00017EBC
	private void method_26(Enum11 enum11_0, byte[] byte_0)
	{
		this.method_30("FML|HS", this.method_8(new byte[][]
		{
			new byte[]
			{
				(byte)enum11_0
			},
			byte_0
		}));
	}

	// Token: 0x0600035C RID: 860 RVA: 0x00019CF4 File Offset: 0x00017EF4
	public bool method_27(string string_0)
	{
		bool result;
		if (string.IsNullOrEmpty(string_0))
		{
			result = true;
		}
		else
		{
			try
			{
				byte[] ienumerable_ = this.method_10(string_0);
				this.method_24((Class25.Enum12)2, ienumerable_);
				result = true;
			}
			catch (SocketException)
			{
				result = false;
			}
			catch (IOException)
			{
				result = false;
			}
		}
		return result;
	}

	// Token: 0x0600035D RID: 861 RVA: 0x00019D4C File Offset: 0x00017F4C
	public bool method_28()
	{
		bool result;
		try
		{
			this.method_24((Class25.Enum12)3, new byte[1]);
			result = true;
		}
		catch (SocketException)
		{
			result = false;
		}
		return result;
	}

	// Token: 0x0600035E RID: 862 RVA: 0x00019D84 File Offset: 0x00017F84
	public bool method_29(string string_0, byte byte_0, byte byte_1, byte byte_2, bool bool_2, byte byte_3, byte byte_4)
	{
		try
		{
			List<byte> list = new List<byte>();
			list.AddRange(this.method_10(string_0));
			list.Add(byte_0);
			List<byte> list2 = list;
			byte[] collection;
			if (this.int_1 < 107)
			{
				(collection = new byte[1])[0] = byte_2;
			}
			else
			{
				collection = this.method_9((int)byte_2);
			}
			list2.AddRange(collection);
			list.Add(bool_2 ? 1 : 0);
			if (this.int_1 < 47)
			{
				list.Add(byte_1);
				list.Add(byte_3 & 1);
			}
			else
			{
				list.Add(byte_3);
			}
			if (this.int_1 >= 107)
			{
				list.AddRange(this.method_9((int)byte_4));
			}
			this.method_24((Class25.Enum12)4, list);
		}
		catch (SocketException)
		{
		}
		return false;
	}

	// Token: 0x0600035F RID: 863 RVA: 0x00019E44 File Offset: 0x00018044
	public bool method_30(string string_0, byte[] byte_0)
	{
		bool result;
		try
		{
			if (this.int_1 < 47)
			{
				byte[] bytes = BitConverter.GetBytes((short)byte_0.Length);
				Array.Reverse(bytes);
				this.method_24((Class25.Enum12)5, this.method_8(new byte[][]
				{
					this.method_10(string_0),
					bytes,
					byte_0
				}));
			}
			else
			{
				this.method_24((Class25.Enum12)5, this.method_8(new byte[][]
				{
					this.method_10(string_0),
					byte_0
				}));
			}
			result = true;
		}
		catch (SocketException)
		{
			result = false;
		}
		catch (IOException)
		{
			result = false;
		}
		return result;
	}

	// Token: 0x06000360 RID: 864 RVA: 0x00019EE4 File Offset: 0x000180E4
	public bool method_31(string string_0)
	{
		bool result;
		if (string.IsNullOrEmpty(string_0))
		{
			result = false;
		}
		else
		{
			byte[] array = this.method_9(this.int_3);
			byte[] array2 = new byte[1];
			byte[] array3 = new byte[1];
			byte[] array4 = new byte[0];
			if (this.int_1 >= 47)
			{
				if (this.int_1 >= 393)
				{
					array4 = this.method_8(new byte[][]
					{
						array4,
						array
					});
					array4 = this.method_8(new byte[][]
					{
						array4,
						this.method_10(string_0)
					});
				}
				else
				{
					array4 = this.method_8(new byte[][]
					{
						array4,
						this.method_10(string_0)
					});
					if (this.int_1 >= 107)
					{
						array4 = this.method_8(new byte[][]
						{
							array4,
							array2
						});
					}
					array4 = this.method_8(new byte[][]
					{
						array4,
						array3
					});
				}
			}
			else
			{
				array4 = this.method_8(new byte[][]
				{
					this.method_10(string_0)
				});
			}
			this.method_24((Class25.Enum12)6, array4);
			result = true;
		}
		return result;
	}

	// Token: 0x06000361 RID: 865 RVA: 0x00019FF4 File Offset: 0x000181F4
	public void method_32()
	{
		try
		{
			this.bool_1 = false;
			if (this.thread_0 != null)
			{
				this.thread_0.Abort();
				this.tcpClient_0.Close();
			}
		}
		catch
		{
		}
	}

	// Token: 0x040002DB RID: 731
	private ForgeInfo forgeInfo_0;

	// Token: 0x040002DC RID: 732
	private TcpClient tcpClient_0;

	// Token: 0x040002DD RID: 733
	private IMinecraftCom iminecraftCom_0;

	// Token: 0x040002DE RID: 734
	private Enum10 enum10_0;

	// Token: 0x040002DF RID: 735
	private int int_0;

	// Token: 0x040002E0 RID: 736
	private int int_1;

	// Token: 0x040002E1 RID: 737
	private bool bool_0;

	// Token: 0x040002E2 RID: 738
	private bool bool_1;

	// Token: 0x040002E3 RID: 739
	private int int_2;

	// Token: 0x040002E4 RID: 740
	private int int_3;

	// Token: 0x040002E5 RID: 741
	private Thread thread_0;

	// Token: 0x020000A4 RID: 164
	private enum Enum12
	{

	}

	// Token: 0x020000A5 RID: 165
	private enum Enum13
	{

	}
}
