﻿using System;
using System.Reflection;

// Token: 0x020000BD RID: 189
internal class Class34
{
	// Token: 0x0600039A RID: 922 RVA: 0x0001B8F4 File Offset: 0x00019AF4
	internal static void bI5VmDjjKqEjf(int typemdt)
	{
		Type type = Class34.module_0.ResolveType(33554432 + typemdt);
		foreach (FieldInfo fieldInfo in type.GetFields())
		{
			MethodInfo method = (MethodInfo)Class34.module_0.ResolveMethod(fieldInfo.MetadataToken + 100663296);
			fieldInfo.SetValue(null, (MulticastDelegate)Delegate.CreateDelegate(type, method));
		}
	}

	// Token: 0x0600039B RID: 923 RVA: 0x0000480C File Offset: 0x00002A0C
	public Class34()
	{
		Class35.NkAVmDjz8ZWXG();
		base..ctor();
	}

	// Token: 0x0600039C RID: 924 RVA: 0x0000604B File Offset: 0x0000424B
	static Class34()
	{
		Class35.NkAVmDjz8ZWXG();
		Class34.module_0 = typeof(Class34).Assembly.ManifestModule;
	}

	// Token: 0x0400032D RID: 813
	internal static Module module_0;

	// Token: 0x020000BE RID: 190
	// (Invoke) Token: 0x0600039E RID: 926
	internal delegate void Delegate6(object o);
}
