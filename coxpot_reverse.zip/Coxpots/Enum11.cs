﻿using System;

// Token: 0x0200009D RID: 157
internal enum Enum11 : byte
{

}
