﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using Coxpots;
using Coxpots.Protocol.Client;
using Coxpots.Protocol.Client.Handler;
using Coxpots.Protocol.Server;
using Coxpots.Protocol.Server.Forge;

// Token: 0x020000AC RID: 172
internal class Class30
{
	// Token: 0x06000384 RID: 900 RVA: 0x0001AE58 File Offset: 0x00019058
	public Class30(ServerInfo serverInfo_1, string string_1, int int_2, ArrayList arrayList_1, int int_3 = 0)
	{
		Class35.NkAVmDjz8ZWXG();
		this.list_0 = new List<Class30.Class31>();
		this.list_1 = new List<string>();
		this.list_2 = new List<TcpClient>();
		this.bool_0 = true;
		base..ctor();
		this.arrayList_0 = arrayList_1;
		this.string_0 = string_1;
		Class30.serverInfo_0 = serverInfo_1;
		this.int_0 = int_2;
		if (Setting.wlogs)
		{
			Class19.smethod_2(Class30.serverInfo_0.ServerIP, Class30.serverInfo_0.ServerPort, Class30.serverInfo_0.GameVersion, int_2);
		}
		if (int_3 == 0)
		{
			Class30.int_1 = Class30.serverInfo_0.ProtocolVersion;
		}
		else
		{
			Class30.int_1 = int_3;
		}
	}

	// Token: 0x06000385 RID: 901 RVA: 0x0001AF00 File Offset: 0x00019100
	internal void method_0(int int_2 = 0)
	{
		Class30.Class32 @class = new Class30.Class32();
		@class.class30_0 = this;
		@class.int_0 = int_2;
		Thread thread = new Thread(new ThreadStart(this.method_1));
		thread.Start();
		new Thread(new ThreadStart(this.JwfZswQxua)).Start();
		new Thread(new ThreadStart(@class.method_0)).Start();
	}

	// Token: 0x06000386 RID: 902 RVA: 0x0001AF68 File Offset: 0x00019168
	public void method_1()
	{
		while (this.bool_0)
		{
			if (this.list_1.Count == 0)
			{
				Class26.smethod_0(this.list_1);
			}
			string[] array = this.list_1.ToArray();
			for (int i = 0; i < array.Length; i++)
			{
				Class30.Class33 @class = new Class30.Class33();
				@class.class30_0 = this;
				@class.string_0 = array[i];
				Thread.Sleep(10);
				if (this.list_2.Count >= 50)
				{
					break;
				}
				new Thread(new ThreadStart(@class.method_0)).Start();
				this.list_1.Remove(@class.string_0);
			}
			Thread.Sleep(3000);
		}
	}

	// Token: 0x06000387 RID: 903 RVA: 0x0001B01C File Offset: 0x0001921C
	private void JwfZswQxua()
	{
		while (this.bool_0)
		{
			Thread.Sleep(Setting.t_clear);
			int i = 0;
			int num = 0;
			while (i < this.list_0.Count)
			{
				if (DateTime.Now.Subtract(this.list_0[i].dateTime_0).Seconds > 25)
				{
					this.list_0[i].Dispose();
					num++;
				}
				i++;
			}
			Class16.smethod_0("运行线程:" + this.list_0.Count.ToString(), "Souiny");
			Class16.smethod_0("清理残留:" + num.ToString(), "Souiny");
			Class16.smethod_0("提取代理数量:" + this.list_1.Count.ToString(), "Souiny");
			GC.Collect();
		}
	}

	// Token: 0x04000301 RID: 769
	private int int_0;

	// Token: 0x04000302 RID: 770
	public List<Class30.Class31> list_0;

	// Token: 0x04000303 RID: 771
	private ArrayList arrayList_0;

	// Token: 0x04000304 RID: 772
	private List<string> list_1;

	// Token: 0x04000305 RID: 773
	private List<TcpClient> list_2;

	// Token: 0x04000306 RID: 774
	private string string_0;

	// Token: 0x04000307 RID: 775
	public bool bool_0;

	// Token: 0x04000308 RID: 776
	public static ServerInfo serverInfo_0;

	// Token: 0x04000309 RID: 777
	public static int int_1;

	// Token: 0x020000AD RID: 173
	public class Class31 : IDisposable, IMinecraftCom
	{
		// Token: 0x06000388 RID: 904 RVA: 0x0001B110 File Offset: 0x00019310
		internal Class31(TcpClient tcpClient_1, string string_3, int int_2, int int_3, ForgeInfo forgeInfo_1, Class30 class30_1)
		{
			Class35.NkAVmDjz8ZWXG();
			this.dateTime_0 = DateTime.Now;
			this.string_1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_";
			base..ctor();
			this.tcpClient_0 = tcpClient_1;
			this.int_0 = int_3;
			this.string_0 = string_3;
			this.int_1 = int_2;
			this.forgeInfo_0 = forgeInfo_1;
			this.class30_0 = class30_1;
		}

		// Token: 0x06000389 RID: 905 RVA: 0x0001B16C File Offset: 0x0001936C
		internal bool method_0(string string_3 = null)
		{
			if (this.tcpClient_0.Connected)
			{
				if (string_3 != null)
				{
					this.string_2 = string_3.Replace("%RANDOM%", this.method_4());
				}
				try
				{
					this.class25_0 = new Class25(this.tcpClient_0, this.int_0, this, this.forgeInfo_0);
					if (this.class25_0.method_23(this.string_0, this.int_1, this.string_2))
					{
						if (Setting.t_tabcomplete > 0)
						{
							this.method_3();
						}
						return true;
					}
					goto IL_8D;
				}
				catch
				{
					this.Dispose();
					goto IL_8D;
				}
			}
			this.Dispose();
			IL_8D:
			return false;
		}

		// Token: 0x0600038A RID: 906 RVA: 0x0001B21C File Offset: 0x0001941C
		public void OnGameJoin()
		{
			Class16.smethod_0(this.string_2 + " 加入成功", "玩家系统");
			if (Setting.sendsetting)
			{
				this.class25_0.method_29("en_US", 9, 0, 0, false, 65, 0);
			}
			this.dateTime_0 = DateTime.Now;
			this.thread_1 = new Thread(new ThreadStart(this.method_5));
			this.thread_1.IsBackground = true;
			this.thread_1.Start();
		}

		// Token: 0x0600038B RID: 907 RVA: 0x00005FD2 File Offset: 0x000041D2
		public void OnKeepAlive()
		{
			this.dateTime_0 = DateTime.Now;
		}

		// Token: 0x0600038C RID: 908 RVA: 0x0001B29C File Offset: 0x0001949C
		public void OnConnectionLost(BotUtils.DisconnectReason type, string msg)
		{
			if (type == BotUtils.DisconnectReason.InGameKick)
			{
				Class16.smethod_0(string.Format("{0}连接丢失:{1}", this.string_2, Class19.smethod_0(msg, null)), "Conss");
				if (Setting.t_rejoin > 0)
				{
					this.method_1();
				}
				else
				{
					this.Dispose();
				}
			}
			else if (type == BotUtils.DisconnectReason.LoginRejected)
			{
				Class16.smethod_0(string.Format("{0}拒绝连接:{1}", this.string_2, Class19.smethod_0(msg, null)), "Conss");
				if (Setting.t_rejoin > 0)
				{
					this.method_1();
				}
				else
				{
					this.Dispose();
				}
			}
			else if (type == BotUtils.DisconnectReason.ConnectionLost)
			{
				this.Dispose();
			}
		}

		// Token: 0x0600038D RID: 909 RVA: 0x0001B338 File Offset: 0x00019538
		private void method_1()
		{
			if (Setting.t_rejoin < 1000)
			{
				Thread.Sleep(Setting.t_rejoin);
				this.dateTime_0 = DateTime.Now;
			}
			else
			{
				int num = Setting.t_rejoin / 1000;
				for (int i = 0; i < num; i++)
				{
					Thread.Sleep(1000);
					this.dateTime_0 = DateTime.Now;
				}
			}
			this.method_0(null);
		}

		// Token: 0x0600038E RID: 910 RVA: 0x0001B3A4 File Offset: 0x000195A4
		public void method_2(TcpClient tcpClient_1)
		{
			byte[] varInt = ProtocolHandler.getVarInt(0);
			byte[] varInt2 = ProtocolHandler.getVarInt(-1);
			byte[] bytes = Encoding.UTF8.GetBytes(this.string_0);
			byte[] varInt3 = ProtocolHandler.getVarInt(bytes.Length);
			byte[] bytes2 = BitConverter.GetBytes((ushort)this.int_1);
			Array.Reverse(bytes2);
			byte[] varInt4 = ProtocolHandler.getVarInt(1);
			byte[] array = ProtocolHandler.concatBytes(new byte[][]
			{
				varInt,
				varInt2,
				varInt3,
				bytes,
				bytes2,
				varInt4
			});
			byte[] buffer = ProtocolHandler.concatBytes(new byte[][]
			{
				ProtocolHandler.getVarInt(array.Length),
				array
			});
			tcpClient_1.Client.Send(buffer, SocketFlags.None);
			byte[] varInt5 = ProtocolHandler.getVarInt(0);
			byte[] buffer2 = ProtocolHandler.concatBytes(new byte[][]
			{
				ProtocolHandler.getVarInt(varInt5.Length),
				varInt5
			});
			tcpClient_1.Client.Send(buffer2, SocketFlags.None);
			ProtocolHandler protocolHandler = new ProtocolHandler(tcpClient_1);
			protocolHandler.readNextVarIntRAW();
		}

		// Token: 0x0600038F RID: 911 RVA: 0x00005FDF File Offset: 0x000041DF
		private void method_3()
		{
			this.thread_0 = new Thread(new ThreadStart(this.method_6));
			this.thread_0.IsBackground = true;
			this.thread_0.Start();
		}

		// Token: 0x06000390 RID: 912 RVA: 0x0001B490 File Offset: 0x00019690
		private string method_4()
		{
			Random random = new Random();
			int num = random.Next(5, 15);
			string text = "";
			for (int i = 0; i < num; i++)
			{
				text += this.string_1[random.Next(0, this.string_1.Length - 1)].ToString();
			}
			return text;
		}

		// Token: 0x06000391 RID: 913 RVA: 0x0001B4F8 File Offset: 0x000196F8
		public void Dispose()
		{
			if (this.class25_0 != null)
			{
				this.class25_0.method_32();
			}
			else if (this.tcpClient_0 != null)
			{
				this.tcpClient_0.Close();
			}
			this.tcpClient_0 = null;
			if (this.thread_1 != null)
			{
				this.thread_1.Abort();
			}
			if (this.thread_0 != null)
			{
				this.thread_0.Abort();
			}
			if (this.class30_0.list_0.Contains(this))
			{
				this.class30_0.list_0.Remove(this);
			}
		}

		// Token: 0x06000392 RID: 914 RVA: 0x00005599 File Offset: 0x00003799
		public void OnChat()
		{
			throw new NotImplementedException();
		}

		// Token: 0x06000393 RID: 915 RVA: 0x0001B58C File Offset: 0x0001978C
		[CompilerGenerated]
		private void method_5()
		{
			while (this.tcpClient_0 != null && this.tcpClient_0.Connected)
			{
				for (int i = 0; i < this.arrayList_0.Count; i++)
				{
					Thread.Sleep(2000);
					this.class25_0.method_27(this.arrayList_0[i].ToString());
				}
			}
		}

		// Token: 0x06000394 RID: 916 RVA: 0x0000600F File Offset: 0x0000420F
		[CompilerGenerated]
		private void method_6()
		{
			while (this.tcpClient_0 != null && this.tcpClient_0.Connected)
			{
				Thread.Sleep(Setting.t_tabcomplete);
				this.class25_0.method_31("/");
			}
		}

		// Token: 0x0400030A RID: 778
		private TcpClient tcpClient_0;

		// Token: 0x0400030B RID: 779
		public DateTime dateTime_0;

		// Token: 0x0400030C RID: 780
		private int int_0;

		// Token: 0x0400030D RID: 781
		private string string_0;

		// Token: 0x0400030E RID: 782
		private int int_1;

		// Token: 0x0400030F RID: 783
		private string string_1;

		// Token: 0x04000310 RID: 784
		private string string_2;

		// Token: 0x04000311 RID: 785
		private ForgeInfo forgeInfo_0;

		// Token: 0x04000312 RID: 786
		private Class25 class25_0;

		// Token: 0x04000313 RID: 787
		public ArrayList arrayList_0;

		// Token: 0x04000314 RID: 788
		private Class30 class30_0;

		// Token: 0x04000315 RID: 789
		private Thread thread_0;

		// Token: 0x04000316 RID: 790
		private Thread thread_1;
	}

	// Token: 0x020000AE RID: 174
	[CompilerGenerated]
	private sealed class Class32
	{
		// Token: 0x06000395 RID: 917 RVA: 0x0000480C File Offset: 0x00002A0C
		public Class32()
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
		}

		// Token: 0x06000396 RID: 918 RVA: 0x0001B5F8 File Offset: 0x000197F8
		internal void method_0()
		{
			try
			{
				while (this.class30_0.bool_0)
				{
					while (this.class30_0.list_0.Count < this.class30_0.int_0)
					{
						if (this.class30_0.list_2.Count > 0)
						{
							this.class31_0 = new Class30.Class31(this.class30_0.list_2[0], Class30.serverInfo_0.ServerIP, Class30.serverInfo_0.ServerPort, Class30.int_1, Class30.serverInfo_0.ForgeInfo, this.class30_0);
							this.class30_0.list_0.Add(this.class31_0);
							this.class31_0.arrayList_0 = this.class30_0.arrayList_0;
							this.class31_0.method_0(this.class30_0.string_0);
							this.class30_0.list_2.RemoveAt(0);
							Thread.Sleep(this.int_0);
						}
						else
						{
							Thread.Sleep(1000);
						}
					}
				}
			}
			catch (Exception ex)
			{
				Class16.smethod_0(ex.Message, "错误");
			}
		}

		// Token: 0x04000317 RID: 791
		public Class30 class30_0;

		// Token: 0x04000318 RID: 792
		public Class30.Class31 class31_0;

		// Token: 0x04000319 RID: 793
		public int int_0;
	}

	// Token: 0x020000AF RID: 175
	[CompilerGenerated]
	private sealed class Class33
	{
		// Token: 0x06000397 RID: 919 RVA: 0x0000480C File Offset: 0x00002A0C
		public Class33()
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
		}

		// Token: 0x06000398 RID: 920 RVA: 0x0001B728 File Offset: 0x00019928
		internal void method_0()
		{
			string[] array = this.string_0.Split(new char[]
			{
				':'
			});
			string hostname;
			int port;
			if (array.Length == 2)
			{
				hostname = array[0];
				port = int.Parse(array[1]);
			}
			else
			{
				hostname = array[0];
				port = 8080;
			}
			try
			{
				TcpClient tcpClient = new TcpClient();
				tcpClient.ReceiveTimeout = 5000;
				tcpClient.Connect(hostname, port);
				string s = string.Format(string.Concat(new string[]
				{
					"CONNECT ",
					Class30.serverInfo_0.ServerIP,
					":",
					Class30.serverInfo_0.ServerPort.ToString(),
					" HTTP/1.1\r\nHost: ",
					Class30.serverInfo_0.ServerIP,
					":",
					Class30.serverInfo_0.ServerPort.ToString(),
					"\r\nProxy-Connection: keep-alive\r\n\r\n"
				}), new object[0]);
				if (tcpClient.Connected)
				{
					byte[] bytes = Encoding.UTF8.GetBytes(s);
					NetworkStream stream = tcpClient.GetStream();
					tcpClient.Client.Send(bytes);
					byte[] array2 = new byte[1024];
					int count = stream.Read(array2, 0, array2.Length);
					string @string = Encoding.Default.GetString(array2, 0, count);
					if (@string.Contains("200") || @string.Contains("100"))
					{
						this.class30_0.list_2.Add(tcpClient);
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x0400031A RID: 794
		public string string_0;

		// Token: 0x0400031B RID: 795
		public Class30 class30_0;
	}
}
