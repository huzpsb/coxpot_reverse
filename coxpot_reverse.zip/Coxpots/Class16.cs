﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Threading;

// Token: 0x0200008E RID: 142
internal class Class16
{
	// Token: 0x060002A8 RID: 680 RVA: 0x00005B18 File Offset: 0x00003D18
	public static void smethod_0(string string_0, string string_1 = null)
	{
		if (string_1 == null)
		{
			Class16.list_0.Add(string_0);
		}
		else
		{
			Class16.list_0.Add("[" + string_1 + "] " + string_0);
		}
	}

	// Token: 0x060002A9 RID: 681 RVA: 0x00005B48 File Offset: 0x00003D48
	public static void smethod_1()
	{
		Class16.thread_0 = new Thread(new ThreadStart(Class16.Class17.class17_0.method_0));
		Class16.thread_0.Start();
	}

	// Token: 0x060002AA RID: 682 RVA: 0x00005B7D File Offset: 0x00003D7D
	public static void smethod_2()
	{
		if (Class16.thread_0 != null)
		{
			Class16.thread_0.Abort();
		}
	}

	// Token: 0x060002AB RID: 683 RVA: 0x00015160 File Offset: 0x00013360
	public static void smethod_3(string string_0, bool bool_0 = true)
	{
		if (!string.IsNullOrEmpty(string_0))
		{
			if (!bool_0)
			{
				string_0 = string_0.Replace('\n', ' ');
			}
			string[] array = string_0.Split(new char[]
			{
				'§'
			});
			for (int i = 1; i < array.Length; i++)
			{
				if (array[i].Length > 0)
				{
					char c = array[i][0];
					char c2 = c;
					switch (c2)
					{
					case '0':
						Console.ForegroundColor = ConsoleColor.Gray;
						break;
					case '1':
						Console.ForegroundColor = ConsoleColor.DarkBlue;
						break;
					case '2':
						Console.ForegroundColor = ConsoleColor.DarkGreen;
						break;
					case '3':
						Console.ForegroundColor = ConsoleColor.DarkCyan;
						break;
					case '4':
						Console.ForegroundColor = ConsoleColor.DarkRed;
						break;
					case '5':
						Console.ForegroundColor = ConsoleColor.DarkMagenta;
						break;
					case '6':
						Console.ForegroundColor = ConsoleColor.DarkYellow;
						break;
					case '7':
						Console.ForegroundColor = ConsoleColor.Gray;
						break;
					case '8':
						Console.ForegroundColor = ConsoleColor.DarkGray;
						break;
					case '9':
						Console.ForegroundColor = ConsoleColor.Blue;
						break;
					default:
						switch (c2)
						{
						case 'a':
							Console.ForegroundColor = ConsoleColor.Green;
							break;
						case 'b':
							Console.ForegroundColor = ConsoleColor.Cyan;
							break;
						case 'c':
							Console.ForegroundColor = ConsoleColor.Red;
							break;
						case 'd':
							Console.ForegroundColor = ConsoleColor.Magenta;
							break;
						case 'e':
							Console.ForegroundColor = ConsoleColor.Yellow;
							break;
						case 'f':
							Console.ForegroundColor = ConsoleColor.White;
							break;
						default:
							if (c2 == 'r')
							{
								Console.ForegroundColor = ConsoleColor.Gray;
							}
							break;
						}
						break;
					}
					if (array[i].Length > 1)
					{
						Console.Write(array[i].Substring(1, array[i].Length - 1));
					}
				}
			}
			Console.ForegroundColor = ConsoleColor.Gray;
			Console.Write('\n');
		}
	}

	// Token: 0x060002AC RID: 684 RVA: 0x0000480C File Offset: 0x00002A0C
	public Class16()
	{
		Class35.NkAVmDjz8ZWXG();
		base..ctor();
	}

	// Token: 0x060002AD RID: 685 RVA: 0x00005B93 File Offset: 0x00003D93
	static Class16()
	{
		Class35.NkAVmDjz8ZWXG();
		Class16.list_0 = new List<string>();
	}

	// Token: 0x0400029F RID: 671
	private static List<string> list_0;

	// Token: 0x040002A0 RID: 672
	private static Thread thread_0;

	// Token: 0x0200008F RID: 143
	[CompilerGenerated]
	[Serializable]
	private sealed class Class17
	{
		// Token: 0x060002AE RID: 686 RVA: 0x00005BA4 File Offset: 0x00003DA4
		static Class17()
		{
			Class35.NkAVmDjz8ZWXG();
			Class16.Class17.class17_0 = new Class16.Class17();
		}

		// Token: 0x060002AF RID: 687 RVA: 0x0000480C File Offset: 0x00002A0C
		public Class17()
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
		}

		// Token: 0x060002B0 RID: 688 RVA: 0x000152F4 File Offset: 0x000134F4
		internal void method_0()
		{
			for (;;)
			{
				if (Class16.list_0.Count <= 0)
				{
					Thread.Sleep(20);
				}
				else
				{
					foreach (string text in Class16.list_0.ToArray())
					{
						Console.WriteLine(text);
						Class16.list_0.Remove(text);
					}
				}
			}
		}

		// Token: 0x040002A1 RID: 673
		public static readonly Class16.Class17 class17_0;

		// Token: 0x040002A2 RID: 674
		public static ThreadStart threadStart_0;
	}
}
