﻿using System;
using Ionic.Zlib;

// Token: 0x02000072 RID: 114
internal sealed class Class4
{
	// Token: 0x060001F9 RID: 505 RVA: 0x0000EE4C File Offset: 0x0000D04C
	internal Class4(ZlibCodec zlibCodec_1, object object_1, int int_13)
	{
		Class35.NkAVmDjz8ZWXG();
		this.int_4 = new int[1];
		this.int_5 = new int[1];
		this.class6_0 = new Class6();
		this.class8_0 = new Class8();
		base..ctor();
		this.zlibCodec_0 = zlibCodec_1;
		this.int_9 = new int[4320];
		this.byte_0 = new byte[int_13];
		this.int_10 = int_13;
		this.object_0 = object_1;
		this.enum5_0 = (Class4.Enum5)0;
		this.method_0();
	}

	// Token: 0x060001FA RID: 506 RVA: 0x0000EED4 File Offset: 0x0000D0D4
	internal uint method_0()
	{
		uint result = this.uint_0;
		this.enum5_0 = (Class4.Enum5)0;
		this.int_7 = 0;
		this.int_8 = 0;
		this.int_12 = 0;
		this.int_11 = 0;
		if (this.object_0 != null)
		{
			this.zlibCodec_0.uint_0 = (this.uint_0 = Adler.Adler32(0u, null, 0, 0));
		}
		return result;
	}

	// Token: 0x060001FB RID: 507 RVA: 0x0000EF38 File Offset: 0x0000D138
	internal int SvBuDpbipQ(int int_13)
	{
		int num = this.zlibCodec_0.NextIn;
		int num2 = this.zlibCodec_0.AvailableBytesIn;
		int num3 = this.int_8;
		int i = this.int_7;
		int num4 = this.int_12;
		int num5 = (num4 < this.int_11) ? (this.int_11 - num4 - 1) : (this.int_10 - num4);
		int num6;
		for (;;)
		{
			switch (this.enum5_0)
			{
			case (Class4.Enum5)0:
				while (i < 3)
				{
					if (num2 == 0)
					{
						goto IL_996;
					}
					int_13 = 0;
					num2--;
					num3 |= (int)(this.zlibCodec_0.InputBuffer[num++] & byte.MaxValue) << i;
					i += 8;
				}
				num6 = (num3 & 7);
				this.int_6 = (num6 & 1);
				switch ((uint)num6 >> 1)
				{
				case 0u:
					num3 >>= 3;
					i -= 3;
					num6 = (i & 7);
					num3 >>= num6;
					i -= num6;
					this.enum5_0 = (Class4.Enum5)1;
					continue;
				case 1u:
				{
					int[] array = new int[1];
					int[] array2 = new int[1];
					int[][] array3 = new int[1][];
					int[][] array4 = new int[1][];
					Class8.smethod_0(array, array2, array3, array4, this.zlibCodec_0);
					this.class6_0.method_0(array[0], array2[0], array3[0], 0, array4[0], 0);
					num3 >>= 3;
					i -= 3;
					this.enum5_0 = (Class4.Enum5)6;
					continue;
				}
				case 2u:
					num3 >>= 3;
					i -= 3;
					this.enum5_0 = (Class4.Enum5)3;
					continue;
				case 3u:
					goto IL_915;
				default:
					continue;
				}
				break;
			case (Class4.Enum5)1:
				while (i < 32)
				{
					if (num2 == 0)
					{
						goto IL_A6B;
					}
					int_13 = 0;
					num2--;
					num3 |= (int)(this.zlibCodec_0.InputBuffer[num++] & byte.MaxValue) << i;
					i += 8;
				}
				if ((~num3 >> 16 & 65535) == (num3 & 65535))
				{
					this.int_1 = (num3 & 65535);
					int num7 = 0;
					i = 0;
					num3 = num7;
					this.enum5_0 = ((this.int_1 != 0) ? ((Class4.Enum5)2) : ((this.int_6 != 0) ? ((Class4.Enum5)7) : ((Class4.Enum5)0)));
					continue;
				}
				goto IL_9F2;
			case (Class4.Enum5)2:
				if (num2 == 0)
				{
					goto IL_AC7;
				}
				if (num5 == 0)
				{
					if (num4 == this.int_10 && this.int_11 != 0)
					{
						num4 = 0;
						num5 = ((0 < this.int_11) ? (this.int_11 - num4 - 1) : (this.int_10 - num4));
					}
					if (num5 == 0)
					{
						this.int_12 = num4;
						int_13 = this.method_4(int_13);
						num4 = this.int_12;
						num5 = ((num4 < this.int_11) ? (this.int_11 - num4 - 1) : (this.int_10 - num4));
						if (num4 == this.int_10 && this.int_11 != 0)
						{
							num4 = 0;
							num5 = ((0 < this.int_11) ? (this.int_11 - num4 - 1) : (this.int_10 - num4));
						}
						if (num5 == 0)
						{
							goto IL_B23;
						}
					}
				}
				int_13 = 0;
				num6 = this.int_1;
				if (num6 > num2)
				{
					num6 = num2;
				}
				if (num6 > num5)
				{
					num6 = num5;
				}
				Array.Copy(this.zlibCodec_0.InputBuffer, num, this.byte_0, num4, num6);
				num += num6;
				num2 -= num6;
				num4 += num6;
				num5 -= num6;
				if ((this.int_1 -= num6) == 0)
				{
					this.enum5_0 = ((this.int_6 != 0) ? ((Class4.Enum5)7) : ((Class4.Enum5)0));
					continue;
				}
				continue;
			case (Class4.Enum5)3:
				while (i < 14)
				{
					if (num2 == 0)
					{
						goto IL_BF8;
					}
					int_13 = 0;
					num2--;
					num3 |= (int)(this.zlibCodec_0.InputBuffer[num++] & byte.MaxValue) << i;
					i += 8;
				}
				num6 = (this.xNduqdKxyp = (num3 & 16383));
				if ((num6 & 31) <= 29 && (num6 >> 5 & 31) <= 29)
				{
					num6 = 258 + (num6 & 31) + (num6 >> 5 & 31);
					if (this.int_3 == null || this.int_3.Length < num6)
					{
						this.int_3 = new int[num6];
					}
					else
					{
						Array.Clear(this.int_3, 0, num6);
					}
					num3 >>= 14;
					i -= 14;
					this.int_2 = 0;
					this.enum5_0 = (Class4.Enum5)4;
					goto IL_429;
				}
				goto IL_B7F;
			case (Class4.Enum5)4:
				goto IL_429;
			case (Class4.Enum5)5:
				goto IL_2E7;
			case (Class4.Enum5)6:
				goto IL_55;
			case (Class4.Enum5)7:
				goto IL_EEA;
			case (Class4.Enum5)8:
				goto IL_F9B;
			case (Class4.Enum5)9:
				goto IL_FF7;
			}
			break;
			for (;;)
			{
				IL_2E7:
				num6 = this.xNduqdKxyp;
				if (this.int_2 >= 258 + (num6 & 31) + (num6 >> 5 & 31))
				{
					break;
				}
				num6 = this.int_4[0];
				while (i < num6)
				{
					if (num2 == 0)
					{
						goto IL_E79;
					}
					int_13 = 0;
					num2--;
					num3 |= (int)(this.zlibCodec_0.InputBuffer[num++] & byte.MaxValue) << i;
					i += 8;
				}
				num6 = this.int_9[(this.int_5[0] + (num3 & Class5.int_0[num6])) * 3 + 1];
				int num8 = this.int_9[(this.int_5[0] + (num3 & Class5.int_0[num6])) * 3 + 2];
				if (num8 < 16)
				{
					num3 >>= num6;
					i -= num6;
					int[] array5 = this.int_3;
					int num9 = this.int_2;
					this.int_2 = num9 + 1;
					array5[num9] = num8;
				}
				else
				{
					int num10 = (num8 == 18) ? 7 : (num8 - 14);
					int num11 = (num8 == 18) ? 11 : 3;
					while (i < num6 + num10)
					{
						if (num2 == 0)
						{
							goto IL_E1D;
						}
						int_13 = 0;
						num2--;
						num3 |= (int)(this.zlibCodec_0.InputBuffer[num++] & byte.MaxValue) << i;
						i += 8;
					}
					num3 >>= num6;
					i -= num6;
					num11 += (num3 & Class5.int_0[num10]);
					num3 >>= num10;
					i -= num10;
					num10 = this.int_2;
					num6 = this.xNduqdKxyp;
					if (num10 + num11 > 258 + (num6 & 31) + (num6 >> 5 & 31) || (num8 == 16 && num10 < 1))
					{
						goto IL_D9D;
					}
					num8 = ((num8 == 16) ? this.int_3[num10 - 1] : 0);
					do
					{
						this.int_3[num10++] = num8;
					}
					while (--num11 != 0);
					this.int_2 = num10;
				}
			}
			this.int_5[0] = -1;
			int[] array6 = new int[]
			{
				9
			};
			int[] array7 = new int[]
			{
				6
			};
			int[] array8 = new int[1];
			int[] array9 = new int[1];
			num6 = this.xNduqdKxyp;
			num6 = this.class8_0.method_2(257 + (num6 & 31), 1 + (num6 >> 5 & 31), this.int_3, array6, array7, array8, array9, this.int_9, this.zlibCodec_0);
			if (num6 == 0)
			{
				this.class6_0.method_0(array6[0], array7[0], this.int_9, array8[0], this.int_9, array9[0]);
				this.enum5_0 = (Class4.Enum5)6;
				goto IL_55;
			}
			goto IL_D26;
			IL_429:
			while (this.int_2 < 4 + (this.xNduqdKxyp >> 10))
			{
				while (i < 3)
				{
					if (num2 == 0)
					{
						goto IL_CCA;
					}
					int_13 = 0;
					num2--;
					num3 |= (int)(this.zlibCodec_0.InputBuffer[num++] & byte.MaxValue) << i;
					i += 8;
				}
				int[] array10 = this.int_3;
				int[] array11 = Class4.int_0;
				int num9 = this.int_2;
				this.int_2 = num9 + 1;
				array10[array11[num9]] = (num3 & 7);
				num3 >>= 3;
				i -= 3;
			}
			while (this.int_2 < 19)
			{
				int[] array12 = this.int_3;
				int[] array13 = Class4.int_0;
				int num9 = this.int_2;
				this.int_2 = num9 + 1;
				array12[array13[num9]] = 0;
			}
			this.int_4[0] = 7;
			num6 = this.class8_0.method_1(this.int_3, this.int_4, this.int_5, this.int_9, this.zlibCodec_0);
			if (num6 == 0)
			{
				this.int_2 = 0;
				this.enum5_0 = (Class4.Enum5)5;
				goto IL_2E7;
			}
			goto IL_C54;
			IL_55:
			this.int_8 = num3;
			this.int_7 = i;
			this.zlibCodec_0.AvailableBytesIn = num2;
			this.zlibCodec_0.TotalBytesIn += (long)(num - this.zlibCodec_0.NextIn);
			this.zlibCodec_0.NextIn = num;
			this.int_12 = num4;
			int_13 = this.class6_0.method_1(this, int_13);
			if (int_13 != 1)
			{
				goto IL_ED5;
			}
			int_13 = 0;
			num = this.zlibCodec_0.NextIn;
			num2 = this.zlibCodec_0.AvailableBytesIn;
			num3 = this.int_8;
			i = this.int_7;
			num4 = this.int_12;
			num5 = ((num4 < this.int_11) ? (this.int_11 - num4 - 1) : (this.int_10 - num4));
			if (this.int_6 != 0)
			{
				goto IL_EE3;
			}
			this.enum5_0 = (Class4.Enum5)0;
		}
		int_13 = -2;
		this.int_8 = num3;
		this.int_7 = i;
		this.zlibCodec_0.AvailableBytesIn = num2;
		this.zlibCodec_0.TotalBytesIn += (long)(num - this.zlibCodec_0.NextIn);
		this.zlibCodec_0.NextIn = num;
		this.int_12 = num4;
		return this.method_4(-2);
		IL_915:
		num3 >>= 3;
		i -= 3;
		this.enum5_0 = (Class4.Enum5)9;
		this.zlibCodec_0.Message = "invalid block type";
		int_13 = -3;
		this.int_8 = num3;
		this.int_7 = i;
		this.zlibCodec_0.AvailableBytesIn = num2;
		this.zlibCodec_0.TotalBytesIn += (long)(num - this.zlibCodec_0.NextIn);
		this.zlibCodec_0.NextIn = num;
		this.int_12 = num4;
		return this.method_4(-3);
		IL_996:
		this.int_8 = num3;
		this.int_7 = i;
		this.zlibCodec_0.AvailableBytesIn = num2;
		this.zlibCodec_0.TotalBytesIn += (long)(num - this.zlibCodec_0.NextIn);
		this.zlibCodec_0.NextIn = num;
		this.int_12 = num4;
		return this.method_4(int_13);
		IL_9F2:
		this.enum5_0 = (Class4.Enum5)9;
		this.zlibCodec_0.Message = "invalid stored block lengths";
		int_13 = -3;
		this.int_8 = num3;
		this.int_7 = i;
		this.zlibCodec_0.AvailableBytesIn = num2;
		this.zlibCodec_0.TotalBytesIn += (long)(num - this.zlibCodec_0.NextIn);
		this.zlibCodec_0.NextIn = num;
		this.int_12 = num4;
		return this.method_4(-3);
		IL_A6B:
		this.int_8 = num3;
		this.int_7 = i;
		this.zlibCodec_0.AvailableBytesIn = num2;
		this.zlibCodec_0.TotalBytesIn += (long)(num - this.zlibCodec_0.NextIn);
		this.zlibCodec_0.NextIn = num;
		this.int_12 = num4;
		return this.method_4(int_13);
		IL_AC7:
		this.int_8 = num3;
		this.int_7 = i;
		this.zlibCodec_0.AvailableBytesIn = num2;
		this.zlibCodec_0.TotalBytesIn += (long)(num - this.zlibCodec_0.NextIn);
		this.zlibCodec_0.NextIn = num;
		this.int_12 = num4;
		return this.method_4(int_13);
		IL_B23:
		this.int_8 = num3;
		this.int_7 = i;
		this.zlibCodec_0.AvailableBytesIn = num2;
		this.zlibCodec_0.TotalBytesIn += (long)(num - this.zlibCodec_0.NextIn);
		this.zlibCodec_0.NextIn = num;
		this.int_12 = num4;
		return this.method_4(int_13);
		IL_B7F:
		this.enum5_0 = (Class4.Enum5)9;
		this.zlibCodec_0.Message = "too many length or distance symbols";
		int_13 = -3;
		this.int_8 = num3;
		this.int_7 = i;
		this.zlibCodec_0.AvailableBytesIn = num2;
		this.zlibCodec_0.TotalBytesIn += (long)(num - this.zlibCodec_0.NextIn);
		this.zlibCodec_0.NextIn = num;
		this.int_12 = num4;
		return this.method_4(-3);
		IL_BF8:
		this.int_8 = num3;
		this.int_7 = i;
		this.zlibCodec_0.AvailableBytesIn = num2;
		this.zlibCodec_0.TotalBytesIn += (long)(num - this.zlibCodec_0.NextIn);
		this.zlibCodec_0.NextIn = num;
		this.int_12 = num4;
		return this.method_4(int_13);
		IL_C54:
		int_13 = num6;
		if (int_13 == -3)
		{
			this.int_3 = null;
			this.enum5_0 = (Class4.Enum5)9;
		}
		this.int_8 = num3;
		this.int_7 = i;
		this.zlibCodec_0.AvailableBytesIn = num2;
		this.zlibCodec_0.TotalBytesIn += (long)(num - this.zlibCodec_0.NextIn);
		this.zlibCodec_0.NextIn = num;
		this.int_12 = num4;
		return this.method_4(int_13);
		IL_CCA:
		this.int_8 = num3;
		this.int_7 = i;
		this.zlibCodec_0.AvailableBytesIn = num2;
		this.zlibCodec_0.TotalBytesIn += (long)(num - this.zlibCodec_0.NextIn);
		this.zlibCodec_0.NextIn = num;
		this.int_12 = num4;
		return this.method_4(int_13);
		IL_D26:
		if (num6 == -3)
		{
			this.int_3 = null;
			this.enum5_0 = (Class4.Enum5)9;
		}
		int_13 = num6;
		this.int_8 = num3;
		this.int_7 = i;
		this.zlibCodec_0.AvailableBytesIn = num2;
		this.zlibCodec_0.TotalBytesIn += (long)(num - this.zlibCodec_0.NextIn);
		this.zlibCodec_0.NextIn = num;
		this.int_12 = num4;
		return this.method_4(int_13);
		IL_D9D:
		this.int_3 = null;
		this.enum5_0 = (Class4.Enum5)9;
		this.zlibCodec_0.Message = "invalid bit length repeat";
		int_13 = -3;
		this.int_8 = num3;
		this.int_7 = i;
		this.zlibCodec_0.AvailableBytesIn = num2;
		this.zlibCodec_0.TotalBytesIn += (long)(num - this.zlibCodec_0.NextIn);
		this.zlibCodec_0.NextIn = num;
		this.int_12 = num4;
		return this.method_4(-3);
		IL_E1D:
		this.int_8 = num3;
		this.int_7 = i;
		this.zlibCodec_0.AvailableBytesIn = num2;
		this.zlibCodec_0.TotalBytesIn += (long)(num - this.zlibCodec_0.NextIn);
		this.zlibCodec_0.NextIn = num;
		this.int_12 = num4;
		return this.method_4(int_13);
		IL_E79:
		this.int_8 = num3;
		this.int_7 = i;
		this.zlibCodec_0.AvailableBytesIn = num2;
		this.zlibCodec_0.TotalBytesIn += (long)(num - this.zlibCodec_0.NextIn);
		this.zlibCodec_0.NextIn = num;
		this.int_12 = num4;
		return this.method_4(int_13);
		IL_ED5:
		return this.method_4(int_13);
		IL_EE3:
		this.enum5_0 = (Class4.Enum5)7;
		IL_EEA:
		this.int_12 = num4;
		int_13 = this.method_4(int_13);
		num4 = this.int_12;
		int num12 = (num4 < this.int_11) ? (this.int_11 - num4 - 1) : (this.int_10 - num4);
		if (this.int_11 != this.int_12)
		{
			this.int_8 = num3;
			this.int_7 = i;
			this.zlibCodec_0.AvailableBytesIn = num2;
			this.zlibCodec_0.TotalBytesIn += (long)(num - this.zlibCodec_0.NextIn);
			this.zlibCodec_0.NextIn = num;
			this.int_12 = num4;
			return this.method_4(int_13);
		}
		this.enum5_0 = (Class4.Enum5)8;
		IL_F9B:
		int_13 = 1;
		this.int_8 = num3;
		this.int_7 = i;
		this.zlibCodec_0.AvailableBytesIn = num2;
		this.zlibCodec_0.TotalBytesIn += (long)(num - this.zlibCodec_0.NextIn);
		this.zlibCodec_0.NextIn = num;
		this.int_12 = num4;
		return this.method_4(1);
		IL_FF7:
		int_13 = -3;
		this.int_8 = num3;
		this.int_7 = i;
		this.zlibCodec_0.AvailableBytesIn = num2;
		this.zlibCodec_0.TotalBytesIn += (long)(num - this.zlibCodec_0.NextIn);
		this.zlibCodec_0.NextIn = num;
		this.int_12 = num4;
		return this.method_4(-3);
	}

	// Token: 0x060001FC RID: 508 RVA: 0x000055CB File Offset: 0x000037CB
	internal void method_1()
	{
		this.method_0();
		this.byte_0 = null;
		this.int_9 = null;
	}

	// Token: 0x060001FD RID: 509 RVA: 0x0000FF9C File Offset: 0x0000E19C
	internal void method_2(byte[] byte_1, int int_13, int int_14)
	{
		Array.Copy(byte_1, int_13, this.byte_0, 0, int_14);
		this.int_12 = int_14;
		this.int_11 = int_14;
	}

	// Token: 0x060001FE RID: 510 RVA: 0x0000FFC8 File Offset: 0x0000E1C8
	internal int method_3()
	{
		return (this.enum5_0 == (Class4.Enum5)1) ? 1 : 0;
	}

	// Token: 0x060001FF RID: 511 RVA: 0x0000FFE4 File Offset: 0x0000E1E4
	internal int method_4(int int_13)
	{
		for (int i = 0; i < 2; i++)
		{
			int num;
			if (i == 0)
			{
				num = ((this.int_11 <= this.int_12) ? this.int_12 : this.int_10) - this.int_11;
			}
			else
			{
				num = this.int_12 - this.int_11;
			}
			if (num == 0)
			{
				if (int_13 == -5)
				{
					int_13 = 0;
				}
				return int_13;
			}
			if (num > this.zlibCodec_0.AvailableBytesOut)
			{
				num = this.zlibCodec_0.AvailableBytesOut;
			}
			if (num != 0 && int_13 == -5)
			{
				int_13 = 0;
			}
			this.zlibCodec_0.AvailableBytesOut -= num;
			this.zlibCodec_0.TotalBytesOut += (long)num;
			if (this.object_0 != null)
			{
				this.zlibCodec_0.uint_0 = (this.uint_0 = Adler.Adler32(this.uint_0, this.byte_0, this.int_11, num));
			}
			Array.Copy(this.byte_0, this.int_11, this.zlibCodec_0.OutputBuffer, this.zlibCodec_0.NextOut, num);
			this.zlibCodec_0.NextOut += num;
			this.int_11 += num;
			if (this.int_11 == this.int_10 && i == 0)
			{
				this.int_11 = 0;
				if (this.int_12 == this.int_10)
				{
					this.int_12 = 0;
				}
			}
			else
			{
				i++;
			}
		}
		return int_13;
	}

	// Token: 0x06000200 RID: 512 RVA: 0x000055E2 File Offset: 0x000037E2
	static Class4()
	{
		Class35.NkAVmDjz8ZWXG();
		Class4.int_0 = new int[]
		{
			16,
			17,
			18,
			0,
			8,
			7,
			9,
			6,
			10,
			5,
			11,
			4,
			12,
			3,
			13,
			2,
			14,
			1,
			15
		};
	}

	// Token: 0x040001EC RID: 492
	internal static readonly int[] int_0;

	// Token: 0x040001ED RID: 493
	private Class4.Enum5 enum5_0;

	// Token: 0x040001EE RID: 494
	internal int int_1;

	// Token: 0x040001EF RID: 495
	internal int xNduqdKxyp;

	// Token: 0x040001F0 RID: 496
	internal int int_2;

	// Token: 0x040001F1 RID: 497
	internal int[] int_3;

	// Token: 0x040001F2 RID: 498
	internal int[] int_4;

	// Token: 0x040001F3 RID: 499
	internal int[] int_5;

	// Token: 0x040001F4 RID: 500
	internal Class6 class6_0;

	// Token: 0x040001F5 RID: 501
	internal int int_6;

	// Token: 0x040001F6 RID: 502
	internal ZlibCodec zlibCodec_0;

	// Token: 0x040001F7 RID: 503
	internal int int_7;

	// Token: 0x040001F8 RID: 504
	internal int int_8;

	// Token: 0x040001F9 RID: 505
	internal int[] int_9;

	// Token: 0x040001FA RID: 506
	internal byte[] byte_0;

	// Token: 0x040001FB RID: 507
	internal int int_10;

	// Token: 0x040001FC RID: 508
	internal int int_11;

	// Token: 0x040001FD RID: 509
	internal int int_12;

	// Token: 0x040001FE RID: 510
	internal object object_0;

	// Token: 0x040001FF RID: 511
	internal uint uint_0;

	// Token: 0x04000200 RID: 512
	internal Class8 class8_0;

	// Token: 0x02000073 RID: 115
	private enum Enum5
	{

	}
}
