﻿using System;
using System.Linq;
using System.Net;
using Coxpots.Protocol.Server;

// Token: 0x02000007 RID: 7
public class Pin
{
	// Token: 0x06000016 RID: 22 RVA: 0x000069DC File Offset: 0x00004BDC
	public static bool SetServerIP(string init = null)
	{
		string text = string.Empty;
		if (init == null)
		{
			Console.ForegroundColor = ConsoleColor.White;
			Console.Write(">> ");
			text = Console.ReadLine();
		}
		else
		{
			text = init;
		}
		text = text.ToLower();
		string[] array = text.Split(new char[]
		{
			':'
		});
		string text2 = array[0];
		ushort serverPort = 25565;
		if (array.Length > 1)
		{
			try
			{
				Pin.ServerIP = Pin.smethod_0(text2);
				Pin.ServerPort = (int)Convert.ToUInt16(array[1]);
				return true;
			}
			catch (FormatException ex)
			{
				Console.WriteLine(ex.Message);
			}
		}
		bool result;
		if ((text2 == "localhost" || text2.Contains('.')) && (array.Length == 1 && text2.Contains('.')))
		{
			if (Protocol.MinecraftServiceLookup(ref text2, ref serverPort))
			{
				Pin.ServerIP = Pin.smethod_0(text2);
				Pin.ServerPort = (int)serverPort;
				Console.ReadLine();
			}
			else
			{
				Console.WriteLine("");
				Console.ForegroundColor = ConsoleColor.DarkGray;
				Console.WriteLine("==================================");
				Console.ForegroundColor = ConsoleColor.White;
				Console.WriteLine("\r当前不存在Srv记录,默认端口[25565]");
				Console.ForegroundColor = ConsoleColor.DarkGray;
				Console.WriteLine("==================================");
				Console.ForegroundColor = ConsoleColor.White;
				Pin.SetServerIP(null);
				if (int.Parse(Console.ReadLine()) == 0)
				{
					Console.Clear();
					Class20.smethod_1();
				}
			}
			result = true;
		}
		else
		{
			result = false;
		}
		return result;
	}

	// Token: 0x06000017 RID: 23 RVA: 0x00006B48 File Offset: 0x00004D48
	private static string smethod_0(string string_0)
	{
		IPHostEntry hostEntry = Dns.GetHostEntry(string_0);
		IPEndPoint ipendPoint = new IPEndPoint(hostEntry.AddressList[0], 0);
		return ipendPoint.Address.ToString();
	}

	// Token: 0x06000018 RID: 24 RVA: 0x0000480C File Offset: 0x00002A0C
	public Pin()
	{
		Class35.NkAVmDjz8ZWXG();
		base..ctor();
	}

	// Token: 0x04000003 RID: 3
	public static string ServerIP;

	// Token: 0x04000004 RID: 4
	public static int ServerPort;
}
