﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

// Token: 0x02000094 RID: 148
internal static class Class21
{
	// Token: 0x060002E6 RID: 742 RVA: 0x00016170 File Offset: 0x00014370
	public static Class21.Class22 smethod_0(string string_0)
	{
		int num = 0;
		return Class21.smethod_1(string_0, ref num);
	}

	// Token: 0x060002E7 RID: 743 RVA: 0x0001618C File Offset: 0x0001438C
	private static Class21.Class22 smethod_1(string string_0, ref int int_0)
	{
		Class21.Class22 result;
		try
		{
			char c = string_0[int_0];
			char c2 = c;
			Class21.Class22 @class;
			if (c2 <= '[')
			{
				if (c2 != '"')
				{
					switch (c2)
					{
					case '.':
					case '0':
					case '1':
					case '2':
					case '3':
					case '4':
					case '5':
					case '6':
					case '7':
					case '8':
					case '9':
					{
						@class = new Class21.Class22((Class21.Class22.Enum9)2);
						StringBuilder stringBuilder = new StringBuilder();
						while ((string_0[int_0] >= '0' && string_0[int_0] <= '9') || string_0[int_0] == '.')
						{
							stringBuilder.Append(string_0[int_0]);
							int_0++;
						}
						@class.string_0 = stringBuilder.ToString();
						break;
					}
					case '/':
						goto IL_23E;
					default:
						if (c2 != '[')
						{
							goto IL_23E;
						}
						@class = new Class21.Class22((Class21.Class22.Enum9)1);
						int_0++;
						while (string_0[int_0] != ']')
						{
							if (string_0[int_0] == ',')
							{
								int_0++;
							}
							Class21.Class22 item = Class21.smethod_1(string_0, ref int_0);
							@class.list_0.Add(item);
						}
						int_0++;
						break;
					}
				}
				else
				{
					@class = new Class21.Class22((Class21.Class22.Enum9)2);
					int_0++;
					while (string_0[int_0] != '"')
					{
						if (string_0[int_0] == '\\')
						{
							try
							{
								if (string_0[int_0 + 1] == 'u' && Class21.smethod_2(string_0[int_0 + 2]) && Class21.smethod_2(string_0[int_0 + 3]) && Class21.smethod_2(string_0[int_0 + 4]) && Class21.smethod_2(string_0[int_0 + 5]))
								{
									Class21.Class22 class2 = @class;
									class2.string_0 += char.ConvertFromUtf32(int.Parse(string_0.Substring(int_0 + 2, 4), NumberStyles.HexNumber));
									int_0 += 6;
									continue;
								}
								int_0++;
							}
							catch (IndexOutOfRangeException)
							{
								int_0++;
							}
							catch (ArgumentOutOfRangeException)
							{
								int_0++;
							}
						}
						Class21.Class22 class3 = @class;
						class3.string_0 += string_0[int_0].ToString();
						int_0++;
					}
					int_0++;
				}
			}
			else if (c2 != 'f')
			{
				if (c2 != 't')
				{
					if (c2 != '{')
					{
						goto IL_23E;
					}
					@class = new Class21.Class22((Class21.Class22.Enum9)0);
					int_0++;
					while (string_0[int_0] != '}')
					{
						if (string_0[int_0] == '"')
						{
							Class21.Class22 class4 = Class21.smethod_1(string_0, ref int_0);
							if (string_0[int_0] == ':')
							{
								int_0++;
							}
							Class21.Class22 value = Class21.smethod_1(string_0, ref int_0);
							@class.dictionary_0[class4.string_0] = value;
						}
						else
						{
							int_0++;
						}
					}
					int_0++;
				}
				else
				{
					@class = new Class21.Class22((Class21.Class22.Enum9)2);
					int_0++;
					if (string_0[int_0] == 'r')
					{
						int_0++;
					}
					if (string_0[int_0] == 'u')
					{
						int_0++;
					}
					if (string_0[int_0] == 'e')
					{
						int_0++;
						@class.string_0 = "true";
					}
				}
			}
			else
			{
				@class = new Class21.Class22((Class21.Class22.Enum9)2);
				int_0++;
				if (string_0[int_0] == 'a')
				{
					int_0++;
				}
				if (string_0[int_0] == 'l')
				{
					int_0++;
				}
				if (string_0[int_0] == 's')
				{
					int_0++;
				}
				if (string_0[int_0] == 'e')
				{
					int_0++;
					@class.string_0 = "false";
				}
			}
			while (int_0 < string_0.Length && (char.IsWhiteSpace(string_0[int_0]) || string_0[int_0] == '\r' || string_0[int_0] == '\n'))
			{
				int_0++;
			}
			return @class;
			IL_23E:
			int_0++;
			result = Class21.smethod_1(string_0, ref int_0);
		}
		catch (IndexOutOfRangeException)
		{
			result = new Class21.Class22((Class21.Class22.Enum9)2);
		}
		return result;
	}

	// Token: 0x060002E8 RID: 744 RVA: 0x00005CDC File Offset: 0x00003EDC
	private static bool smethod_2(char char_0)
	{
		return (char_0 >= '0' && char_0 <= '9') || (char_0 >= 'A' && char_0 <= 'F') || (char_0 >= 'a' && char_0 <= 'f');
	}

	// Token: 0x02000095 RID: 149
	public class Class22
	{
		// Token: 0x060002E9 RID: 745 RVA: 0x000165CC File Offset: 0x000147CC
		public Class21.Class22.Enum9 method_0()
		{
			return this.enum9_0;
		}

		// Token: 0x060002EA RID: 746 RVA: 0x00005D05 File Offset: 0x00003F05
		public Class22(Class21.Class22.Enum9 enum9_1)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.enum9_0 = enum9_1;
			this.dictionary_0 = new Dictionary<string, Class21.Class22>();
			this.list_0 = new List<Class21.Class22>();
			this.string_0 = string.Empty;
		}

		// Token: 0x040002B5 RID: 693
		private Class21.Class22.Enum9 enum9_0;

		// Token: 0x040002B6 RID: 694
		public Dictionary<string, Class21.Class22> dictionary_0;

		// Token: 0x040002B7 RID: 695
		public List<Class21.Class22> list_0;

		// Token: 0x040002B8 RID: 696
		public string string_0;

		// Token: 0x02000096 RID: 150
		public enum Enum9
		{

		}
	}
}
