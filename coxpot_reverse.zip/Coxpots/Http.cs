﻿using System;

// Token: 0x02000006 RID: 6
public class Http
{
	// Token: 0x06000015 RID: 21 RVA: 0x0000480C File Offset: 0x00002A0C
	public Http()
	{
		Class35.NkAVmDjz8ZWXG();
		base..ctor();
	}
}
