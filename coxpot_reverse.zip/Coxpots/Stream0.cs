﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Ionic.Crc;
using Ionic.Zlib;

// Token: 0x02000084 RID: 132
internal class Stream0 : Stream
{
	// Token: 0x0600022D RID: 557 RVA: 0x00012EBC File Offset: 0x000110BC
	internal int method_0()
	{
		int result;
		if (this.crc32_0 == null)
		{
			result = 0;
		}
		else
		{
			result = this.crc32_0.Int32_0;
		}
		return result;
	}

	// Token: 0x0600022E RID: 558 RVA: 0x00012EE8 File Offset: 0x000110E8
	public Stream0(Stream stream_1, CompressionMode compressionMode_1, CompressionLevel compressionLevel_1, Enum7 enum7_1, bool bool_2)
	{
		Class35.NkAVmDjz8ZWXG();
		this.zlibCodec_0 = null;
		this.enum8_0 = (Stream0.Enum8)2;
		this.int_0 = 16384;
		this.byte_1 = new byte[1];
		this.compressionStrategy_0 = CompressionStrategy.Default;
		this.bool_1 = false;
		base..ctor();
		this.flushType_0 = FlushType.None;
		this.stream_0 = stream_1;
		this.bool_0 = bool_2;
		this.compressionMode_0 = compressionMode_1;
		this.enum7_0 = enum7_1;
		this.compressionLevel_0 = compressionLevel_1;
		if (enum7_1 == (Enum7)1952)
		{
			this.crc32_0 = new CRC32();
		}
	}

	// Token: 0x0600022F RID: 559 RVA: 0x00005793 File Offset: 0x00003993
	protected internal bool method_1()
	{
		return this.compressionMode_0 == CompressionMode.Compress;
	}

	// Token: 0x06000230 RID: 560 RVA: 0x00012F78 File Offset: 0x00011178
	private ZlibCodec method_2()
	{
		if (this.zlibCodec_0 == null)
		{
			bool flag = this.enum7_0 == (Enum7)1950;
			this.zlibCodec_0 = new ZlibCodec();
			if (this.compressionMode_0 == CompressionMode.Decompress)
			{
				this.zlibCodec_0.InitializeInflate(flag);
			}
			else
			{
				this.zlibCodec_0.Strategy = this.compressionStrategy_0;
				this.zlibCodec_0.InitializeDeflate(this.compressionLevel_0, flag);
			}
		}
		return this.zlibCodec_0;
	}

	// Token: 0x06000231 RID: 561 RVA: 0x00012FF0 File Offset: 0x000111F0
	private byte[] method_3()
	{
		if (this.byte_0 == null)
		{
			this.byte_0 = new byte[this.int_0];
		}
		return this.byte_0;
	}

	// Token: 0x06000232 RID: 562 RVA: 0x00013024 File Offset: 0x00011224
	public override void Write(byte[] buffer, int offset, int count)
	{
		if (this.crc32_0 != null)
		{
			this.crc32_0.SlurpBlock(buffer, offset, count);
		}
		if (this.enum8_0 == (Stream0.Enum8)2)
		{
			this.enum8_0 = (Stream0.Enum8)0;
		}
		else if (this.enum8_0 > (Stream0.Enum8)0)
		{
			throw new ZlibException("Cannot Write after Reading.");
		}
		if (count != 0)
		{
			this.method_2().InputBuffer = buffer;
			this.zlibCodec_0.NextIn = offset;
			this.zlibCodec_0.AvailableBytesIn = count;
			bool flag;
			do
			{
				this.zlibCodec_0.OutputBuffer = this.method_3();
				this.zlibCodec_0.NextOut = 0;
				this.zlibCodec_0.AvailableBytesOut = this.byte_0.Length;
				int num = this.method_1() ? this.zlibCodec_0.Deflate(this.flushType_0) : this.zlibCodec_0.Inflate(this.flushType_0);
				if (num != 0 && num != 1)
				{
					goto IL_179;
				}
				this.stream_0.Write(this.byte_0, 0, this.byte_0.Length - this.zlibCodec_0.AvailableBytesOut);
				flag = (this.zlibCodec_0.AvailableBytesIn == 0 && this.zlibCodec_0.AvailableBytesOut != 0);
				if (this.enum7_0 == (Enum7)1952 && !this.method_1())
				{
					flag = (this.zlibCodec_0.AvailableBytesIn == 8 && this.zlibCodec_0.AvailableBytesOut != 0);
				}
			}
			while (!flag);
			return;
			IL_179:
			throw new ZlibException((this.method_1() ? "de" : "in") + "flating: " + this.zlibCodec_0.Message);
		}
	}

	// Token: 0x06000233 RID: 563 RVA: 0x000131DC File Offset: 0x000113DC
	private void method_4()
	{
		if (this.zlibCodec_0 != null)
		{
			if (this.enum8_0 == (Stream0.Enum8)0)
			{
				bool flag;
				do
				{
					this.zlibCodec_0.OutputBuffer = this.method_3();
					this.zlibCodec_0.NextOut = 0;
					this.zlibCodec_0.AvailableBytesOut = this.byte_0.Length;
					int num = this.method_1() ? this.zlibCodec_0.Deflate(FlushType.Finish) : this.zlibCodec_0.Inflate(FlushType.Finish);
					if (num != 1 && num != 0)
					{
						goto IL_135;
					}
					if (this.byte_0.Length - this.zlibCodec_0.AvailableBytesOut > 0)
					{
						this.stream_0.Write(this.byte_0, 0, this.byte_0.Length - this.zlibCodec_0.AvailableBytesOut);
					}
					flag = (this.zlibCodec_0.AvailableBytesIn == 0 && this.zlibCodec_0.AvailableBytesOut != 0);
					if (this.enum7_0 == (Enum7)1952 && !this.method_1())
					{
						flag = (this.zlibCodec_0.AvailableBytesIn == 8 && this.zlibCodec_0.AvailableBytesOut != 0);
					}
				}
				while (!flag);
				this.Flush();
				if (this.enum7_0 != (Enum7)1952)
				{
					return;
				}
				if (this.method_1())
				{
					int int32_ = this.crc32_0.Int32_0;
					this.stream_0.Write(BitConverter.GetBytes(int32_), 0, 4);
					int value = (int)(this.crc32_0.TotalBytesRead & 4294967295L);
					this.stream_0.Write(BitConverter.GetBytes(value), 0, 4);
					return;
				}
				throw new ZlibException("Writing with decompression is not supported.");
				IL_135:
				string text = (this.method_1() ? "de" : "in") + "flating";
				if (this.zlibCodec_0.Message == null)
				{
					int num;
					throw new ZlibException(string.Format("{0}: (rc = {1})", text, num));
				}
				throw new ZlibException(text + ": " + this.zlibCodec_0.Message);
			}
			else if (this.enum8_0 == (Stream0.Enum8)1 && this.enum7_0 == (Enum7)1952)
			{
				if (this.method_1())
				{
					throw new ZlibException("Reading with compression is not supported.");
				}
				if (this.zlibCodec_0.TotalBytesOut != 0L)
				{
					byte[] array = new byte[8];
					if (this.zlibCodec_0.AvailableBytesIn < 8)
					{
						Array.Copy(this.zlibCodec_0.InputBuffer, this.zlibCodec_0.NextIn, array, 0, this.zlibCodec_0.AvailableBytesIn);
						int num2 = 8 - this.zlibCodec_0.AvailableBytesIn;
						int num3 = this.stream_0.Read(array, this.zlibCodec_0.AvailableBytesIn, num2);
						if (num2 != num3)
						{
							throw new ZlibException(string.Format("Missing or incomplete GZIP trailer. Expected 8 bytes, got {0}.", this.zlibCodec_0.AvailableBytesIn + num3));
						}
					}
					else
					{
						Array.Copy(this.zlibCodec_0.InputBuffer, this.zlibCodec_0.NextIn, array, 0, array.Length);
					}
					int num4 = BitConverter.ToInt32(array, 0);
					int int32_2 = this.crc32_0.Int32_0;
					int num5 = BitConverter.ToInt32(array, 4);
					int num6 = (int)(this.zlibCodec_0.TotalBytesOut & 4294967295L);
					if (int32_2 != num4)
					{
						throw new ZlibException(string.Format("Bad CRC32 in GZIP trailer. (actual({0:X8})!=expected({1:X8}))", int32_2, num4));
					}
					if (num6 != num5)
					{
						throw new ZlibException(string.Format("Bad size in GZIP trailer. (actual({0})!=expected({1}))", num6, num5));
					}
				}
			}
		}
	}

	// Token: 0x06000234 RID: 564 RVA: 0x0000579E File Offset: 0x0000399E
	private void method_5()
	{
		if (this.method_2() != null)
		{
			if (this.method_1())
			{
				this.zlibCodec_0.EndDeflate();
			}
			else
			{
				this.zlibCodec_0.EndInflate();
			}
			this.zlibCodec_0 = null;
		}
	}

	// Token: 0x06000235 RID: 565 RVA: 0x00013594 File Offset: 0x00011794
	public override void Close()
	{
		if (this.stream_0 != null)
		{
			try
			{
				this.method_4();
			}
			finally
			{
				this.method_5();
				if (!this.bool_0)
				{
					this.stream_0.Close();
				}
				this.stream_0 = null;
			}
		}
	}

	// Token: 0x06000236 RID: 566 RVA: 0x000057D4 File Offset: 0x000039D4
	public override void Flush()
	{
		this.stream_0.Flush();
	}

	// Token: 0x06000237 RID: 567 RVA: 0x00005599 File Offset: 0x00003799
	public override long Seek(long offset, SeekOrigin origin)
	{
		throw new NotImplementedException();
	}

	// Token: 0x06000238 RID: 568 RVA: 0x000057E1 File Offset: 0x000039E1
	public override void SetLength(long value)
	{
		this.stream_0.SetLength(value);
	}

	// Token: 0x06000239 RID: 569 RVA: 0x000135EC File Offset: 0x000117EC
	private string method_6()
	{
		List<byte> list = new List<byte>();
		bool flag = false;
		for (;;)
		{
			int num = this.stream_0.Read(this.byte_1, 0, 1);
			if (num != 1)
			{
				break;
			}
			if (this.byte_1[0] == 0)
			{
				flag = true;
			}
			else
			{
				list.Add(this.byte_1[0]);
			}
			if (flag)
			{
				goto IL_57;
			}
		}
		throw new ZlibException("Unexpected EOF reading GZIP header.");
		IL_57:
		byte[] array = list.ToArray();
		return GZipStream.xnfuafYhhW.GetString(array, 0, array.Length);
	}

	// Token: 0x0600023A RID: 570 RVA: 0x0001366C File Offset: 0x0001186C
	private int method_7()
	{
		int num = 0;
		byte[] array = new byte[10];
		int num2 = this.stream_0.Read(array, 0, array.Length);
		int result;
		if (num2 == 0)
		{
			result = 0;
		}
		else
		{
			if (num2 != 10)
			{
				throw new ZlibException("Not a valid GZIP stream.");
			}
			if (array[0] != 31 || array[1] != 139 || array[2] != 8)
			{
				throw new ZlibException("Bad GZIP header.");
			}
			int num3 = BitConverter.ToInt32(array, 4);
			this.dateTime_0 = GZipStream.dateTime_0.AddSeconds((double)num3);
			num += num2;
			if ((array[3] & 4) == 4)
			{
				num2 = this.stream_0.Read(array, 0, 2);
				num += num2;
				short num4 = (short)((int)array[0] + (int)array[1] * 256);
				byte[] array2 = new byte[(int)num4];
				num2 = this.stream_0.Read(array2, 0, array2.Length);
				if (num2 != (int)num4)
				{
					throw new ZlibException("Unexpected end-of-file reading GZIP header.");
				}
				num += num2;
			}
			if ((array[3] & 8) == 8)
			{
				this.string_0 = this.method_6();
			}
			if ((array[3] & 16) == 16)
			{
				this.string_1 = this.method_6();
			}
			if ((array[3] & 2) == 2)
			{
				this.Read(this.byte_1, 0, 1);
			}
			result = num;
		}
		return result;
	}

	// Token: 0x0600023B RID: 571 RVA: 0x000137B0 File Offset: 0x000119B0
	public override int Read(byte[] buffer, int offset, int count)
	{
		if (this.enum8_0 == (Stream0.Enum8)2)
		{
			if (!this.stream_0.CanRead)
			{
				throw new ZlibException("The stream is not readable.");
			}
			this.enum8_0 = (Stream0.Enum8)1;
			this.method_2().AvailableBytesIn = 0;
			if (this.enum7_0 == (Enum7)1952)
			{
				this.int_1 = this.method_7();
				if (this.int_1 == 0)
				{
					return 0;
				}
			}
		}
		if (this.enum8_0 != (Stream0.Enum8)1)
		{
			throw new ZlibException("Cannot Read after Writing.");
		}
		int result;
		if (count == 0)
		{
			result = 0;
		}
		else if (this.bool_1 && this.method_1())
		{
			result = 0;
		}
		else
		{
			if (buffer == null)
			{
				throw new ArgumentNullException("buffer");
			}
			if (count < 0)
			{
				throw new ArgumentOutOfRangeException("count");
			}
			if (offset < buffer.GetLowerBound(0))
			{
				throw new ArgumentOutOfRangeException("offset");
			}
			if (offset + count > buffer.GetLength(0))
			{
				throw new ArgumentOutOfRangeException("count");
			}
			this.zlibCodec_0.OutputBuffer = buffer;
			this.zlibCodec_0.NextOut = offset;
			this.zlibCodec_0.AvailableBytesOut = count;
			this.zlibCodec_0.InputBuffer = this.method_3();
			int num;
			for (;;)
			{
				if (this.zlibCodec_0.AvailableBytesIn == 0 && !this.bool_1)
				{
					this.zlibCodec_0.NextIn = 0;
					this.zlibCodec_0.AvailableBytesIn = this.stream_0.Read(this.byte_0, 0, this.byte_0.Length);
					if (this.zlibCodec_0.AvailableBytesIn == 0)
					{
						this.bool_1 = true;
					}
				}
				num = (this.method_1() ? this.zlibCodec_0.Deflate(this.flushType_0) : this.zlibCodec_0.Inflate(this.flushType_0));
				if (this.bool_1 && num == -5)
				{
					goto IL_22F;
				}
				if (num == 0 || num == 1)
				{
					if (this.bool_1)
					{
						goto IL_1DE;
					}
					if (num == 1)
					{
						goto IL_1DE;
					}
					bool flag = false;
					IL_1EC:
					if (flag)
					{
						break;
					}
					if (this.zlibCodec_0.AvailableBytesOut <= 0 || this.bool_1 || num != 0)
					{
						break;
					}
					continue;
					IL_1DE:
					flag = (this.zlibCodec_0.AvailableBytesOut == count);
					goto IL_1EC;
				}
				goto IL_236;
			}
			goto IL_26B;
			IL_22F:
			return 0;
			IL_236:
			throw new ZlibException(string.Format("{0}flating:  rc={1}  msg={2}", this.method_1() ? "de" : "in", num, this.zlibCodec_0.Message));
			IL_26B:
			if (this.zlibCodec_0.AvailableBytesOut > 0)
			{
				if (num != 0 || this.zlibCodec_0.AvailableBytesIn != 0)
				{
				}
				if (this.bool_1 && this.method_1())
				{
					num = this.zlibCodec_0.Deflate(FlushType.Finish);
					if (num != 0 && num != 1)
					{
						throw new ZlibException(string.Format("Deflating:  rc={0}  msg={1}", num, this.zlibCodec_0.Message));
					}
				}
			}
			num = count - this.zlibCodec_0.AvailableBytesOut;
			if (this.crc32_0 != null)
			{
				this.crc32_0.SlurpBlock(buffer, offset, num);
			}
			result = num;
		}
		return result;
	}

	// Token: 0x17000048 RID: 72
	// (get) Token: 0x0600023C RID: 572 RVA: 0x000057EF File Offset: 0x000039EF
	public override bool CanRead
	{
		get
		{
			return this.stream_0.CanRead;
		}
	}

	// Token: 0x17000049 RID: 73
	// (get) Token: 0x0600023D RID: 573 RVA: 0x000057FC File Offset: 0x000039FC
	public override bool CanSeek
	{
		get
		{
			return this.stream_0.CanSeek;
		}
	}

	// Token: 0x1700004A RID: 74
	// (get) Token: 0x0600023E RID: 574 RVA: 0x00005809 File Offset: 0x00003A09
	public override bool CanWrite
	{
		get
		{
			return this.stream_0.CanWrite;
		}
	}

	// Token: 0x1700004B RID: 75
	// (get) Token: 0x0600023F RID: 575 RVA: 0x00013AC8 File Offset: 0x00011CC8
	public override long Length
	{
		get
		{
			return this.stream_0.Length;
		}
	}

	// Token: 0x1700004C RID: 76
	// (get) Token: 0x06000240 RID: 576 RVA: 0x00005599 File Offset: 0x00003799
	// (set) Token: 0x06000241 RID: 577 RVA: 0x00005599 File Offset: 0x00003799
	public override long Position
	{
		get
		{
			throw new NotImplementedException();
		}
		set
		{
			throw new NotImplementedException();
		}
	}

	// Token: 0x06000242 RID: 578 RVA: 0x00013AE4 File Offset: 0x00011CE4
	public static void smethod_0(string string_2, Stream stream_1)
	{
		byte[] bytes = Encoding.UTF8.GetBytes(string_2);
		try
		{
			stream_1.Write(bytes, 0, bytes.Length);
		}
		finally
		{
			if (stream_1 != null)
			{
				((IDisposable)stream_1).Dispose();
			}
		}
	}

	// Token: 0x06000243 RID: 579 RVA: 0x00013B28 File Offset: 0x00011D28
	public static void smethod_1(byte[] byte_2, Stream stream_1)
	{
		try
		{
			stream_1.Write(byte_2, 0, byte_2.Length);
		}
		finally
		{
			if (stream_1 != null)
			{
				((IDisposable)stream_1).Dispose();
			}
		}
	}

	// Token: 0x06000244 RID: 580 RVA: 0x00013B60 File Offset: 0x00011D60
	public static string smethod_2(byte[] byte_2, Stream stream_1)
	{
		byte[] array = new byte[1024];
		Encoding utf = Encoding.UTF8;
		string result;
		using (MemoryStream memoryStream = new MemoryStream())
		{
			try
			{
				int count;
				while ((count = stream_1.Read(array, 0, array.Length)) != 0)
				{
					memoryStream.Write(array, 0, count);
				}
			}
			finally
			{
				if (stream_1 != null)
				{
					((IDisposable)stream_1).Dispose();
				}
			}
			memoryStream.Seek(0L, SeekOrigin.Begin);
			StreamReader streamReader = new StreamReader(memoryStream, utf);
			result = streamReader.ReadToEnd();
		}
		return result;
	}

	// Token: 0x06000245 RID: 581 RVA: 0x00013C00 File Offset: 0x00011E00
	public static byte[] smethod_3(byte[] byte_2, Stream stream_1)
	{
		byte[] array = new byte[1024];
		byte[] result;
		using (MemoryStream memoryStream = new MemoryStream())
		{
			try
			{
				int count;
				while ((count = stream_1.Read(array, 0, array.Length)) != 0)
				{
					memoryStream.Write(array, 0, count);
				}
			}
			finally
			{
				if (stream_1 != null)
				{
					((IDisposable)stream_1).Dispose();
				}
			}
			result = memoryStream.ToArray();
		}
		return result;
	}

	// Token: 0x04000267 RID: 615
	protected internal ZlibCodec zlibCodec_0;

	// Token: 0x04000268 RID: 616
	protected internal Stream0.Enum8 enum8_0;

	// Token: 0x04000269 RID: 617
	protected internal FlushType flushType_0;

	// Token: 0x0400026A RID: 618
	protected internal Enum7 enum7_0;

	// Token: 0x0400026B RID: 619
	protected internal CompressionMode compressionMode_0;

	// Token: 0x0400026C RID: 620
	protected internal CompressionLevel compressionLevel_0;

	// Token: 0x0400026D RID: 621
	protected internal bool bool_0;

	// Token: 0x0400026E RID: 622
	protected internal byte[] byte_0;

	// Token: 0x0400026F RID: 623
	protected internal int int_0;

	// Token: 0x04000270 RID: 624
	protected internal byte[] byte_1;

	// Token: 0x04000271 RID: 625
	protected internal Stream stream_0;

	// Token: 0x04000272 RID: 626
	protected internal CompressionStrategy compressionStrategy_0;

	// Token: 0x04000273 RID: 627
	private CRC32 crc32_0;

	// Token: 0x04000274 RID: 628
	protected internal string string_0;

	// Token: 0x04000275 RID: 629
	protected internal string string_1;

	// Token: 0x04000276 RID: 630
	protected internal DateTime dateTime_0;

	// Token: 0x04000277 RID: 631
	protected internal int int_1;

	// Token: 0x04000278 RID: 632
	private bool bool_1;

	// Token: 0x02000085 RID: 133
	internal enum Enum8
	{

	}
}
