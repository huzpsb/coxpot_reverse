﻿using System;
using Ionic.Zlib;

// Token: 0x0200006E RID: 110
internal sealed class Class2
{
	// Token: 0x060001A8 RID: 424 RVA: 0x0000BFF0 File Offset: 0x0000A1F0
	internal Class2()
	{
		Class35.NkAVmDjz8ZWXG();
		this.class9_0 = new Class9();
		this.class9_1 = new Class9();
		this.class9_2 = new Class9();
		this.short_5 = new short[Class11.int_0 + 1];
		this.int_39 = new int[2 * Class11.int_5 + 1];
		this.sbyte_1 = new sbyte[2 * Class11.int_5 + 1];
		this.bool_0 = false;
		this.bool_1 = true;
		base..ctor();
		this.short_2 = new short[Class2.int_16 * 2];
		this.short_3 = new short[(2 * Class11.int_2 + 1) * 2];
		this.short_4 = new short[(2 * Class11.int_1 + 1) * 2];
	}

	// Token: 0x060001A9 RID: 425 RVA: 0x0000C0B0 File Offset: 0x0000A2B0
	private void method_0()
	{
		this.int_25 = 2 * this.int_22;
		Array.Clear(this.short_1, 0, this.int_27);
		this.class3_0 = Class2.Class3.smethod_0(this.Rqvufksjgj);
		this.method_34();
		this.int_35 = 0;
		this.int_31 = 0;
		this.int_37 = 0;
		this.int_32 = (this.int_38 = Class2.int_13 - 1);
		this.int_34 = 0;
		this.int_26 = 0;
	}

	// Token: 0x060001AA RID: 426 RVA: 0x0000C130 File Offset: 0x0000A330
	private void method_1()
	{
		this.class9_0.short_0 = this.short_2;
		this.class9_0.class12_0 = Class12.class12_0;
		this.class9_1.short_0 = this.short_3;
		this.class9_1.class12_0 = Class12.class12_1;
		this.class9_2.short_0 = this.short_4;
		this.class9_2.class12_0 = Class12.class12_2;
		this.short_6 = 0;
		this.int_47 = 0;
		this.int_46 = 8;
		this.method_2();
	}

	// Token: 0x060001AB RID: 427 RVA: 0x0000C1BC File Offset: 0x0000A3BC
	internal void method_2()
	{
		for (int i = 0; i < Class11.int_5; i++)
		{
			this.short_2[i * 2] = 0;
		}
		for (int j = 0; j < Class11.int_2; j++)
		{
			this.short_3[j * 2] = 0;
		}
		for (int k = 0; k < Class11.int_1; k++)
		{
			this.short_4[k * 2] = 0;
		}
		this.short_2[Class2.int_17 * 2] = 1;
		this.IyxuFiuMr8 = 0;
		this.int_44 = 0;
		this.int_45 = 0;
		this.int_42 = 0;
	}

	// Token: 0x060001AC RID: 428 RVA: 0x0000C24C File Offset: 0x0000A44C
	internal void method_3(short[] short_7, int int_48)
	{
		int num = this.int_39[int_48];
		for (int i = int_48 << 1; i <= this.int_40; i <<= 1)
		{
			if (i < this.int_40 && Class2.smethod_0(short_7, this.int_39[i + 1], this.int_39[i], this.sbyte_1))
			{
				i++;
			}
			if (Class2.smethod_0(short_7, num, this.int_39[i], this.sbyte_1))
			{
				break;
			}
			this.int_39[int_48] = this.int_39[i];
			int_48 = i;
		}
		this.int_39[int_48] = num;
	}

	// Token: 0x060001AD RID: 429 RVA: 0x0000C2E0 File Offset: 0x0000A4E0
	internal static bool smethod_0(short[] short_7, int int_48, int int_49, sbyte[] sbyte_2)
	{
		short num = short_7[int_48 * 2];
		short num2 = short_7[int_49 * 2];
		return num < num2 || (num == num2 && sbyte_2[int_48] <= sbyte_2[int_49]);
	}

	// Token: 0x060001AE RID: 430 RVA: 0x0000C314 File Offset: 0x0000A514
	internal void method_4(short[] short_7, int int_48)
	{
		int num = -1;
		int num2 = (int)short_7[1];
		int num3 = 0;
		int num4 = 7;
		int num5 = 4;
		if (num2 == 0)
		{
			num4 = 138;
			num5 = 3;
		}
		short_7[(int_48 + 1) * 2 + 1] = short.MaxValue;
		for (int i = 0; i <= int_48; i++)
		{
			int num6 = num2;
			num2 = (int)short_7[(i + 1) * 2 + 1];
			if (++num3 >= num4 || num6 != num2)
			{
				if (num3 < num5)
				{
					this.short_4[num6 * 2] = (short)((int)this.short_4[num6 * 2] + num3);
				}
				else if (num6 != 0)
				{
					if (num6 != num)
					{
						short[] array = this.short_4;
						int num7 = num6 * 2;
						array[num7] += 1;
					}
					short[] array2 = this.short_4;
					int num8 = Class11.int_7 * 2;
					array2[num8] += 1;
				}
				else if (num3 <= 10)
				{
					short[] array3 = this.short_4;
					int num9 = Class11.int_8 * 2;
					array3[num9] += 1;
				}
				else
				{
					short[] array4 = this.short_4;
					int num10 = Class11.int_9 * 2;
					array4[num10] += 1;
				}
				num3 = 0;
				num = num6;
				if (num2 == 0)
				{
					num4 = 138;
					num5 = 3;
				}
				else if (num6 == num2)
				{
					num4 = 6;
					num5 = 3;
				}
				else
				{
					num4 = 7;
					num5 = 4;
				}
			}
		}
	}

	// Token: 0x060001AF RID: 431 RVA: 0x0000C450 File Offset: 0x0000A650
	internal int method_5()
	{
		this.method_4(this.short_2, this.class9_0.int_6);
		this.method_4(this.short_3, this.class9_1.int_6);
		this.class9_2.method_1(this);
		int num = Class11.int_1 - 1;
		while (num >= 3 && this.short_4[(int)(Class9.sbyte_0[num] * 2 + 1)] == 0)
		{
			num--;
		}
		this.int_44 += 3 * (num + 1) + 5 + 5 + 4;
		return num;
	}

	// Token: 0x060001B0 RID: 432 RVA: 0x0000C4E0 File Offset: 0x0000A6E0
	internal void method_6(int int_48, int int_49, int int_50)
	{
		this.method_10(int_48 - 257, 5);
		this.method_10(int_49 - 1, 5);
		this.method_10(int_50 - 4, 4);
		for (int i = 0; i < int_50; i++)
		{
			this.method_10((int)this.short_4[(int)(Class9.sbyte_0[i] * 2 + 1)], 3);
		}
		this.method_7(this.short_2, int_48 - 1);
		this.method_7(this.short_3, int_49 - 1);
	}

	// Token: 0x060001B1 RID: 433 RVA: 0x0000C554 File Offset: 0x0000A754
	internal void method_7(short[] short_7, int int_48)
	{
		int num = -1;
		int num2 = (int)short_7[1];
		int num3 = 0;
		int num4 = 7;
		int num5 = 4;
		if (num2 == 0)
		{
			num4 = 138;
			num5 = 3;
		}
		for (int i = 0; i <= int_48; i++)
		{
			int num6 = num2;
			num2 = (int)short_7[(i + 1) * 2 + 1];
			if (++num3 >= num4 || num6 != num2)
			{
				if (num3 < num5)
				{
					do
					{
						this.method_9(num6, this.short_4);
					}
					while (--num3 != 0);
				}
				else if (num6 != 0)
				{
					if (num6 != num)
					{
						this.method_9(num6, this.short_4);
						num3--;
					}
					this.method_9(Class11.int_7, this.short_4);
					this.method_10(num3 - 3, 2);
				}
				else if (num3 <= 10)
				{
					this.method_9(Class11.int_8, this.short_4);
					this.method_10(num3 - 3, 3);
				}
				else
				{
					this.method_9(Class11.int_9, this.short_4);
					this.method_10(num3 - 11, 7);
				}
				num3 = 0;
				num = num6;
				if (num2 == 0)
				{
					num4 = 138;
					num5 = 3;
				}
				else if (num6 == num2)
				{
					num4 = 6;
					num5 = 3;
				}
				else
				{
					num4 = 7;
					num5 = 4;
				}
			}
		}
	}

	// Token: 0x060001B2 RID: 434 RVA: 0x000053D3 File Offset: 0x000035D3
	private void method_8(byte[] byte_2, int int_48, int int_49)
	{
		Array.Copy(byte_2, int_48, this.byte_0, this.int_20, int_49);
		this.int_20 += int_49;
	}

	// Token: 0x060001B3 RID: 435 RVA: 0x0000C68C File Offset: 0x0000A88C
	internal void method_9(int int_48, short[] short_7)
	{
		int num = int_48 * 2;
		this.method_10((int)short_7[num] & 65535, (int)short_7[num + 1] & 65535);
	}

	// Token: 0x060001B4 RID: 436 RVA: 0x0000C6B8 File Offset: 0x0000A8B8
	internal void method_10(int int_48, int int_49)
	{
		if (this.int_47 > Class2.int_12 - int_49)
		{
			this.short_6 |= (short)(int_48 << this.int_47 & 65535);
			byte[] array = this.byte_0;
			int num = this.int_20;
			this.int_20 = num + 1;
			array[num] = (byte)this.short_6;
			byte[] array2 = this.byte_0;
			num = this.int_20;
			this.int_20 = num + 1;
			array2[num] = (byte)(this.short_6 >> 8);
			this.short_6 = (short)((uint)int_48 >> Class2.int_12 - this.int_47);
			this.int_47 += int_49 - Class2.int_12;
		}
		else
		{
			this.short_6 |= (short)(int_48 << this.int_47 & 65535);
			this.int_47 += int_49;
		}
	}

	// Token: 0x060001B5 RID: 437 RVA: 0x0000C798 File Offset: 0x0000A998
	internal void method_11()
	{
		this.method_10(Class2.int_8 << 1, 3);
		this.method_9(Class2.int_17, Class12.short_0);
		this.method_15();
		if (1 + this.int_46 + 10 - this.int_47 < 9)
		{
			this.method_10(Class2.int_8 << 1, 3);
			this.method_9(Class2.int_17, Class12.short_0);
			this.method_15();
		}
		this.int_46 = 7;
	}

	// Token: 0x060001B6 RID: 438 RVA: 0x0000C80C File Offset: 0x0000AA0C
	internal bool method_12(int int_48, int int_49)
	{
		this.byte_0[this.int_43 + this.int_42 * 2] = (byte)((uint)int_48 >> 8);
		this.byte_0[this.int_43 + this.int_42 * 2 + 1] = (byte)int_48;
		this.byte_0[this.EkEunrkoBw + this.int_42] = (byte)int_49;
		this.int_42++;
		if (int_48 == 0)
		{
			short[] array = this.short_2;
			int num = int_49 * 2;
			array[num] += 1;
		}
		else
		{
			this.int_45++;
			int_48--;
			short[] array2 = this.short_2;
			int num2 = ((int)Class9.sbyte_2[int_49] + Class11.int_3 + 1) * 2;
			array2[num2] += 1;
			short[] array3 = this.short_3;
			int num3 = Class9.smethod_0(int_48) * 2;
			array3[num3] += 1;
		}
		if ((this.int_42 & 8191) == 0 && this.Rqvufksjgj > CompressionLevel.Level2)
		{
			int num4 = this.int_42 << 3;
			int num5 = this.int_35 - this.int_31;
			for (int i = 0; i < Class11.int_2; i++)
			{
				num4 = (int)((long)num4 + (long)this.short_3[i * 2] * (5L + (long)Class9.int_2[i]));
			}
			num4 >>= 3;
			if (this.int_45 < this.int_42 / 2 && num4 < num5 / 2)
			{
				return true;
			}
		}
		return this.int_42 == this.int_41 - 1 || this.int_42 == this.int_41;
	}

	// Token: 0x060001B7 RID: 439 RVA: 0x0000C98C File Offset: 0x0000AB8C
	internal void method_13(short[] short_7, short[] short_8)
	{
		int num = 0;
		if (this.int_42 != 0)
		{
			do
			{
				int num2 = this.int_43 + num * 2;
				int num3 = ((int)this.byte_0[num2] << 8 & 65280) | (int)(this.byte_0[num2 + 1] & byte.MaxValue);
				int num4 = (int)(this.byte_0[this.EkEunrkoBw + num] & byte.MaxValue);
				num++;
				if (num3 == 0)
				{
					this.method_9(num4, short_7);
				}
				else
				{
					int num5 = (int)Class9.sbyte_2[num4];
					this.method_9(num5 + Class11.int_3 + 1, short_7);
					int num6 = Class9.int_1[num5];
					if (num6 != 0)
					{
						num4 -= Class9.int_4[num5];
						this.method_10(num4, num6);
					}
					num3--;
					num5 = Class9.smethod_0(num3);
					this.method_9(num5, short_8);
					num6 = Class9.int_2[num5];
					if (num6 != 0)
					{
						num3 -= Class9.int_5[num5];
						this.method_10(num3, num6);
					}
				}
			}
			while (num < this.int_42);
		}
		this.method_9(Class2.int_17, short_7);
		this.int_46 = (int)short_7[Class2.int_17 * 2 + 1];
	}

	// Token: 0x060001B8 RID: 440 RVA: 0x0000CAAC File Offset: 0x0000ACAC
	internal void method_14()
	{
		int i = 0;
		int num = 0;
		int num2 = 0;
		while (i < 7)
		{
			num2 += (int)this.short_2[i * 2];
			i++;
		}
		while (i < 128)
		{
			num += (int)this.short_2[i * 2];
			i++;
		}
		while (i < Class11.int_3)
		{
			num2 += (int)this.short_2[i * 2];
			i++;
		}
		this.sbyte_0 = (sbyte)((num2 > num >> 2) ? Class2.int_9 : Class2.int_10);
	}

	// Token: 0x060001B9 RID: 441 RVA: 0x0000CB2C File Offset: 0x0000AD2C
	internal void method_15()
	{
		if (this.int_47 == 16)
		{
			byte[] array = this.byte_0;
			int num = this.int_20;
			this.int_20 = num + 1;
			array[num] = (byte)this.short_6;
			byte[] array2 = this.byte_0;
			num = this.int_20;
			this.int_20 = num + 1;
			array2[num] = (byte)(this.short_6 >> 8);
			this.short_6 = 0;
			this.int_47 = 0;
		}
		else if (this.int_47 >= 8)
		{
			byte[] array3 = this.byte_0;
			int num = this.int_20;
			this.int_20 = num + 1;
			array3[num] = (byte)this.short_6;
			this.short_6 = (short)(this.short_6 >> 8);
			this.int_47 -= 8;
		}
	}

	// Token: 0x060001BA RID: 442 RVA: 0x0000CBE0 File Offset: 0x0000ADE0
	internal void method_16()
	{
		if (this.int_47 > 8)
		{
			byte[] array = this.byte_0;
			int num = this.int_20;
			this.int_20 = num + 1;
			array[num] = (byte)this.short_6;
			byte[] array2 = this.byte_0;
			num = this.int_20;
			this.int_20 = num + 1;
			array2[num] = (byte)(this.short_6 >> 8);
		}
		else if (this.int_47 > 0)
		{
			byte[] array3 = this.byte_0;
			int num = this.int_20;
			this.int_20 = num + 1;
			array3[num] = (byte)this.short_6;
		}
		this.short_6 = 0;
		this.int_47 = 0;
	}

	// Token: 0x060001BB RID: 443 RVA: 0x0000CC74 File Offset: 0x0000AE74
	internal void method_17(int int_48, int int_49, bool bool_2)
	{
		this.method_16();
		this.int_46 = 8;
		if (bool_2)
		{
			byte[] array = this.byte_0;
			int num = this.int_20;
			this.int_20 = num + 1;
			array[num] = (byte)int_49;
			byte[] array2 = this.byte_0;
			num = this.int_20;
			this.int_20 = num + 1;
			array2[num] = (byte)(int_49 >> 8);
			byte[] array3 = this.byte_0;
			num = this.int_20;
			this.int_20 = num + 1;
			array3[num] = (byte)(~(byte)int_49);
			byte[] array4 = this.byte_0;
			num = this.int_20;
			this.int_20 = num + 1;
			array4[num] = (byte)(~int_49 >> 8);
		}
		this.method_8(this.byte_1, int_48, int_49);
	}

	// Token: 0x060001BC RID: 444 RVA: 0x000053F7 File Offset: 0x000035F7
	internal void method_18(bool bool_2)
	{
		this.method_21((this.int_31 >= 0) ? this.int_31 : -1, this.int_35 - this.int_31, bool_2);
		this.int_31 = this.int_35;
		this.zlibCodec_0.method_0();
	}

	// Token: 0x060001BD RID: 445 RVA: 0x0000CD10 File Offset: 0x0000AF10
	internal Enum3 method_19(FlushType flushType_0)
	{
		int num = 65535;
		if (65535 > this.byte_0.Length - 5)
		{
			num = this.byte_0.Length - 5;
		}
		for (;;)
		{
			if (this.int_37 <= 1)
			{
				this.method_22();
				if (this.int_37 == 0 && flushType_0 == FlushType.None)
				{
					goto IL_10A;
				}
				if (this.int_37 == 0)
				{
					goto Block_8;
				}
			}
			this.int_35 += this.int_37;
			this.int_37 = 0;
			int num2 = this.int_31 + num;
			if (this.int_35 == 0 || this.int_35 >= num2)
			{
				this.int_37 = this.int_35 - num2;
				this.int_35 = num2;
				this.method_18(false);
				if (this.zlibCodec_0.AvailableBytesOut == 0)
				{
					goto IL_13E;
				}
			}
			if (this.int_35 - this.int_31 >= this.int_22 - Class2.int_15)
			{
				this.method_18(false);
				if (this.zlibCodec_0.AvailableBytesOut == 0)
				{
					break;
				}
			}
		}
		return (Enum3)0;
		Block_8:
		this.method_18(flushType_0 == FlushType.Finish);
		if (this.zlibCodec_0.AvailableBytesOut == 0)
		{
			return (flushType_0 == FlushType.Finish) ? ((Enum3)2) : ((Enum3)0);
		}
		return (flushType_0 == FlushType.Finish) ? ((Enum3)3) : ((Enum3)1);
		IL_10A:
		return (Enum3)0;
		IL_13E:
		return (Enum3)0;
	}

	// Token: 0x060001BE RID: 446 RVA: 0x00005436 File Offset: 0x00003636
	internal void method_20(int int_48, int int_49, bool bool_2)
	{
		this.method_10((Class2.int_7 << 1) + (bool_2 ? 1 : 0), 3);
		this.method_17(int_48, int_49, true);
	}

	// Token: 0x060001BF RID: 447 RVA: 0x0000CE64 File Offset: 0x0000B064
	internal void method_21(int int_48, int int_49, bool bool_2)
	{
		int num = 0;
		int num2;
		int num3;
		if (this.Rqvufksjgj > CompressionLevel.None)
		{
			if ((int)this.sbyte_0 == Class2.int_11)
			{
				this.method_14();
			}
			this.class9_0.method_1(this);
			this.class9_1.method_1(this);
			num = this.method_5();
			num2 = this.int_44 + 3 + 7 >> 3;
			num3 = this.IyxuFiuMr8 + 3 + 7 >> 3;
			if (num3 <= num2)
			{
				num2 = num3;
			}
		}
		else
		{
			num3 = (num2 = int_49 + 5);
		}
		if (int_49 + 4 <= num2 && int_48 != -1)
		{
			this.method_20(int_48, int_49, bool_2);
		}
		else if (num3 == num2)
		{
			this.method_10((Class2.int_8 << 1) + (bool_2 ? 1 : 0), 3);
			this.method_13(Class12.short_0, Class12.short_1);
		}
		else
		{
			this.method_10((Class2.AuxYvteyLw << 1) + (bool_2 ? 1 : 0), 3);
			this.method_6(this.class9_0.int_6 + 1, this.class9_1.int_6 + 1, num + 1);
			this.method_13(this.short_2, this.short_3);
		}
		this.method_2();
		if (bool_2)
		{
			this.method_16();
		}
	}

	// Token: 0x060001C0 RID: 448 RVA: 0x0000CF84 File Offset: 0x0000B184
	private void method_22()
	{
		do
		{
			int num = this.int_25 - this.int_37 - this.int_35;
			int num2;
			if (num == 0 && this.int_35 == 0 && this.int_37 == 0)
			{
				num = this.int_22;
			}
			else if (num == -1)
			{
				num--;
			}
			else if (this.int_35 >= this.int_22 + this.int_22 - Class2.int_15)
			{
				Array.Copy(this.byte_1, this.int_22, this.byte_1, 0, this.int_22);
				this.int_36 -= this.int_22;
				this.int_35 -= this.int_22;
				this.int_31 -= this.int_22;
				num2 = this.int_27;
				int num3 = num2;
				do
				{
					int num4 = (int)this.short_1[--num3] & 65535;
					this.short_1[num3] = (short)((num4 < this.int_22) ? 0 : (num4 - this.int_22));
				}
				while (--num2 != 0);
				num2 = this.int_22;
				num3 = num2;
				do
				{
					int num4 = (int)this.short_0[--num3] & 65535;
					this.short_0[num3] = (short)((num4 < this.int_22) ? 0 : (num4 - this.int_22));
				}
				while (--num2 != 0);
				num += this.int_22;
			}
			if (this.zlibCodec_0.AvailableBytesIn == 0)
			{
				break;
			}
			num2 = this.zlibCodec_0.method_1(this.byte_1, this.int_35 + this.int_37, num);
			this.int_37 += num2;
			if (this.int_37 >= Class2.int_13)
			{
				this.int_26 = (int)(this.byte_1[this.int_35] & byte.MaxValue);
				this.int_26 = ((this.int_26 << this.int_30 ^ (int)(this.byte_1[this.int_35 + 1] & byte.MaxValue)) & this.int_29);
			}
		}
		while (this.int_37 < Class2.int_15 && this.zlibCodec_0.AvailableBytesIn != 0);
	}

	// Token: 0x060001C1 RID: 449 RVA: 0x0000D1BC File Offset: 0x0000B3BC
	internal Enum3 method_23(FlushType flushType_0)
	{
		int num = 0;
		for (;;)
		{
			if (this.int_37 < Class2.int_15)
			{
				this.method_22();
				if (this.int_37 < Class2.int_15 && flushType_0 == FlushType.None)
				{
					goto IL_319;
				}
				if (this.int_37 == 0)
				{
					goto Block_13;
				}
			}
			if (this.int_37 >= Class2.int_13)
			{
				this.int_26 = ((this.int_26 << this.int_30 ^ (int)(this.byte_1[this.int_35 + (Class2.int_13 - 1)] & byte.MaxValue)) & this.int_29);
				num = ((int)this.short_1[this.int_26] & 65535);
				this.short_0[this.int_35 & this.int_24] = this.short_1[this.int_26];
				this.short_1[this.int_26] = (short)this.int_35;
			}
			if ((long)num != 0L && (this.int_35 - num & 65535) <= this.int_22 - Class2.int_15 && this.compressionStrategy_0 != CompressionStrategy.HuffmanOnly)
			{
				this.int_32 = this.method_25(num);
			}
			bool flag;
			if (this.int_32 >= Class2.int_13)
			{
				flag = this.method_12(this.int_35 - this.int_36, this.int_32 - Class2.int_13);
				this.int_37 -= this.int_32;
				if (this.int_32 <= this.class3_0.int_1 && this.int_37 >= Class2.int_13)
				{
					this.int_32--;
					int num2;
					do
					{
						this.int_35++;
						this.int_26 = ((this.int_26 << this.int_30 ^ (int)(this.byte_1[this.int_35 + (Class2.int_13 - 1)] & byte.MaxValue)) & this.int_29);
						num = ((int)this.short_1[this.int_26] & 65535);
						this.short_0[this.int_35 & this.int_24] = this.short_1[this.int_26];
						this.short_1[this.int_26] = (short)this.int_35;
						num2 = this.int_32 - 1;
						this.int_32 = num2;
					}
					while (num2 != 0);
					this.int_35++;
				}
				else
				{
					this.int_35 += this.int_32;
					this.int_32 = 0;
					this.int_26 = (int)(this.byte_1[this.int_35] & byte.MaxValue);
					this.int_26 = ((this.int_26 << this.int_30 ^ (int)(this.byte_1[this.int_35 + 1] & byte.MaxValue)) & this.int_29);
				}
			}
			else
			{
				flag = this.method_12(0, (int)(this.byte_1[this.int_35] & byte.MaxValue));
				this.int_37--;
				this.int_35++;
			}
			if (flag)
			{
				this.method_18(false);
				if (this.zlibCodec_0.AvailableBytesOut == 0)
				{
					break;
				}
			}
		}
		return (Enum3)0;
		Block_13:
		this.method_18(flushType_0 == FlushType.Finish);
		if (this.zlibCodec_0.AvailableBytesOut != 0)
		{
			return (flushType_0 == FlushType.Finish) ? ((Enum3)3) : ((Enum3)1);
		}
		if (flushType_0 == FlushType.Finish)
		{
			return (Enum3)2;
		}
		return (Enum3)0;
		IL_319:
		return (Enum3)0;
	}

	// Token: 0x060001C2 RID: 450 RVA: 0x0000D51C File Offset: 0x0000B71C
	internal Enum3 method_24(FlushType flushType_0)
	{
		int num = 0;
		for (;;)
		{
			if (this.int_37 < Class2.int_15)
			{
				this.method_22();
				if (this.int_37 < Class2.int_15 && flushType_0 == FlushType.None)
				{
					goto IL_3BF;
				}
				if (this.int_37 == 0)
				{
					goto Block_21;
				}
			}
			if (this.int_37 >= Class2.int_13)
			{
				this.int_26 = ((this.int_26 << this.int_30 ^ (int)(this.byte_1[this.int_35 + (Class2.int_13 - 1)] & byte.MaxValue)) & this.int_29);
				num = ((int)this.short_1[this.int_26] & 65535);
				this.short_0[this.int_35 & this.int_24] = this.short_1[this.int_26];
				this.short_1[this.int_26] = (short)this.int_35;
			}
			this.int_38 = this.int_32;
			this.int_33 = this.int_36;
			this.int_32 = Class2.int_13 - 1;
			if (num != 0 && this.int_38 < this.class3_0.int_1 && (this.int_35 - num & 65535) <= this.int_22 - Class2.int_15)
			{
				if (this.compressionStrategy_0 != CompressionStrategy.HuffmanOnly)
				{
					this.int_32 = this.method_25(num);
				}
				if (this.int_32 <= 5 && (this.compressionStrategy_0 == CompressionStrategy.Filtered || (this.int_32 == Class2.int_13 && this.int_35 - this.int_36 > 4096)))
				{
					this.int_32 = Class2.int_13 - 1;
				}
			}
			if (this.int_38 >= Class2.int_13 && this.int_32 <= this.int_38)
			{
				int num2 = this.int_35 + this.int_37 - Class2.int_13;
				bool flag = this.method_12(this.int_35 - 1 - this.int_33, this.int_38 - Class2.int_13);
				this.int_37 -= this.int_38 - 1;
				this.int_38 -= 2;
				int num3;
				do
				{
					num3 = this.int_35 + 1;
					this.int_35 = num3;
					if (num3 <= num2)
					{
						this.int_26 = ((this.int_26 << this.int_30 ^ (int)(this.byte_1[this.int_35 + (Class2.int_13 - 1)] & byte.MaxValue)) & this.int_29);
						num = ((int)this.short_1[this.int_26] & 65535);
						this.short_0[this.int_35 & this.int_24] = this.short_1[this.int_26];
						this.short_1[this.int_26] = (short)this.int_35;
					}
					num3 = this.int_38 - 1;
					this.int_38 = num3;
				}
				while (num3 != 0);
				this.int_34 = 0;
				this.int_32 = Class2.int_13 - 1;
				this.int_35++;
				if (flag)
				{
					this.method_18(false);
					if (this.zlibCodec_0.AvailableBytesOut == 0)
					{
						break;
					}
				}
			}
			else if (this.int_34 != 0)
			{
				if (this.method_12(0, (int)(this.byte_1[this.int_35 - 1] & 255)))
				{
					this.method_18(false);
				}
				this.int_35++;
				this.int_37--;
				if (this.zlibCodec_0.AvailableBytesOut == 0)
				{
					goto Block_18;
				}
			}
			else
			{
				this.int_34 = 1;
				this.int_35++;
				this.int_37--;
			}
		}
		return (Enum3)0;
		Block_18:
		return (Enum3)0;
		Block_21:
		if (this.int_34 != 0)
		{
			bool flag = this.method_12(0, (int)(this.byte_1[this.int_35 - 1] & byte.MaxValue));
			this.int_34 = 0;
		}
		this.method_18(flushType_0 == FlushType.Finish);
		if (this.zlibCodec_0.AvailableBytesOut != 0)
		{
			return (flushType_0 == FlushType.Finish) ? ((Enum3)3) : ((Enum3)1);
		}
		if (flushType_0 == FlushType.Finish)
		{
			return (Enum3)2;
		}
		return (Enum3)0;
		IL_3BF:
		return (Enum3)0;
	}

	// Token: 0x060001C3 RID: 451 RVA: 0x0000D958 File Offset: 0x0000BB58
	internal int method_25(int int_48)
	{
		int num = this.class3_0.int_3;
		int num2 = this.int_35;
		int num3 = this.int_38;
		int num4 = (this.int_35 > this.int_22 - Class2.int_15) ? (this.int_35 - (this.int_22 - Class2.int_15)) : 0;
		int num5 = this.class3_0.int_2;
		int num6 = this.int_24;
		int num7 = this.int_35 + Class2.int_14;
		byte b = this.byte_1[num2 + num3 - 1];
		byte b2 = this.byte_1[num2 + num3];
		if (this.int_38 >= this.class3_0.int_0)
		{
			num >>= 2;
		}
		if (num5 > this.int_37)
		{
			num5 = this.int_37;
		}
		do
		{
			int num8 = int_48;
			if (this.byte_1[num8 + num3] == b2 && this.byte_1[num8 + num3 - 1] == b && this.byte_1[num8] == this.byte_1[num2] && this.byte_1[++num8] == this.byte_1[num2 + 1])
			{
				num2 += 2;
				num8++;
				while (this.byte_1[++num2] == this.byte_1[++num8] && this.byte_1[++num2] == this.byte_1[++num8] && this.byte_1[++num2] == this.byte_1[++num8] && this.byte_1[++num2] == this.byte_1[++num8] && this.byte_1[++num2] == this.byte_1[++num8] && this.byte_1[++num2] == this.byte_1[++num8] && this.byte_1[++num2] == this.byte_1[++num8] && this.byte_1[++num2] == this.byte_1[++num8] && num2 < num7)
				{
				}
				int num9 = Class2.int_14 - (num7 - num2);
				num2 = num7 - Class2.int_14;
				if (num9 > num3)
				{
					this.int_36 = int_48;
					num3 = num9;
					if (num9 >= num5)
					{
						break;
					}
					b = this.byte_1[num2 + num3 - 1];
					b2 = this.byte_1[num2 + num3];
				}
			}
		}
		while ((int_48 = ((int)this.short_0[int_48 & num6] & 65535)) > num4 && --num != 0);
		int result;
		if (num3 <= this.int_37)
		{
			result = num3;
		}
		else
		{
			result = this.int_37;
		}
		return result;
	}

	// Token: 0x060001C4 RID: 452 RVA: 0x00005457 File Offset: 0x00003657
	internal bool method_26()
	{
		return this.bool_1;
	}

	// Token: 0x060001C5 RID: 453 RVA: 0x0000545F File Offset: 0x0000365F
	internal void method_27(bool bool_2)
	{
		this.bool_1 = bool_2;
	}

	// Token: 0x060001C6 RID: 454 RVA: 0x0000DC2C File Offset: 0x0000BE2C
	internal int method_28(ZlibCodec zlibCodec_1, CompressionLevel compressionLevel_0)
	{
		return this.method_29(zlibCodec_1, compressionLevel_0, 15);
	}

	// Token: 0x060001C7 RID: 455 RVA: 0x0000DC48 File Offset: 0x0000BE48
	internal int method_29(ZlibCodec zlibCodec_1, CompressionLevel compressionLevel_0, int int_48)
	{
		return this.method_31(zlibCodec_1, compressionLevel_0, int_48, Class2.int_1, CompressionStrategy.Default);
	}

	// Token: 0x060001C8 RID: 456 RVA: 0x0000DC68 File Offset: 0x0000BE68
	internal int method_30(ZlibCodec zlibCodec_1, CompressionLevel compressionLevel_0, int int_48, CompressionStrategy compressionStrategy_1)
	{
		return this.method_31(zlibCodec_1, compressionLevel_0, int_48, Class2.int_1, compressionStrategy_1);
	}

	// Token: 0x060001C9 RID: 457 RVA: 0x0000DC88 File Offset: 0x0000BE88
	internal int method_31(ZlibCodec zlibCodec_1, CompressionLevel compressionLevel_0, int int_48, int int_49, CompressionStrategy compressionStrategy_1)
	{
		this.zlibCodec_0 = zlibCodec_1;
		this.zlibCodec_0.Message = null;
		if (int_48 < 9 || int_48 > 15)
		{
			throw new ZlibException("windowBits must be in the range 9..15.");
		}
		if (int_49 < 1 || int_49 > Class2.int_0)
		{
			throw new ZlibException(string.Format("memLevel must be in the range 1.. {0}", Class2.int_0));
		}
		this.zlibCodec_0.class2_0 = this;
		this.int_23 = int_48;
		this.int_22 = 1 << this.int_23;
		this.int_24 = this.int_22 - 1;
		this.int_28 = int_49 + 7;
		this.int_27 = 1 << this.int_28;
		this.int_29 = this.int_27 - 1;
		this.int_30 = (this.int_28 + Class2.int_13 - 1) / Class2.int_13;
		this.byte_1 = new byte[this.int_22 * 2];
		this.short_0 = new short[this.int_22];
		this.short_1 = new short[this.int_27];
		this.int_41 = 1 << int_49 + 6;
		this.byte_0 = new byte[this.int_41 * 4];
		this.int_43 = this.int_41;
		this.EkEunrkoBw = 3 * this.int_41;
		this.Rqvufksjgj = compressionLevel_0;
		this.compressionStrategy_0 = compressionStrategy_1;
		this.method_32();
		return 0;
	}

	// Token: 0x060001CA RID: 458 RVA: 0x0000DDEC File Offset: 0x0000BFEC
	internal void method_32()
	{
		ZlibCodec zlibCodec = this.zlibCodec_0;
		this.zlibCodec_0.TotalBytesOut = 0L;
		zlibCodec.TotalBytesIn = 0L;
		this.zlibCodec_0.Message = null;
		this.int_20 = 0;
		this.int_19 = 0;
		this.bool_0 = false;
		this.int_18 = (this.method_26() ? Class2.int_3 : Class2.int_4);
		this.zlibCodec_0.uint_0 = Adler.Adler32(0u, null, 0, 0);
		this.int_21 = 0;
		this.method_1();
		this.method_0();
	}

	// Token: 0x060001CB RID: 459 RVA: 0x0000DE84 File Offset: 0x0000C084
	internal int method_33()
	{
		int result;
		if (this.int_18 != Class2.int_3 && this.int_18 != Class2.int_4 && this.int_18 != Class2.int_5)
		{
			result = -2;
		}
		else
		{
			this.byte_0 = null;
			this.short_1 = null;
			this.short_0 = null;
			this.byte_1 = null;
			result = ((this.int_18 == Class2.int_4) ? -3 : 0);
		}
		return result;
	}

	// Token: 0x060001CC RID: 460 RVA: 0x0000DEF8 File Offset: 0x0000C0F8
	private void method_34()
	{
		switch (this.class3_0.xCeZypFmc4)
		{
		case (Enum4)0:
			this.delegate5_0 = new Class2.Delegate5(this.method_19);
			break;
		case (Enum4)1:
			this.delegate5_0 = new Class2.Delegate5(this.method_23);
			break;
		case (Enum4)2:
			this.delegate5_0 = new Class2.Delegate5(this.method_24);
			break;
		}
	}

	// Token: 0x060001CD RID: 461 RVA: 0x0000DF64 File Offset: 0x0000C164
	internal int method_35(CompressionLevel compressionLevel_0, CompressionStrategy compressionStrategy_1)
	{
		int result = 0;
		if (this.Rqvufksjgj != compressionLevel_0)
		{
			Class2.Class3 @class = Class2.Class3.smethod_0(compressionLevel_0);
			if (@class.xCeZypFmc4 != this.class3_0.xCeZypFmc4 && this.zlibCodec_0.TotalBytesIn != 0L)
			{
				result = this.zlibCodec_0.Deflate(FlushType.Partial);
			}
			this.Rqvufksjgj = compressionLevel_0;
			this.class3_0 = @class;
			this.method_34();
		}
		this.compressionStrategy_0 = compressionStrategy_1;
		return result;
	}

	// Token: 0x060001CE RID: 462 RVA: 0x0000DFE4 File Offset: 0x0000C1E4
	internal int method_36(byte[] byte_2)
	{
		int num = byte_2.Length;
		int sourceIndex = 0;
		if (byte_2 == null || this.int_18 != Class2.int_3)
		{
			throw new ZlibException("Stream error.");
		}
		this.zlibCodec_0.uint_0 = Adler.Adler32(this.zlibCodec_0.uint_0, byte_2, 0, byte_2.Length);
		int result;
		if (num < Class2.int_13)
		{
			result = 0;
		}
		else
		{
			if (num > this.int_22 - Class2.int_15)
			{
				num = this.int_22 - Class2.int_15;
				sourceIndex = byte_2.Length - num;
			}
			Array.Copy(byte_2, sourceIndex, this.byte_1, 0, num);
			this.int_35 = num;
			this.int_31 = num;
			this.int_26 = (int)(this.byte_1[0] & byte.MaxValue);
			this.int_26 = ((this.int_26 << this.int_30 ^ (int)(this.byte_1[1] & byte.MaxValue)) & this.int_29);
			for (int i = 0; i <= num - Class2.int_13; i++)
			{
				this.int_26 = ((this.int_26 << this.int_30 ^ (int)(this.byte_1[i + (Class2.int_13 - 1)] & byte.MaxValue)) & this.int_29);
				this.short_0[i & this.int_24] = this.short_1[this.int_26];
				this.short_1[this.int_26] = (short)i;
			}
			result = 0;
		}
		return result;
	}

	// Token: 0x060001CF RID: 463 RVA: 0x0000E148 File Offset: 0x0000C348
	internal int method_37(FlushType flushType_0)
	{
		if (this.zlibCodec_0.OutputBuffer == null || (this.zlibCodec_0.InputBuffer == null && this.zlibCodec_0.AvailableBytesIn != 0) || (this.int_18 == Class2.int_5 && flushType_0 != FlushType.Finish))
		{
			this.zlibCodec_0.Message = Class2.string_0[4];
			throw new ZlibException(string.Format("Something is fishy. [{0}]", this.zlibCodec_0.Message));
		}
		if (this.zlibCodec_0.AvailableBytesOut == 0)
		{
			this.zlibCodec_0.Message = Class2.string_0[7];
			throw new ZlibException("OutputBuffer is full (AvailableBytesOut == 0)");
		}
		int num = this.int_21;
		this.int_21 = (int)flushType_0;
		if (this.int_18 == Class2.int_3)
		{
			int num2 = Class2.int_6 + (this.int_23 - 8 << 4) << 8;
			int num3 = (this.Rqvufksjgj - CompressionLevel.BestSpeed & 255) >> 1;
			if (num3 > 3)
			{
				num3 = 3;
			}
			num2 |= num3 << 6;
			if (this.int_35 != 0)
			{
				num2 |= Class2.int_2;
			}
			num2 += 31 - num2 % 31;
			this.int_18 = Class2.int_4;
			byte[] array = this.byte_0;
			int num4 = this.int_20;
			this.int_20 = num4 + 1;
			array[num4] = (byte)(num2 >> 8);
			byte[] array2 = this.byte_0;
			num4 = this.int_20;
			this.int_20 = num4 + 1;
			array2[num4] = (byte)num2;
			if (this.int_35 != 0)
			{
				byte[] array3 = this.byte_0;
				num4 = this.int_20;
				this.int_20 = num4 + 1;
				array3[num4] = (byte)((this.zlibCodec_0.uint_0 & 4278190080u) >> 24);
				byte[] array4 = this.byte_0;
				num4 = this.int_20;
				this.int_20 = num4 + 1;
				array4[num4] = (byte)((this.zlibCodec_0.uint_0 & 16711680u) >> 16);
				byte[] array5 = this.byte_0;
				num4 = this.int_20;
				this.int_20 = num4 + 1;
				array5[num4] = (byte)((this.zlibCodec_0.uint_0 & 65280u) >> 8);
				byte[] array6 = this.byte_0;
				num4 = this.int_20;
				this.int_20 = num4 + 1;
				array6[num4] = (byte)(this.zlibCodec_0.uint_0 & 255u);
			}
			this.zlibCodec_0.uint_0 = Adler.Adler32(0u, null, 0, 0);
		}
		if (this.int_20 != 0)
		{
			this.zlibCodec_0.method_0();
			if (this.zlibCodec_0.AvailableBytesOut == 0)
			{
				this.int_21 = -1;
				return 0;
			}
		}
		else if (this.zlibCodec_0.AvailableBytesIn == 0 && flushType_0 <= (FlushType)num && flushType_0 != FlushType.Finish)
		{
			return 0;
		}
		if (this.int_18 == Class2.int_5 && this.zlibCodec_0.AvailableBytesIn != 0)
		{
			this.zlibCodec_0.Message = Class2.string_0[7];
			throw new ZlibException("status == FINISH_STATE && _codec.AvailableBytesIn != 0");
		}
		if (this.zlibCodec_0.AvailableBytesIn != 0 || this.int_37 != 0 || (flushType_0 != FlushType.None && this.int_18 != Class2.int_5))
		{
			Enum3 @enum = this.delegate5_0(flushType_0);
			if (@enum == (Enum3)2 || @enum == (Enum3)3)
			{
				this.int_18 = Class2.int_5;
			}
			if (@enum == (Enum3)0 || @enum == (Enum3)2)
			{
				if (this.zlibCodec_0.AvailableBytesOut == 0)
				{
					this.int_21 = -1;
				}
				return 0;
			}
			if (@enum == (Enum3)1)
			{
				if (flushType_0 == FlushType.Partial)
				{
					this.method_11();
				}
				else
				{
					this.method_20(0, 0, false);
					if (flushType_0 == FlushType.Full)
					{
						for (int i = 0; i < this.int_27; i++)
						{
							this.short_1[i] = 0;
						}
					}
				}
				this.zlibCodec_0.method_0();
				if (this.zlibCodec_0.AvailableBytesOut == 0)
				{
					this.int_21 = -1;
					return 0;
				}
			}
		}
		int result;
		if (flushType_0 != FlushType.Finish)
		{
			result = 0;
		}
		else if (!this.method_26() || this.bool_0)
		{
			result = 1;
		}
		else
		{
			byte[] array7 = this.byte_0;
			int num4 = this.int_20;
			this.int_20 = num4 + 1;
			array7[num4] = (byte)((this.zlibCodec_0.uint_0 & 4278190080u) >> 24);
			byte[] array8 = this.byte_0;
			num4 = this.int_20;
			this.int_20 = num4 + 1;
			array8[num4] = (byte)((this.zlibCodec_0.uint_0 & 16711680u) >> 16);
			byte[] array9 = this.byte_0;
			num4 = this.int_20;
			this.int_20 = num4 + 1;
			array9[num4] = (byte)((this.zlibCodec_0.uint_0 & 65280u) >> 8);
			byte[] array10 = this.byte_0;
			num4 = this.int_20;
			this.int_20 = num4 + 1;
			array10[num4] = (byte)(this.zlibCodec_0.uint_0 & 255u);
			this.zlibCodec_0.method_0();
			this.bool_0 = true;
			result = ((this.int_20 != 0) ? 0 : 1);
		}
		return result;
	}

	// Token: 0x060001D0 RID: 464 RVA: 0x0000E614 File Offset: 0x0000C814
	static Class2()
	{
		Class35.NkAVmDjz8ZWXG();
		Class2.int_0 = 9;
		Class2.int_1 = 8;
		Class2.string_0 = new string[]
		{
			"need dictionary",
			"stream end",
			"",
			"file error",
			"stream error",
			"data error",
			"insufficient memory",
			"buffer error",
			"incompatible version",
			""
		};
		Class2.int_2 = 32;
		Class2.int_3 = 42;
		Class2.int_4 = 113;
		Class2.int_5 = 666;
		Class2.int_6 = 8;
		Class2.int_7 = 0;
		Class2.int_8 = 1;
		Class2.AuxYvteyLw = 2;
		Class2.int_9 = 0;
		Class2.int_10 = 1;
		Class2.int_11 = 2;
		Class2.int_12 = 16;
		Class2.int_13 = 3;
		Class2.int_14 = 258;
		Class2.int_15 = Class2.int_14 + Class2.int_13 + 1;
		Class2.int_16 = 2 * Class11.int_5 + 1;
		Class2.int_17 = 256;
	}

	// Token: 0x04000192 RID: 402
	private static readonly int int_0;

	// Token: 0x04000193 RID: 403
	private static readonly int int_1;

	// Token: 0x04000194 RID: 404
	private Class2.Delegate5 delegate5_0;

	// Token: 0x04000195 RID: 405
	private static readonly string[] string_0;

	// Token: 0x04000196 RID: 406
	private static readonly int int_2;

	// Token: 0x04000197 RID: 407
	private static readonly int int_3;

	// Token: 0x04000198 RID: 408
	private static readonly int int_4;

	// Token: 0x04000199 RID: 409
	private static readonly int int_5;

	// Token: 0x0400019A RID: 410
	private static readonly int int_6;

	// Token: 0x0400019B RID: 411
	private static readonly int int_7;

	// Token: 0x0400019C RID: 412
	private static readonly int int_8;

	// Token: 0x0400019D RID: 413
	private static readonly int AuxYvteyLw;

	// Token: 0x0400019E RID: 414
	private static readonly int int_9;

	// Token: 0x0400019F RID: 415
	private static readonly int int_10;

	// Token: 0x040001A0 RID: 416
	private static readonly int int_11;

	// Token: 0x040001A1 RID: 417
	private static readonly int int_12;

	// Token: 0x040001A2 RID: 418
	private static readonly int int_13;

	// Token: 0x040001A3 RID: 419
	private static readonly int int_14;

	// Token: 0x040001A4 RID: 420
	private static readonly int int_15;

	// Token: 0x040001A5 RID: 421
	private static readonly int int_16;

	// Token: 0x040001A6 RID: 422
	private static readonly int int_17;

	// Token: 0x040001A7 RID: 423
	internal ZlibCodec zlibCodec_0;

	// Token: 0x040001A8 RID: 424
	internal int int_18;

	// Token: 0x040001A9 RID: 425
	internal byte[] byte_0;

	// Token: 0x040001AA RID: 426
	internal int int_19;

	// Token: 0x040001AB RID: 427
	internal int int_20;

	// Token: 0x040001AC RID: 428
	internal sbyte sbyte_0;

	// Token: 0x040001AD RID: 429
	internal int int_21;

	// Token: 0x040001AE RID: 430
	internal int int_22;

	// Token: 0x040001AF RID: 431
	internal int int_23;

	// Token: 0x040001B0 RID: 432
	internal int int_24;

	// Token: 0x040001B1 RID: 433
	internal byte[] byte_1;

	// Token: 0x040001B2 RID: 434
	internal int int_25;

	// Token: 0x040001B3 RID: 435
	internal short[] short_0;

	// Token: 0x040001B4 RID: 436
	internal short[] short_1;

	// Token: 0x040001B5 RID: 437
	internal int int_26;

	// Token: 0x040001B6 RID: 438
	internal int int_27;

	// Token: 0x040001B7 RID: 439
	internal int int_28;

	// Token: 0x040001B8 RID: 440
	internal int int_29;

	// Token: 0x040001B9 RID: 441
	internal int int_30;

	// Token: 0x040001BA RID: 442
	internal int int_31;

	// Token: 0x040001BB RID: 443
	private Class2.Class3 class3_0;

	// Token: 0x040001BC RID: 444
	internal int int_32;

	// Token: 0x040001BD RID: 445
	internal int int_33;

	// Token: 0x040001BE RID: 446
	internal int int_34;

	// Token: 0x040001BF RID: 447
	internal int int_35;

	// Token: 0x040001C0 RID: 448
	internal int int_36;

	// Token: 0x040001C1 RID: 449
	internal int int_37;

	// Token: 0x040001C2 RID: 450
	internal int int_38;

	// Token: 0x040001C3 RID: 451
	internal CompressionLevel Rqvufksjgj;

	// Token: 0x040001C4 RID: 452
	internal CompressionStrategy compressionStrategy_0;

	// Token: 0x040001C5 RID: 453
	internal short[] short_2;

	// Token: 0x040001C6 RID: 454
	internal short[] short_3;

	// Token: 0x040001C7 RID: 455
	internal short[] short_4;

	// Token: 0x040001C8 RID: 456
	internal Class9 class9_0;

	// Token: 0x040001C9 RID: 457
	internal Class9 class9_1;

	// Token: 0x040001CA RID: 458
	internal Class9 class9_2;

	// Token: 0x040001CB RID: 459
	internal short[] short_5;

	// Token: 0x040001CC RID: 460
	internal int[] int_39;

	// Token: 0x040001CD RID: 461
	internal int int_40;

	// Token: 0x040001CE RID: 462
	internal int xokuGhDon1;

	// Token: 0x040001CF RID: 463
	internal sbyte[] sbyte_1;

	// Token: 0x040001D0 RID: 464
	internal int EkEunrkoBw;

	// Token: 0x040001D1 RID: 465
	internal int int_41;

	// Token: 0x040001D2 RID: 466
	internal int int_42;

	// Token: 0x040001D3 RID: 467
	internal int int_43;

	// Token: 0x040001D4 RID: 468
	internal int int_44;

	// Token: 0x040001D5 RID: 469
	internal int IyxuFiuMr8;

	// Token: 0x040001D6 RID: 470
	internal int int_45;

	// Token: 0x040001D7 RID: 471
	internal int int_46;

	// Token: 0x040001D8 RID: 472
	internal short short_6;

	// Token: 0x040001D9 RID: 473
	internal int int_47;

	// Token: 0x040001DA RID: 474
	private bool bool_0;

	// Token: 0x040001DB RID: 475
	private bool bool_1;

	// Token: 0x0200006F RID: 111
	// (Invoke) Token: 0x060001D2 RID: 466
	internal delegate Enum3 Delegate5(FlushType flush);

	// Token: 0x02000070 RID: 112
	internal class Class3
	{
		// Token: 0x060001D5 RID: 469 RVA: 0x00005468 File Offset: 0x00003668
		private Class3(int int_4, int int_5, int int_6, int int_7, Enum4 enum4_0)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.int_0 = int_4;
			this.int_1 = int_5;
			this.int_2 = int_6;
			this.int_3 = int_7;
			this.xCeZypFmc4 = enum4_0;
		}

		// Token: 0x060001D6 RID: 470 RVA: 0x0000E71C File Offset: 0x0000C91C
		public static Class2.Class3 smethod_0(CompressionLevel compressionLevel_0)
		{
			return Class2.Class3.class3_0[(int)compressionLevel_0];
		}

		// Token: 0x060001D7 RID: 471 RVA: 0x0000E734 File Offset: 0x0000C934
		static Class3()
		{
			Class35.NkAVmDjz8ZWXG();
			Class2.Class3.class3_0 = new Class2.Class3[]
			{
				new Class2.Class3(0, 0, 0, 0, (Enum4)0),
				new Class2.Class3(4, 4, 8, 4, (Enum4)1),
				new Class2.Class3(4, 5, 16, 8, (Enum4)1),
				new Class2.Class3(4, 6, 32, 32, (Enum4)1),
				new Class2.Class3(4, 4, 16, 16, (Enum4)2),
				new Class2.Class3(8, 16, 32, 32, (Enum4)2),
				new Class2.Class3(8, 16, 128, 128, (Enum4)2),
				new Class2.Class3(8, 32, 128, 256, (Enum4)2),
				new Class2.Class3(32, 128, 258, 1024, (Enum4)2),
				new Class2.Class3(32, 258, 258, 4096, (Enum4)2)
			};
		}

		// Token: 0x040001DC RID: 476
		internal int int_0;

		// Token: 0x040001DD RID: 477
		internal int int_1;

		// Token: 0x040001DE RID: 478
		internal int int_2;

		// Token: 0x040001DF RID: 479
		internal int int_3;

		// Token: 0x040001E0 RID: 480
		internal Enum4 xCeZypFmc4;

		// Token: 0x040001E1 RID: 481
		private static readonly Class2.Class3[] class3_0;
	}
}
