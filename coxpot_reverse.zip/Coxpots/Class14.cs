﻿using System;
using System.Linq;
using System.Net.Sockets;
using Coxpots.Protocol.Server;
using Coxpots.Protocol.Server.Forge;

// Token: 0x0200008C RID: 140
internal class Class14
{
	// Token: 0x060002A4 RID: 676 RVA: 0x00014C90 File Offset: 0x00012E90
	public static void smethod_0()
	{
		for (;;)
		{
			Console.Clear();
			Console.Write("[内置]IP:");
			string text = Console.ReadLine();
			if (!string.IsNullOrWhiteSpace(text))
			{
				Console.Write("[内置]端口:");
				string text2 = Console.ReadLine();
				if (string.IsNullOrWhiteSpace(text2))
				{
					Console.Write("[内置]端口不正确.请重新输入");
					Console.ReadKey();
					continue;
				}
				int port;
				try
				{
					port = int.Parse(text2);
				}
				catch (FormatException)
				{
					Console.Write("[内置]端口不合法");
					Console.ReadKey();
					continue;
				}
				Console.WriteLine();
				Console.WriteLine("[内置]正在获取中...");
				Console.WriteLine();
				try
				{
					ServerInfo serverInfo = new ServerInfo(text, port);
					serverInfo.method_0();
					Console.WriteLine("");
					Console.WriteLine("[内置]连接到:" + serverInfo.ServerIP + serverInfo.ServerPort.ToString());
					Console.WriteLine("[内置]服务器MOTD:" + serverInfo.MOTD);
					Console.WriteLine("[内置]已确定版本:" + serverInfo.GameVersion + " Protocol:" + serverInfo.ProtocolVersion.ToString());
					Console.WriteLine("[内置]在线人数:" + serverInfo.CurrentPlayerCount.ToString() + "/" + serverInfo.MaxPlayerCount.ToString());
					Console.WriteLine("[内置]延迟:" + serverInfo.Ping.ToString());
					Console.WriteLine("");
					if (serverInfo.ForgeInfo != null && serverInfo.ForgeInfo.Mods.Any<ForgeInfo.ForgeMod>())
					{
						Console.WriteLine("Mod数据");
						foreach (ForgeInfo.ForgeMod forgeMod in serverInfo.ForgeInfo.Mods)
						{
							string str = "[内置]MOD:";
							ForgeInfo.ForgeMod forgeMod2 = forgeMod;
							Console.WriteLine(str + ((forgeMod2 != null) ? forgeMod2.ToString() : null));
						}
						Console.WriteLine("======================================");
						Console.WriteLine();
						Console.WriteLine("玩家数据");
						foreach (string str2 in serverInfo.OnlinePlayersName)
						{
							Console.WriteLine("[内置]玩家:" + str2);
						}
						Console.WriteLine("==========================");
						Console.WriteLine();
						serverInfo.Icon.Save("icon.png");
					}
					break;
				}
				catch (SocketException ex)
				{
					Console.WriteLine(ex.Message);
					Console.Write("[内置]连接发生异常");
					Console.ReadKey();
					continue;
				}
				catch (Exception value)
				{
					Console.WriteLine(value);
					Console.Write("[内置]发生异常");
					Console.ReadKey();
					continue;
				}
			}
			Console.Write("[内置]IP不正确.请重新输入");
			Console.ReadKey();
		}
		Console.Write("[内置]运行结束");
		Console.ReadKey();
	}

	// Token: 0x060002A5 RID: 677 RVA: 0x0000480C File Offset: 0x00002A0C
	public Class14()
	{
		Class35.NkAVmDjz8ZWXG();
		base..ctor();
	}
}
