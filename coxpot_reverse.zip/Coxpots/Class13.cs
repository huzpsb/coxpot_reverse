﻿using System;
using System.Net.Sockets;
using Coxpots.Protocol.Server;

// Token: 0x0200008B RID: 139
internal class Class13
{
	// Token: 0x060002A2 RID: 674 RVA: 0x00014AF8 File Offset: 0x00012CF8
	public static void smethod_0()
	{
		for (;;)
		{
			Console.Clear();
			Console.Write(">> ");
			string text = Console.ReadLine();
			if (!string.IsNullOrWhiteSpace(text))
			{
				Console.Write(">> ");
				string text2 = Console.ReadLine();
				if (string.IsNullOrWhiteSpace(text2))
				{
					Console.Write(">> 端口格式不正确");
					Console.ReadKey();
					continue;
				}
				int port;
				try
				{
					port = int.Parse(text2);
				}
				catch (FormatException)
				{
					Console.Write(">> 端口格式不正确");
					Console.ReadKey();
					continue;
				}
				try
				{
					ServerInfo serverInfo = new ServerInfo(text, port);
					serverInfo.method_0();
					Console.WriteLine("");
					Console.ForegroundColor = ConsoleColor.Yellow;
					Console.WriteLine(string.Concat(new string[]
					{
						">> 目标服务器:",
						serverInfo.ServerIP,
						":",
						serverInfo.ServerPort.ToString(),
						"  在线"
					}));
					Console.ForegroundColor = ConsoleColor.DarkGray;
					Console.WriteLine("");
					break;
				}
				catch (SocketException ex)
				{
					Console.WriteLine(ex.Message);
					ServerInfo serverInfo2 = new ServerInfo(text, port);
					serverInfo2.method_0();
					Console.WriteLine(string.Concat(new string[]
					{
						">> 目标服务器:",
						serverInfo2.ServerIP,
						":",
						serverInfo2.ServerPort.ToString(),
						"  离线"
					}));
					continue;
				}
			}
			Console.Write(">> IP格式不正确");
			Console.ReadKey();
		}
		Class15.smethod_0();
		Console.ReadLine();
	}

	// Token: 0x060002A3 RID: 675 RVA: 0x0000480C File Offset: 0x00002A0C
	public Class13()
	{
		Class35.NkAVmDjz8ZWXG();
		base..ctor();
	}
}
