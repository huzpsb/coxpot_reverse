﻿using System;

namespace Coxpots.Protocol.Client
{
	// Token: 0x020000A0 RID: 160
	public class BotUtils
	{
		// Token: 0x0600033B RID: 827 RVA: 0x0000480C File Offset: 0x00002A0C
		public BotUtils()
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
		}

		// Token: 0x020000A1 RID: 161
		public enum DisconnectReason
		{
			// Token: 0x040002D8 RID: 728
			InGameKick,
			// Token: 0x040002D9 RID: 729
			LoginRejected,
			// Token: 0x040002DA RID: 730
			ConnectionLost
		}
	}
}
