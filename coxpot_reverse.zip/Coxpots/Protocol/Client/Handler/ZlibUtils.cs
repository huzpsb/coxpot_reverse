﻿using System;
using System.IO;
using System.IO.Compression;
using System.Text;
using Ionic.Zlib;

namespace Coxpots.Protocol.Client.Handler
{
	// Token: 0x020000A6 RID: 166
	public static class ZlibUtils
	{
		// Token: 0x06000362 RID: 866 RVA: 0x0001A040 File Offset: 0x00018240
		public static byte[] Compress(byte[] to_compress)
		{
			byte[] result;
			using (MemoryStream memoryStream = new MemoryStream())
			{
				using (ZlibStream zlibStream = new ZlibStream(memoryStream, Ionic.Zlib.CompressionMode.Compress))
				{
					zlibStream.Write(to_compress, 0, to_compress.Length);
				}
				result = memoryStream.ToArray();
			}
			return result;
		}

		// Token: 0x06000363 RID: 867 RVA: 0x0001A0A4 File Offset: 0x000182A4
		public static byte[] Decompress(byte[] to_decompress, int size_uncompressed)
		{
			ZlibStream zlibStream = new ZlibStream(new MemoryStream(to_decompress, false), Ionic.Zlib.CompressionMode.Decompress);
			byte[] array = new byte[size_uncompressed];
			zlibStream.Read(array, 0, size_uncompressed);
			zlibStream.Close();
			return array;
		}

		// Token: 0x06000364 RID: 868 RVA: 0x0001A0DC File Offset: 0x000182DC
		public static string GZIPdecompress(byte[] to_decompress)
		{
			Stream stream = new MemoryStream(to_decompress);
			MemoryStream memoryStream = new MemoryStream();
			try
			{
				System.IO.Compression.GZipStream gzipStream = new System.IO.Compression.GZipStream(stream, System.IO.Compression.CompressionMode.Decompress);
				byte[] array = new byte[512];
				for (;;)
				{
					int num = gzipStream.Read(array, 0, array.Length);
					if (num <= 0)
					{
						break;
					}
					memoryStream.Write(array, 0, num);
				}
				gzipStream.Close();
			}
			catch
			{
			}
			return Encoding.UTF8.GetString(memoryStream.ToArray());
		}

		// Token: 0x06000365 RID: 869 RVA: 0x0001A15C File Offset: 0x0001835C
		public static byte[] Decompress(byte[] to_decompress)
		{
			ZlibStream zlibStream = new ZlibStream(new MemoryStream(to_decompress, false), Ionic.Zlib.CompressionMode.Decompress);
			byte[] array = new byte[16384];
			byte[] result;
			using (MemoryStream memoryStream = new MemoryStream())
			{
				int count;
				while ((count = zlibStream.Read(array, 0, array.Length)) > 0)
				{
					memoryStream.Write(array, 0, count);
				}
				result = memoryStream.ToArray();
			}
			return result;
		}
	}
}
