﻿using System;

namespace Coxpots.Protocol.Client.Handler
{
	// Token: 0x020000A2 RID: 162
	public interface IMinecraftCom
	{
		// Token: 0x0600033C RID: 828
		void OnGameJoin();

		// Token: 0x0600033D RID: 829
		void OnConnectionLost(BotUtils.DisconnectReason type, string msg);

		// Token: 0x0600033E RID: 830
		void OnKeepAlive();

		// Token: 0x0600033F RID: 831
		void OnChat();
	}
}
