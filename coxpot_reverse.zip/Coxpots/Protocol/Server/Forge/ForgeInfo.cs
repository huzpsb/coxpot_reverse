﻿using System;
using System.Collections.Generic;

namespace Coxpots.Protocol.Server.Forge
{
	// Token: 0x0200009E RID: 158
	public class ForgeInfo
	{
		// Token: 0x06000338 RID: 824 RVA: 0x00018508 File Offset: 0x00016708
		internal ForgeInfo(Class21.Class22 data)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.Mods = new List<ForgeInfo.ForgeMod>();
			foreach (Class21.Class22 @class in data.dictionary_0["modList"].list_0)
			{
				string string_ = @class.dictionary_0["modid"].string_0;
				string string_2 = @class.dictionary_0["version"].string_0;
				this.Mods.Add(new ForgeInfo.ForgeMod(string_, string_2));
			}
		}

		// Token: 0x040002D4 RID: 724
		public List<ForgeInfo.ForgeMod> Mods;

		// Token: 0x0200009F RID: 159
		public class ForgeMod
		{
			// Token: 0x06000339 RID: 825 RVA: 0x00005E8A File Offset: 0x0000408A
			public ForgeMod(string ModID, string Version)
			{
				Class35.NkAVmDjz8ZWXG();
				base..ctor();
				this.ModID = ModID;
				this.Version = Version;
			}

			// Token: 0x0600033A RID: 826 RVA: 0x000185B8 File Offset: 0x000167B8
			public override string ToString()
			{
				return this.ModID + " [" + this.Version + "]";
			}

			// Token: 0x040002D5 RID: 725
			public readonly string ModID;

			// Token: 0x040002D6 RID: 726
			public readonly string Version;
		}
	}
}
