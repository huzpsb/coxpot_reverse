﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;
using Heijden.DNS;

namespace Coxpots.Protocol.Server
{
	// Token: 0x02000097 RID: 151
	public class Protocol
	{
		// Token: 0x060002EB RID: 747 RVA: 0x00005D3A File Offset: 0x00003F3A
		public Protocol(TcpClient tcp)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.tcpClient_0 = tcp;
		}

		// Token: 0x060002EC RID: 748 RVA: 0x000165E4 File Offset: 0x000147E4
		public static bool MinecraftServiceLookup(ref string domain, ref ushort port)
		{
			bool flag;
			if (!string.IsNullOrEmpty(domain))
			{
				flag = domain.Any(new Func<char, bool>(Protocol.Class23.class23_0.method_0));
			}
			else
			{
				flag = false;
			}
			if (flag)
			{
				try
				{
					Console.ForegroundColor = ConsoleColor.DarkGray;
					Console.WriteLine("==================================");
					Console.ForegroundColor = ConsoleColor.White;
					Console.WriteLine("解析>> [{0}]", domain);
					Response response = new Resolver().Query("_minecraft._tcp." + domain, QType.SRV);
					RecordSRV[] recordSRV_ = response.RecordSRV_0;
					if (recordSRV_ != null && recordSRV_.Any<RecordSRV>())
					{
						RecordSRV recordSRV = recordSRV_.OrderBy(new Func<RecordSRV, ushort>(Protocol.Class23.class23_0.method_1)).ThenByDescending(new Func<RecordSRV, ushort>(Protocol.Class23.class23_0.method_2)).ThenBy(new Func<RecordSRV, Guid>(Protocol.Class23.class23_0.method_3)).First<RecordSRV>();
						string text = recordSRV.TARGET.Trim(new char[]
						{
							'.'
						});
						domain = text;
						port = recordSRV.PORT;
						Console.ForegroundColor = ConsoleColor.DarkGray;
						Console.WriteLine("==================================");
						Console.ForegroundColor = ConsoleColor.White;
						Console.WriteLine("Srv记录为：" + domain + ":" + port.ToString());
						Console.ForegroundColor = ConsoleColor.DarkGray;
						Console.WriteLine("==================================");
						Pin.SetServerIP(null);
						Console.WriteLine("");
						return true;
					}
				}
				catch (Exception ex)
				{
					Console.WriteLine("解析失败..." + ex.Message);
				}
			}
			return false;
		}

		// Token: 0x060002ED RID: 749 RVA: 0x000167A8 File Offset: 0x000149A8
		public void Receive(byte[] buffer, int start, int offset, SocketFlags f)
		{
			for (int i = 0; i < offset; i += this.tcpClient_0.Client.Receive(buffer, start + i, offset - i, f))
			{
			}
		}

		// Token: 0x060002EE RID: 750 RVA: 0x000167DC File Offset: 0x000149DC
		public string readNextString()
		{
			ushort num = (ushort)this.readNextShort();
			string result;
			if (num > 0)
			{
				byte[] array = new byte[(int)(num * 2)];
				this.Receive(array, 0, (int)(num * 2), SocketFlags.None);
				string @string = Encoding.BigEndianUnicode.GetString(array);
				result = @string;
			}
			else
			{
				result = "";
			}
			return result;
		}

		// Token: 0x060002EF RID: 751 RVA: 0x00016824 File Offset: 0x00014A24
		public static byte[] getVarInt(int paramInt)
		{
			List<byte> list = new List<byte>();
			while ((paramInt & -128) != 0)
			{
				list.Add((byte)((paramInt & 127) | 128));
				paramInt = (int)((uint)paramInt >> 7);
			}
			list.Add((byte)paramInt);
			return list.ToArray();
		}

		// Token: 0x060002F0 RID: 752 RVA: 0x00016868 File Offset: 0x00014A68
		public static byte[] concatBytes(params byte[][] bytes)
		{
			List<byte> list = new List<byte>();
			foreach (byte collection in bytes)
			{
				list.AddRange(collection);
			}
			return list.ToArray();
		}

		// Token: 0x060002F1 RID: 753 RVA: 0x000168A0 File Offset: 0x00014AA0
		private static byte[] smethod_0(int int_0, List<byte> list_0)
		{
			byte[] result = list_0.Take(int_0).ToArray<byte>();
			list_0.RemoveRange(0, int_0);
			return result;
		}

		// Token: 0x060002F2 RID: 754 RVA: 0x000168C8 File Offset: 0x00014AC8
		public static string readNextString(List<byte> cache)
		{
			int num = Protocol.readNextVarInt(cache);
			string result;
			if (num > 0)
			{
				result = Encoding.UTF8.GetString(Protocol.smethod_0(num, cache));
			}
			else
			{
				result = "";
			}
			return result;
		}

		// Token: 0x060002F3 RID: 755 RVA: 0x00016900 File Offset: 0x00014B00
		public byte[] readNextByteArray()
		{
			short num = this.readNextShort();
			byte[] array = new byte[(int)num];
			this.Receive(array, 0, (int)num, SocketFlags.None);
			return array;
		}

		// Token: 0x060002F4 RID: 756 RVA: 0x00016928 File Offset: 0x00014B28
		public short readNextShort()
		{
			byte[] array = new byte[2];
			this.Receive(array, 0, 2, SocketFlags.None);
			Array.Reverse(array);
			return BitConverter.ToInt16(array, 0);
		}

		// Token: 0x060002F5 RID: 757 RVA: 0x00016958 File Offset: 0x00014B58
		public int readNextInt()
		{
			byte[] array = new byte[4];
			this.Receive(array, 0, 4, SocketFlags.None);
			Array.Reverse(array);
			return BitConverter.ToInt32(array, 0);
		}

		// Token: 0x060002F6 RID: 758 RVA: 0x00016988 File Offset: 0x00014B88
		public byte readNextByte()
		{
			byte[] array = new byte[1];
			this.Receive(array, 0, 1, SocketFlags.None);
			return array[0];
		}

		// Token: 0x060002F7 RID: 759 RVA: 0x000169AC File Offset: 0x00014BAC
		public static byte readNextByte(List<byte> cache)
		{
			byte result = cache[0];
			cache.RemoveAt(0);
			return result;
		}

		// Token: 0x060002F8 RID: 760 RVA: 0x000169CC File Offset: 0x00014BCC
		public int readNextVarIntRAW()
		{
			int num = 0;
			int num2 = 0;
			byte[] array = new byte[1];
			for (;;)
			{
				this.Receive(array, 0, 1, SocketFlags.None);
				int num3 = (int)array[0];
				num |= (num3 & 127) << num2++ * 7;
				if (num2 > 5)
				{
					break;
				}
				if ((num3 & 128) != 128)
				{
					return num;
				}
			}
			throw new OverflowException("VarInt too big");
		}

		// Token: 0x060002F9 RID: 761 RVA: 0x00016A34 File Offset: 0x00014C34
		public byte[] method_0(int offset)
		{
			if (offset > 0)
			{
				try
				{
					byte[] array = new byte[offset];
					this.Receive(array, 0, offset, SocketFlags.None);
					return array;
				}
				catch (OutOfMemoryException)
				{
				}
			}
			return new byte[0];
		}

		// Token: 0x060002FA RID: 762 RVA: 0x00016A78 File Offset: 0x00014C78
		public static int readNextVarInt(List<byte> cache)
		{
			int num = 0;
			int num2 = 0;
			for (;;)
			{
				int num3 = (int)Protocol.readNextByte(cache);
				num |= (num3 & 127) << num2++ * 7;
				if (num2 > 5)
				{
					break;
				}
				if ((num3 & 128) != 128)
				{
					return num;
				}
			}
			throw new OverflowException("VarInt too big");
		}

		// Token: 0x060002FB RID: 763 RVA: 0x00016AD0 File Offset: 0x00014CD0
		public static int MCVer2ProtocolVersion(string string_0)
		{
			int result;
			if (string_0.Contains('.'))
			{
				string text = string_0.Split(new char[]
				{
					' '
				})[0].Trim();
				string text2 = text;
				if (text2 != null)
				{
					uint num = <PrivateImplementationDetails>.ComputeStringHash(text2);
					if (num <= 2736047893u)
					{
						if (num > 1362732105u)
						{
							if (num <= 1834777243u)
							{
								if (num <= 1547285914u)
								{
									if (num != 1379509724u)
									{
										if (num != 1396287343u)
										{
											if (num != 1547285914u)
											{
												goto IL_6EF;
											}
											if (!(text2 == "1.7.9"))
											{
												goto IL_6EF;
											}
											goto IL_408;
										}
										else
										{
											if (!(text2 == "1.7.2"))
											{
												goto IL_6EF;
											}
											goto IL_24F;
										}
									}
									else
									{
										if (text2 == "1.7.3")
										{
											goto IL_24F;
										}
										goto IL_6EF;
									}
								}
								else if (num != 1564063533u)
								{
									if (num != 1817999624u)
									{
										if (num != 1834777243u)
										{
											goto IL_6EF;
										}
										if (!(text2 == "1.6.3"))
										{
											goto IL_6EF;
										}
									}
									else if (!(text2 == "1.6.2"))
									{
										goto IL_6EF;
									}
								}
								else
								{
									if (!(text2 == "1.7.8"))
									{
										goto IL_6EF;
									}
									goto IL_408;
								}
							}
							else if (num <= 1918665338u)
							{
								if (num != 1851554862u)
								{
									if (num != 1868332481u)
									{
										if (num != 1918665338u)
										{
											goto IL_6EF;
										}
										if (!(text2 == "1.6.4"))
										{
											goto IL_6EF;
										}
									}
									else if (!(text2 == "1.6.1"))
									{
										goto IL_6EF;
									}
								}
								else
								{
									if (!(text2 == "1.6.0"))
									{
										goto IL_6EF;
									}
									goto IL_5F7;
								}
							}
							else if (num <= 2702492655u)
							{
								if (num != 2685715036u)
								{
									if (num != 2702492655u)
									{
										goto IL_6EF;
									}
									if (text2 == "1.10")
									{
										goto IL_33D;
									}
									goto IL_6EF;
								}
								else
								{
									if (!(text2 == "1.11"))
									{
										goto IL_6EF;
									}
									goto IL_4D3;
								}
							}
							else if (num != 2719270274u)
							{
								if (num != 2736047893u)
								{
									goto IL_6EF;
								}
								if (text2 == "1.12")
								{
									goto IL_382;
								}
								goto IL_6EF;
							}
							else
							{
								if (text2 == "1.13")
								{
									return 393;
								}
								goto IL_6EF;
							}
							return 73;
						}
						if (num <= 844126771u)
						{
							if (num <= 216907561u)
							{
								if (num != 166574704u)
								{
									if (num != 183352323u)
									{
										if (num != 216907561u)
										{
											goto IL_6EF;
										}
										if (text2 == "1.12.2")
										{
											return 340;
										}
										goto IL_6EF;
									}
									else
									{
										if (!(text2 == "1.12.0"))
										{
											goto IL_6EF;
										}
										goto IL_382;
									}
								}
								else
								{
									if (text2 == "1.12.1")
									{
										return 338;
									}
									goto IL_6EF;
								}
							}
							else if (num != 692724044u)
							{
								if (num != 743056901u)
								{
									if (num != 844126771u)
									{
										goto IL_6EF;
									}
									if (!(text2 == "1.10.2"))
									{
										goto IL_6EF;
									}
									goto IL_33D;
								}
								else
								{
									if (text2 == "1.5.2")
									{
										return 61;
									}
									goto IL_6EF;
								}
							}
							else
							{
								if (text2 == "1.5.1")
								{
									return 60;
								}
								goto IL_6EF;
							}
						}
						else if (num <= 1312399248u)
						{
							if (num != 860904390u)
							{
								if (num != 877682009u)
								{
									if (num != 1312399248u)
									{
										goto IL_6EF;
									}
									if (!(text2 == "1.7.7"))
									{
										goto IL_6EF;
									}
									goto IL_408;
								}
								else
								{
									if (!(text2 == "1.10.0"))
									{
										goto IL_6EF;
									}
									goto IL_33D;
								}
							}
							else
							{
								if (!(text2 == "1.10.1"))
								{
									goto IL_6EF;
								}
								goto IL_33D;
							}
						}
						else if (num != 1329176867u)
						{
							if (num != 1345954486u)
							{
								if (num != 1362732105u)
								{
									goto IL_6EF;
								}
								if (!(text2 == "1.7.4"))
								{
									goto IL_6EF;
								}
							}
							else if (!(text2 == "1.7.5"))
							{
								goto IL_6EF;
							}
						}
						else
						{
							if (!(text2 == "1.7.6"))
							{
								goto IL_6EF;
							}
							goto IL_408;
						}
						IL_24F:
						return 4;
						IL_33D:
						return 210;
						IL_382:
						return 335;
					}
					if (num <= 3517312711u)
					{
						if (num <= 3433424616u)
						{
							if (num <= 3379414890u)
							{
								if (num != 2769377455u)
								{
									if (num != 3368376758u)
									{
										if (num != 3379414890u)
										{
											goto IL_6EF;
										}
										if (!(text2 == "1.4.6"))
										{
											goto IL_6EF;
										}
									}
									else
									{
										if (text2 == "1.7.10")
										{
											goto IL_408;
										}
										goto IL_6EF;
									}
								}
								else
								{
									if (text2 == "1.13.1")
									{
										return 401;
									}
									goto IL_6EF;
								}
							}
							else if (num != 3396192509u)
							{
								if (num != 3423716876u)
								{
									if (num != 3433424616u)
									{
										goto IL_6EF;
									}
									if (text2 == "1.9.1")
									{
										return 108;
									}
									goto IL_6EF;
								}
								else
								{
									if (!(text2 == "1.11.2"))
									{
										goto IL_6EF;
									}
									goto IL_550;
								}
							}
							else if (!(text2 == "1.4.7"))
							{
								goto IL_6EF;
							}
							return 51;
						}
						if (num <= 3466979854u)
						{
							if (num != 3450202235u)
							{
								if (num != 3457272114u)
								{
									if (num != 3466979854u)
									{
										goto IL_6EF;
									}
									if (!(text2 == "1.9.3"))
									{
										goto IL_6EF;
									}
								}
								else
								{
									if (text2 == "1.11.0")
									{
										goto IL_4D3;
									}
									goto IL_6EF;
								}
							}
							else
							{
								if (!(text2 == "1.9.0"))
								{
									goto IL_6EF;
								}
								goto IL_6D8;
							}
						}
						else if (num != 3474049733u)
						{
							if (num != 3483757473u)
							{
								if (num != 3517312711u)
								{
									goto IL_6EF;
								}
								if (!(text2 == "1.9.4"))
								{
									goto IL_6EF;
								}
							}
							else
							{
								if (text2 == "1.9.2")
								{
									return 109;
								}
								goto IL_6EF;
							}
						}
						else
						{
							if (text2 == "1.11.1")
							{
								goto IL_550;
							}
							goto IL_6EF;
						}
						return 110;
						IL_550:
						return 316;
					}
					if (num <= 3846312576u)
					{
						if (num <= 3804804040u)
						{
							if (num != 3737693564u)
							{
								if (num != 3754471183u)
								{
									if (num != 3804804040u)
									{
										goto IL_6EF;
									}
									if (!(text2 == "1.8.4"))
									{
										goto IL_6EF;
									}
								}
								else if (!(text2 == "1.8.9"))
								{
									goto IL_6EF;
								}
							}
							else if (!(text2 == "1.8.8"))
							{
								goto IL_6EF;
							}
						}
						else if (num != 3821581659u)
						{
							if (num != 3838359278u)
							{
								if (num != 3846312576u)
								{
									goto IL_6EF;
								}
								if (text2 == "1.6")
								{
									goto IL_5F7;
								}
								goto IL_6EF;
							}
							else if (!(text2 == "1.8.6"))
							{
								goto IL_6EF;
							}
						}
						else if (!(text2 == "1.8.5"))
						{
							goto IL_6EF;
						}
					}
					else if (num <= 3888692135u)
					{
						if (num != 3855136897u)
						{
							if (num != 3871914516u)
							{
								if (num != 3888692135u)
								{
									goto IL_6EF;
								}
								if (!(text2 == "1.8.1"))
								{
									goto IL_6EF;
								}
							}
							else if (!(text2 == "1.8.0"))
							{
								goto IL_6EF;
							}
						}
						else if (!(text2 == "1.8.7"))
						{
							goto IL_6EF;
						}
					}
					else if (num <= 3922247373u)
					{
						if (num != 3905469754u)
						{
							if (num != 3922247373u)
							{
								goto IL_6EF;
							}
							if (!(text2 == "1.8.3"))
							{
								goto IL_6EF;
							}
						}
						else if (!(text2 == "1.8.2"))
						{
							goto IL_6EF;
						}
					}
					else if (num != 4081199242u)
					{
						if (num != 4097976861u)
						{
							goto IL_6EF;
						}
						if (text2 == "1.9")
						{
							goto IL_6D8;
						}
						goto IL_6EF;
					}
					else if (!(text2 == "1.8"))
					{
						goto IL_6EF;
					}
					return 47;
					IL_6D8:
					return 107;
					IL_408:
					return 5;
					IL_4D3:
					return 315;
					IL_5F7:
					return 72;
				}
				IL_6EF:
				result = 0;
			}
			else
			{
				try
				{
					result = int.Parse(string_0);
				}
				catch
				{
					result = 0;
				}
			}
			return result;
		}

		// Token: 0x060002FC RID: 764 RVA: 0x000171F0 File Offset: 0x000153F0
		public static string getGameVersion(int protover)
		{
			if (protover <= 73)
			{
				if (protover <= 51)
				{
					if (protover <= 5)
					{
						if (protover == 4)
						{
							return "1.7.2";
						}
						if (protover == 5)
						{
							return "1.7.10";
						}
					}
					else
					{
						if (protover == 47)
						{
							return "1.8";
						}
						if (protover == 51)
						{
							return "1.4.6";
						}
					}
				}
				else if (protover <= 61)
				{
					if (protover == 60)
					{
						return "1.5.1";
					}
					if (protover == 61)
					{
						return "1.5.2";
					}
				}
				else
				{
					if (protover == 72)
					{
						return "1.6";
					}
					if (protover == 73)
					{
						return "1.6.2";
					}
				}
			}
			else if (protover <= 316)
			{
				if (protover <= 210)
				{
					switch (protover)
					{
					case 107:
						return "1.9";
					case 108:
						return "1.9.1";
					case 109:
						return "1.9.2";
					case 110:
						return "1.9.4";
					default:
						if (protover == 210)
						{
							return "1.10";
						}
						break;
					}
				}
				else
				{
					if (protover == 315)
					{
						return "1.11";
					}
					if (protover == 316)
					{
						return "1.11.2";
					}
				}
			}
			else if (protover <= 338)
			{
				if (protover == 335)
				{
					return "1.12";
				}
				if (protover == 338)
				{
					return "1.12.1";
				}
			}
			else
			{
				if (protover == 340)
				{
					return "1.12.2";
				}
				if (protover == 393)
				{
					return "1.13";
				}
				if (protover == 401)
				{
					return "1.13.1";
				}
			}
			return "";
		}

		// Token: 0x040002BA RID: 698
		private TcpClient tcpClient_0;

		// Token: 0x02000098 RID: 152
		[CompilerGenerated]
		[Serializable]
		private sealed class Class23
		{
			// Token: 0x060002FD RID: 765 RVA: 0x00005D4E File Offset: 0x00003F4E
			static Class23()
			{
				Class35.NkAVmDjz8ZWXG();
				Protocol.Class23.class23_0 = new Protocol.Class23();
			}

			// Token: 0x060002FE RID: 766 RVA: 0x0000480C File Offset: 0x00002A0C
			public Class23()
			{
				Class35.NkAVmDjz8ZWXG();
				base..ctor();
			}

			// Token: 0x060002FF RID: 767 RVA: 0x00005D5F File Offset: 0x00003F5F
			internal bool method_0(char char_0)
			{
				return char.IsLetter(char_0);
			}

			// Token: 0x06000300 RID: 768 RVA: 0x00005D67 File Offset: 0x00003F67
			internal ushort method_1(RecordSRV recordSRV_0)
			{
				return recordSRV_0.PRIORITY;
			}

			// Token: 0x06000301 RID: 769 RVA: 0x00005D6F File Offset: 0x00003F6F
			internal ushort method_2(RecordSRV recordSRV_0)
			{
				return recordSRV_0.WEIGHT;
			}

			// Token: 0x06000302 RID: 770 RVA: 0x00005D77 File Offset: 0x00003F77
			internal Guid method_3(RecordSRV recordSRV_0)
			{
				return Guid.NewGuid();
			}

			// Token: 0x040002BB RID: 699
			public static readonly Protocol.Class23 class23_0;

			// Token: 0x040002BC RID: 700
			public static Func<char, bool> func_0;

			// Token: 0x040002BD RID: 701
			public static Func<RecordSRV, ushort> func_1;

			// Token: 0x040002BE RID: 702
			public static Func<RecordSRV, ushort> func_2;

			// Token: 0x040002BF RID: 703
			public static Func<RecordSRV, Guid> func_3;
		}
	}
}
