﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;
using Coxpots.Protocol.Server.Forge;

namespace Coxpots.Protocol.Server
{
	// Token: 0x0200009B RID: 155
	public class ServerInfo
	{
		// Token: 0x1700006D RID: 109
		// (get) Token: 0x0600031B RID: 795 RVA: 0x00005DA3 File Offset: 0x00003FA3
		// (set) Token: 0x0600031C RID: 796 RVA: 0x00005DAB File Offset: 0x00003FAB
		public string ServerIP { get; set; }

		// Token: 0x1700006E RID: 110
		// (get) Token: 0x0600031D RID: 797 RVA: 0x00005DB4 File Offset: 0x00003FB4
		// (set) Token: 0x0600031E RID: 798 RVA: 0x00005DBC File Offset: 0x00003FBC
		public int ServerPort { get; set; }

		// Token: 0x1700006F RID: 111
		// (get) Token: 0x0600031F RID: 799 RVA: 0x00005DC5 File Offset: 0x00003FC5
		// (set) Token: 0x06000320 RID: 800 RVA: 0x00005DCD File Offset: 0x00003FCD
		public string MOTD { get; private set; }

		// Token: 0x17000070 RID: 112
		// (get) Token: 0x06000321 RID: 801 RVA: 0x00005DD6 File Offset: 0x00003FD6
		// (set) Token: 0x06000322 RID: 802 RVA: 0x00005DDE File Offset: 0x00003FDE
		public int MaxPlayerCount { get; private set; }

		// Token: 0x17000071 RID: 113
		// (get) Token: 0x06000323 RID: 803 RVA: 0x00005DE7 File Offset: 0x00003FE7
		// (set) Token: 0x06000324 RID: 804 RVA: 0x00005DEF File Offset: 0x00003FEF
		public int CurrentPlayerCount { get; private set; }

		// Token: 0x17000072 RID: 114
		// (get) Token: 0x06000325 RID: 805 RVA: 0x00005DF8 File Offset: 0x00003FF8
		// (set) Token: 0x06000326 RID: 806 RVA: 0x00005E00 File Offset: 0x00004000
		public int ProtocolVersion { get; private set; }

		// Token: 0x17000073 RID: 115
		// (get) Token: 0x06000327 RID: 807 RVA: 0x00005E09 File Offset: 0x00004009
		// (set) Token: 0x06000328 RID: 808 RVA: 0x00005E11 File Offset: 0x00004011
		public string GameVersion { get; private set; }

		// Token: 0x17000074 RID: 116
		// (get) Token: 0x06000329 RID: 809 RVA: 0x00005E1A File Offset: 0x0000401A
		// (set) Token: 0x0600032A RID: 810 RVA: 0x00005E22 File Offset: 0x00004022
		public string JsonResult { get; private set; }

		// Token: 0x17000075 RID: 117
		// (get) Token: 0x0600032B RID: 811 RVA: 0x00005E2B File Offset: 0x0000402B
		// (set) Token: 0x0600032C RID: 812 RVA: 0x00005E33 File Offset: 0x00004033
		public ForgeInfo ForgeInfo { get; private set; }

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x0600032D RID: 813 RVA: 0x00005E3C File Offset: 0x0000403C
		// (set) Token: 0x0600032E RID: 814 RVA: 0x00005E44 File Offset: 0x00004044
		public List<string> OnlinePlayersName { get; private set; }

		// Token: 0x17000077 RID: 119
		// (get) Token: 0x0600032F RID: 815 RVA: 0x00005E4D File Offset: 0x0000404D
		// (set) Token: 0x06000330 RID: 816 RVA: 0x00005E55 File Offset: 0x00004055
		public long Ping { get; private set; }

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x06000331 RID: 817 RVA: 0x00005E5E File Offset: 0x0000405E
		// (set) Token: 0x06000332 RID: 818 RVA: 0x00005E66 File Offset: 0x00004066
		public Bitmap Icon { get; private set; }

		// Token: 0x17000079 RID: 121
		// (get) Token: 0x06000333 RID: 819 RVA: 0x00017ECC File Offset: 0x000160CC
		public static Dictionary<char, string> MinecraftColors
		{
			get
			{
				return new Dictionary<char, string>
				{
					{
						'0',
						"#000000"
					},
					{
						'1',
						"#0000AA"
					},
					{
						'2',
						"#00AA00"
					},
					{
						'3',
						"#00AAAA"
					},
					{
						'4',
						"#AA0000"
					},
					{
						'5',
						"#AA00AA"
					},
					{
						'6',
						"#FFAA00"
					},
					{
						'7',
						"#AAAAAA"
					},
					{
						'8',
						"#555555"
					},
					{
						'9',
						"#5555FF"
					},
					{
						'a',
						"#55FF55"
					},
					{
						'b',
						"#55FFFF"
					},
					{
						'c',
						"#FF5555"
					},
					{
						'd',
						"#FF55FF"
					},
					{
						'e',
						"#FFFF55"
					},
					{
						'f',
						"#FFFFFF"
					}
				};
			}
		}

		// Token: 0x06000334 RID: 820 RVA: 0x00005E6F File Offset: 0x0000406F
		public ServerInfo(string ip, int port)
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
			this.ServerIP = ip;
			this.ServerPort = port;
		}

		// Token: 0x06000335 RID: 821 RVA: 0x00017FB0 File Offset: 0x000161B0
		internal bool method_0()
		{
			try
			{
				using (TcpClient tcpClient = new TcpClient(this.ServerIP, this.ServerPort))
				{
					tcpClient.ReceiveBufferSize = 1048576;
					byte[] varInt = ProtocolHandler.getVarInt(0);
					byte[] varInt2 = ProtocolHandler.getVarInt(-1);
					byte[] bytes = Encoding.UTF8.GetBytes(this.ServerIP);
					byte[] varInt3 = ProtocolHandler.getVarInt(bytes.Length);
					byte[] bytes2 = BitConverter.GetBytes((ushort)this.ServerPort);
					Array.Reverse(bytes2);
					byte[] varInt4 = ProtocolHandler.getVarInt(1);
					byte[] array = ProtocolHandler.concatBytes(new byte[][]
					{
						varInt,
						varInt2,
						varInt3,
						bytes,
						bytes2,
						varInt4
					});
					byte[] buffer = ProtocolHandler.concatBytes(new byte[][]
					{
						ProtocolHandler.getVarInt(array.Length),
						array
					});
					tcpClient.Client.Send(buffer, SocketFlags.None);
					byte[] varInt5 = ProtocolHandler.getVarInt(0);
					byte[] buffer2 = ProtocolHandler.concatBytes(new byte[][]
					{
						ProtocolHandler.getVarInt(varInt5.Length),
						varInt5
					});
					tcpClient.Client.Send(buffer2, SocketFlags.None);
					ProtocolHandler protocolHandler = new ProtocolHandler(tcpClient);
					int num = protocolHandler.readNextVarIntRAW();
					if (num > 0)
					{
						List<byte> cache = new List<byte>(protocolHandler.method_0(num));
						if (ProtocolHandler.readNextVarInt(cache) == 0)
						{
							string text = ProtocolHandler.readNextString(cache);
							this.JsonResult = text;
							this.method_1(text);
						}
					}
				}
				this.ReloadPing();
				return true;
			}
			catch (Exception ex)
			{
				Console.WriteLine("[错误] " + ex.Message);
			}
			return false;
		}

		// Token: 0x06000336 RID: 822 RVA: 0x00018164 File Offset: 0x00016364
		private void method_1(string string_4)
		{
			try
			{
				if (!string.IsNullOrEmpty(string_4) && string_4.StartsWith("{") && string_4.EndsWith("}"))
				{
					Class21.Class22 @class = Class21.smethod_0(string_4);
					Class21.Class22 class2 = @class.dictionary_0["version"];
					this.GameVersion = class2.dictionary_0["name"].string_0;
					this.ProtocolVersion = int.Parse(class2.dictionary_0["protocol"].string_0);
					Class21.Class22 class3 = @class.dictionary_0["players"];
					this.MaxPlayerCount = int.Parse(class3.dictionary_0["max"].string_0);
					this.CurrentPlayerCount = int.Parse(class3.dictionary_0["online"].string_0);
					if (class3.dictionary_0.ContainsKey("sample"))
					{
						this.OnlinePlayersName = new List<string>();
						foreach (Class21.Class22 class4 in class3.dictionary_0["sample"].list_0)
						{
							string item = class4.dictionary_0["name"].string_0.Remove(0, 2);
							this.OnlinePlayersName.Add(item);
						}
					}
					Class21.Class22 class5 = @class.dictionary_0["description"];
					if (class5.dictionary_0.ContainsKey("text"))
					{
						this.MOTD = class5.dictionary_0["text"].string_0;
					}
					else
					{
						this.MOTD = class5.string_0;
					}
					if (this.ProtocolVersion < 47 && this.GameVersion.Split(new char[]
					{
						' ',
						'/'
					}).Contains("1.8"))
					{
						this.ProtocolVersion = ProtocolHandler.MCVer2ProtocolVersion("1.8.0");
					}
					if (@class.dictionary_0.ContainsKey("modinfo") && @class.dictionary_0["modinfo"].method_0() == (Class21.Class22.Enum9)0)
					{
						Class21.Class22 class6 = @class.dictionary_0["modinfo"];
						if (class6.dictionary_0.ContainsKey("type") && class6.dictionary_0["type"].string_0 == "FML")
						{
							this.ForgeInfo = new ForgeInfo(class6);
							if (!this.ForgeInfo.Mods.Any<ForgeInfo.ForgeMod>())
							{
								this.ForgeInfo = null;
							}
						}
					}
					if (@class.dictionary_0.ContainsKey("favicon"))
					{
						string text = @class.dictionary_0["favicon"].string_0;
						byte[] buffer = Convert.FromBase64String(text.Replace("data:image/png;base64,", ""));
						using (MemoryStream memoryStream = new MemoryStream(buffer))
						{
							this.Icon = new Bitmap(memoryStream);
						}
					}
				}
			}
			catch (Exception)
			{
				throw;
			}
		}

		// Token: 0x06000337 RID: 823 RVA: 0x000184B4 File Offset: 0x000166B4
		public void ReloadPing()
		{
			using (Ping ping = new Ping())
			{
				PingReply pingReply = ping.Send(this.ServerIP);
				if (pingReply.Status == IPStatus.Success)
				{
					this.Ping = pingReply.RoundtripTime;
				}
			}
		}

		// Token: 0x040002C6 RID: 710
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private string string_0;

		// Token: 0x040002C7 RID: 711
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private int int_0;

		// Token: 0x040002C8 RID: 712
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private string string_1;

		// Token: 0x040002C9 RID: 713
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int int_1;

		// Token: 0x040002CA RID: 714
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private int int_2;

		// Token: 0x040002CB RID: 715
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int int_3;

		// Token: 0x040002CC RID: 716
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private string string_2;

		// Token: 0x040002CD RID: 717
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private string string_3;

		// Token: 0x040002CE RID: 718
		[CompilerGenerated]
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private ForgeInfo forgeInfo_0;

		// Token: 0x040002CF RID: 719
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private List<string> list_0;

		// Token: 0x040002D0 RID: 720
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private long long_0;

		// Token: 0x040002D1 RID: 721
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		[CompilerGenerated]
		private Bitmap bitmap_0;
	}
}
