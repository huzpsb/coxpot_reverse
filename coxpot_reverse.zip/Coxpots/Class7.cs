﻿using System;
using Ionic.Zlib;

// Token: 0x02000076 RID: 118
internal sealed class Class7
{
	// Token: 0x06000206 RID: 518 RVA: 0x00005671 File Offset: 0x00003871
	internal bool method_0()
	{
		return this.bool_0;
	}

	// Token: 0x06000207 RID: 519 RVA: 0x00005679 File Offset: 0x00003879
	internal void method_1(bool bool_1)
	{
		this.bool_0 = bool_1;
	}

	// Token: 0x06000208 RID: 520 RVA: 0x00005682 File Offset: 0x00003882
	public Class7()
	{
		Class35.NkAVmDjz8ZWXG();
		this.bool_0 = true;
		base..ctor();
	}

	// Token: 0x06000209 RID: 521 RVA: 0x00005696 File Offset: 0x00003896
	public Class7(bool bool_1)
	{
		Class35.NkAVmDjz8ZWXG();
		this.bool_0 = true;
		base..ctor();
		this.bool_0 = bool_1;
	}

	// Token: 0x0600020A RID: 522 RVA: 0x000112F8 File Offset: 0x0000F4F8
	internal int method_2()
	{
		ZlibCodec zlibCodec = this.zlibCodec_0;
		this.zlibCodec_0.TotalBytesOut = 0L;
		zlibCodec.TotalBytesIn = 0L;
		this.zlibCodec_0.Message = null;
		this.enum6_0 = (this.method_0() ? ((Class7.Enum6)0) : ((Class7.Enum6)7));
		this.class4_0.method_0();
		return 0;
	}

	// Token: 0x0600020B RID: 523 RVA: 0x000056B1 File Offset: 0x000038B1
	internal int method_3()
	{
		if (this.class4_0 != null)
		{
			this.class4_0.method_1();
		}
		this.class4_0 = null;
		return 0;
	}

	// Token: 0x0600020C RID: 524 RVA: 0x00011358 File Offset: 0x0000F558
	internal int method_4(ZlibCodec zlibCodec_1, int int_3)
	{
		this.zlibCodec_0 = zlibCodec_1;
		this.zlibCodec_0.Message = null;
		this.class4_0 = null;
		if (int_3 < 8 || int_3 > 15)
		{
			this.method_3();
			throw new ZlibException("Bad window size.");
		}
		this.int_2 = int_3;
		this.class4_0 = new Class4(zlibCodec_1, this.method_0() ? this : null, 1 << int_3);
		this.method_2();
		return 0;
	}

	// Token: 0x0600020D RID: 525 RVA: 0x000113CC File Offset: 0x0000F5CC
	internal int method_5(FlushType flushType_0)
	{
		if (this.zlibCodec_0.InputBuffer == null)
		{
			throw new ZlibException("InputBuffer is null. ");
		}
		int num = 0;
		int num2 = -5;
		int nextIn;
		for (;;)
		{
			switch (this.enum6_0)
			{
			case (Class7.Enum6)0:
			{
				if (this.zlibCodec_0.AvailableBytesIn == 0)
				{
					goto IL_673;
				}
				num2 = num;
				this.zlibCodec_0.AvailableBytesIn--;
				this.zlibCodec_0.TotalBytesIn += 1L;
				byte[] inputBuffer = this.zlibCodec_0.InputBuffer;
				ZlibCodec zlibCodec = this.zlibCodec_0;
				nextIn = zlibCodec.NextIn;
				zlibCodec.NextIn = nextIn + 1;
				if (((this.int_0 = inputBuffer[nextIn]) & 15) != 8)
				{
					this.enum6_0 = (Class7.Enum6)13;
					this.zlibCodec_0.Message = string.Format("unknown compression method (0x{0:X2})", this.int_0);
					this.int_1 = 5;
					continue;
				}
				if ((this.int_0 >> 4) + 8 > this.int_2)
				{
					this.enum6_0 = (Class7.Enum6)13;
					this.zlibCodec_0.Message = string.Format("invalid window size ({0})", (this.int_0 >> 4) + 8);
					this.int_1 = 5;
					continue;
				}
				this.enum6_0 = (Class7.Enum6)1;
				continue;
			}
			case (Class7.Enum6)1:
			{
				if (this.zlibCodec_0.AvailableBytesIn == 0)
				{
					goto IL_67A;
				}
				num2 = num;
				this.zlibCodec_0.AvailableBytesIn--;
				this.zlibCodec_0.TotalBytesIn += 1L;
				byte[] inputBuffer2 = this.zlibCodec_0.InputBuffer;
				ZlibCodec zlibCodec2 = this.zlibCodec_0;
				nextIn = zlibCodec2.NextIn;
				zlibCodec2.NextIn = nextIn + 1;
				int num3 = inputBuffer2[nextIn] & 255;
				if (((this.int_0 << 8) + num3) % 31 != 0)
				{
					this.enum6_0 = (Class7.Enum6)13;
					this.zlibCodec_0.Message = "incorrect header check";
					this.int_1 = 5;
					continue;
				}
				this.enum6_0 = (((num3 & 32) == 0) ? ((Class7.Enum6)7) : ((Class7.Enum6)2));
				continue;
			}
			case (Class7.Enum6)2:
				if (this.zlibCodec_0.AvailableBytesIn != 0)
				{
					num2 = num;
					this.zlibCodec_0.AvailableBytesIn--;
					this.zlibCodec_0.TotalBytesIn += 1L;
					byte[] inputBuffer3 = this.zlibCodec_0.InputBuffer;
					ZlibCodec zlibCodec3 = this.zlibCodec_0;
					nextIn = zlibCodec3.NextIn;
					zlibCodec3.NextIn = nextIn + 1;
					this.uint_1 = (uint)(inputBuffer3[nextIn] << 24 & 4278190080L);
					this.enum6_0 = (Class7.Enum6)3;
					continue;
				}
				goto IL_681;
			case (Class7.Enum6)3:
				if (this.zlibCodec_0.AvailableBytesIn != 0)
				{
					num2 = num;
					this.zlibCodec_0.AvailableBytesIn--;
					this.zlibCodec_0.TotalBytesIn += 1L;
					uint num4 = this.uint_1;
					byte[] inputBuffer4 = this.zlibCodec_0.InputBuffer;
					ZlibCodec zlibCodec4 = this.zlibCodec_0;
					nextIn = zlibCodec4.NextIn;
					zlibCodec4.NextIn = nextIn + 1;
					this.uint_1 = num4 + (inputBuffer4[nextIn] << 16 & 16711680u);
					this.enum6_0 = (Class7.Enum6)4;
					continue;
				}
				goto IL_688;
			case (Class7.Enum6)4:
				if (this.zlibCodec_0.AvailableBytesIn != 0)
				{
					num2 = num;
					this.zlibCodec_0.AvailableBytesIn--;
					this.zlibCodec_0.TotalBytesIn += 1L;
					uint num5 = this.uint_1;
					byte[] inputBuffer5 = this.zlibCodec_0.InputBuffer;
					ZlibCodec zlibCodec5 = this.zlibCodec_0;
					nextIn = zlibCodec5.NextIn;
					zlibCodec5.NextIn = nextIn + 1;
					this.uint_1 = num5 + (inputBuffer5[nextIn] << 8 & 65280u);
					this.enum6_0 = (Class7.Enum6)5;
					continue;
				}
				goto IL_68F;
			case (Class7.Enum6)5:
				goto IL_696;
			case (Class7.Enum6)6:
				goto IL_72E;
			case (Class7.Enum6)7:
				num2 = this.class4_0.SvBuDpbipQ(num2);
				if (num2 == -3)
				{
					this.enum6_0 = (Class7.Enum6)13;
					this.int_1 = 0;
					continue;
				}
				if (num2 == 0)
				{
					num2 = num;
				}
				if (num2 != 1)
				{
					goto IL_752;
				}
				num2 = num;
				this.uint_0 = this.class4_0.method_0();
				if (this.method_0())
				{
					this.enum6_0 = (Class7.Enum6)8;
					continue;
				}
				goto IL_756;
			case (Class7.Enum6)8:
				if (this.zlibCodec_0.AvailableBytesIn != 0)
				{
					num2 = num;
					this.zlibCodec_0.AvailableBytesIn--;
					this.zlibCodec_0.TotalBytesIn += 1L;
					byte[] inputBuffer6 = this.zlibCodec_0.InputBuffer;
					ZlibCodec zlibCodec6 = this.zlibCodec_0;
					nextIn = zlibCodec6.NextIn;
					zlibCodec6.NextIn = nextIn + 1;
					this.uint_1 = (uint)(inputBuffer6[nextIn] << 24 & 4278190080L);
					this.enum6_0 = (Class7.Enum6)9;
					continue;
				}
				goto IL_762;
			case (Class7.Enum6)9:
				if (this.zlibCodec_0.AvailableBytesIn != 0)
				{
					num2 = num;
					this.zlibCodec_0.AvailableBytesIn--;
					this.zlibCodec_0.TotalBytesIn += 1L;
					uint num6 = this.uint_1;
					byte[] inputBuffer7 = this.zlibCodec_0.InputBuffer;
					ZlibCodec zlibCodec7 = this.zlibCodec_0;
					nextIn = zlibCodec7.NextIn;
					zlibCodec7.NextIn = nextIn + 1;
					this.uint_1 = num6 + (inputBuffer7[nextIn] << 16 & 16711680u);
					this.enum6_0 = (Class7.Enum6)10;
					continue;
				}
				goto IL_766;
			case (Class7.Enum6)10:
				if (this.zlibCodec_0.AvailableBytesIn != 0)
				{
					num2 = num;
					this.zlibCodec_0.AvailableBytesIn--;
					this.zlibCodec_0.TotalBytesIn += 1L;
					uint num7 = this.uint_1;
					byte[] inputBuffer8 = this.zlibCodec_0.InputBuffer;
					ZlibCodec zlibCodec8 = this.zlibCodec_0;
					nextIn = zlibCodec8.NextIn;
					zlibCodec8.NextIn = nextIn + 1;
					this.uint_1 = num7 + (inputBuffer8[nextIn] << 8 & 65280u);
					this.enum6_0 = (Class7.Enum6)11;
					continue;
				}
				goto IL_76A;
			case (Class7.Enum6)11:
			{
				if (this.zlibCodec_0.AvailableBytesIn == 0)
				{
					goto IL_76E;
				}
				num2 = num;
				this.zlibCodec_0.AvailableBytesIn--;
				this.zlibCodec_0.TotalBytesIn += 1L;
				uint num8 = this.uint_1;
				byte[] inputBuffer9 = this.zlibCodec_0.InputBuffer;
				ZlibCodec zlibCodec9 = this.zlibCodec_0;
				nextIn = zlibCodec9.NextIn;
				zlibCodec9.NextIn = nextIn + 1;
				this.uint_1 = num8 + (inputBuffer9[nextIn] & 255u);
				if (this.uint_0 != this.uint_1)
				{
					this.enum6_0 = (Class7.Enum6)13;
					this.zlibCodec_0.Message = "incorrect data check";
					this.int_1 = 5;
					continue;
				}
				goto IL_772;
			}
			case (Class7.Enum6)12:
				goto IL_77E;
			case (Class7.Enum6)13:
				goto IL_782;
			}
			break;
		}
		throw new ZlibException("Stream error.");
		IL_673:
		return num2;
		IL_67A:
		return num2;
		IL_681:
		return num2;
		IL_688:
		return num2;
		IL_68F:
		return num2;
		IL_696:
		if (this.zlibCodec_0.AvailableBytesIn == 0)
		{
			return num2;
		}
		this.zlibCodec_0.AvailableBytesIn--;
		this.zlibCodec_0.TotalBytesIn += 1L;
		uint num9 = this.uint_1;
		byte[] inputBuffer10 = this.zlibCodec_0.InputBuffer;
		ZlibCodec zlibCodec10 = this.zlibCodec_0;
		nextIn = zlibCodec10.NextIn;
		zlibCodec10.NextIn = nextIn + 1;
		this.uint_1 = num9 + (inputBuffer10[nextIn] & 255u);
		this.zlibCodec_0.uint_0 = this.uint_1;
		this.enum6_0 = (Class7.Enum6)6;
		return 2;
		IL_72E:
		this.enum6_0 = (Class7.Enum6)13;
		this.zlibCodec_0.Message = "need dictionary";
		this.int_1 = 0;
		return -2;
		IL_752:
		return num2;
		IL_756:
		this.enum6_0 = (Class7.Enum6)12;
		return 1;
		IL_762:
		return num2;
		IL_766:
		return num2;
		IL_76A:
		return num2;
		IL_76E:
		return num2;
		IL_772:
		this.enum6_0 = (Class7.Enum6)12;
		return 1;
		IL_77E:
		return 1;
		IL_782:
		throw new ZlibException(string.Format("Bad state ({0})", this.zlibCodec_0.Message));
	}

	// Token: 0x0600020E RID: 526 RVA: 0x00011B78 File Offset: 0x0000FD78
	internal int method_6(byte[] byte_1)
	{
		int int_ = 0;
		int num = byte_1.Length;
		if (this.enum6_0 != (Class7.Enum6)6)
		{
			throw new ZlibException("Stream error.");
		}
		int result;
		if (Adler.Adler32(1u, byte_1, 0, byte_1.Length) != this.zlibCodec_0.uint_0)
		{
			result = -3;
		}
		else
		{
			this.zlibCodec_0.uint_0 = Adler.Adler32(0u, null, 0, 0);
			if (num >= 1 << this.int_2)
			{
				num = (1 << this.int_2) - 1;
				int_ = byte_1.Length - num;
			}
			this.class4_0.method_2(byte_1, int_, num);
			this.enum6_0 = (Class7.Enum6)7;
			result = 0;
		}
		return result;
	}

	// Token: 0x0600020F RID: 527 RVA: 0x00011C1C File Offset: 0x0000FE1C
	internal int method_7()
	{
		if (this.enum6_0 != (Class7.Enum6)13)
		{
			this.enum6_0 = (Class7.Enum6)13;
			this.int_1 = 0;
		}
		int num;
		int result;
		if ((num = this.zlibCodec_0.AvailableBytesIn) == 0)
		{
			result = -5;
		}
		else
		{
			int num2 = this.zlibCodec_0.NextIn;
			int num3 = this.int_1;
			while (num != 0 && num3 < 4)
			{
				if (this.zlibCodec_0.InputBuffer[num2] == Class7.byte_0[num3])
				{
					num3++;
				}
				else if (this.zlibCodec_0.InputBuffer[num2] > 0)
				{
					num3 = 0;
				}
				else
				{
					num3 = 4 - num3;
				}
				num2++;
				num--;
			}
			this.zlibCodec_0.TotalBytesIn += (long)(num2 - this.zlibCodec_0.NextIn);
			this.zlibCodec_0.NextIn = num2;
			this.zlibCodec_0.AvailableBytesIn = num;
			this.int_1 = num3;
			if (num3 != 4)
			{
				result = -3;
			}
			else
			{
				long totalBytesIn = this.zlibCodec_0.TotalBytesIn;
				long totalBytesOut = this.zlibCodec_0.TotalBytesOut;
				this.method_2();
				this.zlibCodec_0.TotalBytesIn = totalBytesIn;
				this.zlibCodec_0.TotalBytesOut = totalBytesOut;
				this.enum6_0 = (Class7.Enum6)7;
				result = 0;
			}
		}
		return result;
	}

	// Token: 0x06000210 RID: 528 RVA: 0x00011D58 File Offset: 0x0000FF58
	internal int xlbtvqiXjb(ZlibCodec zlibCodec_1)
	{
		return this.class4_0.method_3();
	}

	// Token: 0x06000211 RID: 529 RVA: 0x000056D1 File Offset: 0x000038D1
	static Class7()
	{
		Class35.NkAVmDjz8ZWXG();
		Class7.byte_0 = new byte[]
		{
			0,
			0,
			byte.MaxValue,
			byte.MaxValue
		};
	}

	// Token: 0x04000211 RID: 529
	private Class7.Enum6 enum6_0;

	// Token: 0x04000212 RID: 530
	internal ZlibCodec zlibCodec_0;

	// Token: 0x04000213 RID: 531
	internal int int_0;

	// Token: 0x04000214 RID: 532
	internal uint uint_0;

	// Token: 0x04000215 RID: 533
	internal uint uint_1;

	// Token: 0x04000216 RID: 534
	internal int int_1;

	// Token: 0x04000217 RID: 535
	private bool bool_0;

	// Token: 0x04000218 RID: 536
	internal int int_2;

	// Token: 0x04000219 RID: 537
	internal Class4 class4_0;

	// Token: 0x0400021A RID: 538
	private static readonly byte[] byte_0;

	// Token: 0x02000077 RID: 119
	private enum Enum6
	{

	}
}
