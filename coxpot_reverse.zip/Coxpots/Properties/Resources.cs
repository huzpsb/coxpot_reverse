﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Coxpots.Properties
{
	// Token: 0x020000A7 RID: 167
	[DebuggerNonUserCode]
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
	[CompilerGenerated]
	internal class Resources
	{
		// Token: 0x06000366 RID: 870 RVA: 0x0000480C File Offset: 0x00002A0C
		internal Resources()
		{
			Class35.NkAVmDjz8ZWXG();
			base..ctor();
		}

		// Token: 0x1700007A RID: 122
		// (get) Token: 0x06000367 RID: 871 RVA: 0x0001A1CC File Offset: 0x000183CC
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager_0
		{
			get
			{
				if (Resources.resourceManager_0 == null)
				{
					ResourceManager resourceManager = new ResourceManager("Coxpots.Properties.Resources", typeof(Resources).Assembly);
					Resources.resourceManager_0 = resourceManager;
				}
				return Resources.resourceManager_0;
			}
		}

		// Token: 0x1700007B RID: 123
		// (get) Token: 0x06000368 RID: 872 RVA: 0x0001A20C File Offset: 0x0001840C
		// (set) Token: 0x06000369 RID: 873 RVA: 0x00005F00 File Offset: 0x00004100
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo CultureInfo_0
		{
			get
			{
				return Resources.cultureInfo_0;
			}
			set
			{
				Resources.cultureInfo_0 = value;
			}
		}

		// Token: 0x0600036A RID: 874 RVA: 0x0001A220 File Offset: 0x00018420
		internal static string smethod_0()
		{
			return Resources.ResourceManager_0.GetString("DefaultConfig", Resources.cultureInfo_0);
		}

		// Token: 0x040002E8 RID: 744
		private static ResourceManager resourceManager_0;

		// Token: 0x040002E9 RID: 745
		private static CultureInfo cultureInfo_0;
	}
}
