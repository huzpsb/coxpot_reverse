﻿using System;

// Token: 0x02000080 RID: 128
internal static class Class11
{
	// Token: 0x06000227 RID: 551 RVA: 0x00012C20 File Offset: 0x00010E20
	static Class11()
	{
		Class35.NkAVmDjz8ZWXG();
		Class11.int_0 = 15;
		Class11.int_1 = 19;
		Class11.int_2 = 30;
		Class11.int_3 = 256;
		Class11.int_4 = 29;
		Class11.int_5 = Class11.int_3 + 1 + Class11.int_4;
		Class11.int_6 = 7;
		Class11.int_7 = 16;
		Class11.int_8 = 17;
		Class11.int_9 = 18;
	}

	// Token: 0x04000250 RID: 592
	internal static readonly int int_0;

	// Token: 0x04000251 RID: 593
	internal static readonly int int_1;

	// Token: 0x04000252 RID: 594
	internal static readonly int int_2;

	// Token: 0x04000253 RID: 595
	internal static readonly int int_3;

	// Token: 0x04000254 RID: 596
	internal static readonly int int_4;

	// Token: 0x04000255 RID: 597
	internal static readonly int int_5;

	// Token: 0x04000256 RID: 598
	internal static readonly int int_6;

	// Token: 0x04000257 RID: 599
	internal static readonly int int_7;

	// Token: 0x04000258 RID: 600
	internal static readonly int int_8;

	// Token: 0x04000259 RID: 601
	internal static readonly int int_9;
}
