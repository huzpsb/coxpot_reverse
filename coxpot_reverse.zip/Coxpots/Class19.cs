﻿using System;
using System.Collections.Generic;
using System.IO;
using Coxpots;

// Token: 0x02000091 RID: 145
internal class Class19
{
	// Token: 0x060002B7 RID: 695 RVA: 0x00015754 File Offset: 0x00013954
	public static string smethod_0(string string_0, List<string> list_0 = null)
	{
		return Class19.smethod_1(Class21.smethod_0(string_0), "", list_0);
	}

	// Token: 0x060002B8 RID: 696 RVA: 0x00015774 File Offset: 0x00013974
	private static string smethod_1(Class21.Class22 class22_0, string string_0, List<string> list_0)
	{
		string text = "";
		string result;
		switch (class22_0.method_0())
		{
		case (Class21.Class22.Enum9)0:
			if (class22_0.dictionary_0.ContainsKey("clickEvent") && list_0 != null)
			{
				Class21.Class22 @class = class22_0.dictionary_0["clickEvent"];
				if (@class.dictionary_0.ContainsKey("action") && @class.dictionary_0.ContainsKey("value") && @class.dictionary_0["action"].string_0 == "open_url" && !string.IsNullOrEmpty(@class.dictionary_0["value"].string_0))
				{
					list_0.Add(@class.dictionary_0["value"].string_0);
				}
			}
			if (class22_0.dictionary_0.ContainsKey("extra"))
			{
				Class21.Class22[] array = class22_0.dictionary_0["extra"].list_0.ToArray();
				foreach (Class21.Class22 class22_ in array)
				{
					text = text + Class19.smethod_1(class22_, string_0, list_0) + "§r";
				}
			}
			if (class22_0.dictionary_0.ContainsKey("text"))
			{
				result = string_0 + Class19.smethod_1(class22_0.dictionary_0["text"], string_0, list_0) + text;
			}
			else if (class22_0.dictionary_0.ContainsKey("translate"))
			{
				List<string> list = new List<string>();
				if (class22_0.dictionary_0.ContainsKey("using") && !class22_0.dictionary_0.ContainsKey("with"))
				{
					class22_0.dictionary_0["with"] = class22_0.dictionary_0["using"];
				}
				if (class22_0.dictionary_0.ContainsKey("with"))
				{
					Class21.Class22[] array3 = class22_0.dictionary_0["with"].list_0.ToArray();
					for (int j = 0; j < array3.Length; j++)
					{
						list.Add(Class19.smethod_1(array3[j], string_0, list_0));
					}
				}
				result = string_0 + Class19.smethod_1(class22_0.dictionary_0["translate"], "", list_0) + text;
			}
			else
			{
				result = text;
			}
			break;
		case (Class21.Class22.Enum9)1:
		{
			string text2 = "";
			foreach (Class21.Class22 class22_2 in class22_0.list_0)
			{
				text2 += Class19.smethod_1(class22_2, string_0, list_0);
			}
			result = text2;
			break;
		}
		case (Class21.Class22.Enum9)2:
			result = string_0 + class22_0.string_0;
			break;
		default:
			result = "";
			break;
		}
		return result;
	}

	// Token: 0x060002B9 RID: 697 RVA: 0x00015A50 File Offset: 0x00013C50
	public static void smethod_2(string string_0, int int_0, string string_1, int int_1)
	{
		if (Setting.wlogs)
		{
			string path = "服务器日志.txt";
			string str = "";
			string text = "5.7";
			string str2 = string.Format("黑河日志记录 \n\n[{0}]\r\nTarget: {1}:{2}\r\nVersion: {3}\r\nThreads: {4}\r\n软件版本:{5}\r\n\r\n", new object[]
			{
				DateTime.Now.ToString("HH 24,MM dd,yyyy"),
				string_0,
				int_0,
				string_1,
				int_1,
				text
			});
			if (File.Exists(path))
			{
				str = File.ReadAllText(path);
			}
			File.WriteAllText(path, str + str2);
		}
	}

	// Token: 0x060002BA RID: 698 RVA: 0x0000480C File Offset: 0x00002A0C
	public Class19()
	{
		Class35.NkAVmDjz8ZWXG();
		base..ctor();
	}
}
