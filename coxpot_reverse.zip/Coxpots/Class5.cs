﻿using System;

// Token: 0x02000074 RID: 116
internal static class Class5
{
	// Token: 0x06000201 RID: 513 RVA: 0x00005600 File Offset: 0x00003800
	static Class5()
	{
		Class35.NkAVmDjz8ZWXG();
		Class5.int_0 = new int[]
		{
			0,
			1,
			3,
			7,
			15,
			31,
			63,
			127,
			255,
			511,
			1023,
			2047,
			4095,
			8191,
			16383,
			32767,
			65535
		};
	}

	// Token: 0x04000202 RID: 514
	internal static readonly int[] int_0;
}
