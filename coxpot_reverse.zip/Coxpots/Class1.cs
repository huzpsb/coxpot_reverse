﻿using System;
using System.Globalization;
using System.Net;
using System.Net.Sockets;

// Token: 0x02000014 RID: 20
internal static class Class1
{
	// Token: 0x06000094 RID: 148 RVA: 0x00008638 File Offset: 0x00006838
	internal static string smethod_0(TcpClient tcpClient_0)
	{
		if (tcpClient_0 == null)
		{
			throw new ArgumentNullException("client");
		}
		string result = "";
		try
		{
			result = ((IPEndPoint)tcpClient_0.Client.RemoteEndPoint).Address.ToString();
		}
		catch
		{
		}
		return result;
	}

	// Token: 0x06000095 RID: 149 RVA: 0x00008690 File Offset: 0x00006890
	internal static string smethod_1(TcpClient tcpClient_0)
	{
		if (tcpClient_0 == null)
		{
			throw new ArgumentNullException("client");
		}
		string result = "";
		try
		{
			result = ((IPEndPoint)tcpClient_0.Client.RemoteEndPoint).Port.ToString(CultureInfo.InvariantCulture);
		}
		catch
		{
		}
		return result;
	}
}
